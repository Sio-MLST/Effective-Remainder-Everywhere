namespace Gen

def tri : Nat → Nat
  | 0 => 0
  | n + 1 => tri n + n

theorem tri_two (n : Nat) : 2 * tri n = n * (n - 1) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    show 2 * (tri n + n) = (n + 1) * n
    rw [Nat.mul_add, ih]; cases n with
    | zero => rfl
    | succ n => simp; grind

theorem pow_expand (a : Nat) : ∀ n, ∃ z, (1 + a) ^ n = 1 + n * a + tri n * a ^ 2 + a ^ 3 * z
  | 0 => ⟨0, by simp [tri]⟩
  | n + 1 => by
    obtain ⟨z, hz⟩ := pow_expand a n
    refine ⟨tri n + z + z * a, ?_⟩
    rw [Nat.pow_succ, hz]; show _ = 1 + (n + 1) * a + (tri n + n) * a ^ 2 + a ^ 3 * (tri n + z + z * a)
    grind

theorem pow_expand2 (a : Nat) : ∀ n, ∃ z, (1 + a) ^ n = 1 + n * a + a ^ 2 * z := by
  intro n; obtain ⟨z, hz⟩ := pow_expand a n
  exact ⟨tri n + a * z, by rw [hz]; grind⟩

theorem lte_step {p j u : Nat} (hp : p % 2 = 1) (hj : 1 ≤ j) (hu : Nat.Coprime p u) :
    ∃ w, Nat.Coprime p w ∧ (1 + p ^ j * u) ^ p = 1 + p ^ (j + 1) * w := by
  obtain ⟨z, hz⟩ := pow_expand (p ^ j * u) p
  obtain ⟨h, hh⟩ : ∃ h, tri p = p * h := by
    refine ⟨(p - 1) / 2, ?_⟩
    have := tri_two p
    have : (p - 1) % 2 = 0 := by omega
    have e : p - 1 = 2 * ((p - 1) / 2) := by omega
    rw [e] at *; grind
  obtain ⟨k, rfl⟩ : ∃ k, j = k + 1 := ⟨j - 1, by omega⟩
  let w := u + p * (h * p ^ k * u ^ 2 + p ^ (2 * k) * u ^ 3 * z)
  refine ⟨w, ?_, ?_⟩
  · show Nat.Coprime p (u + p * _)
    rw [Nat.Coprime, Nat.gcd_add_mul_left_right]; exact hu
  · rw [hz, hh]
    show _ = 1 + p ^ (k + 1 + 1) * (u + p * (h * p ^ k * u ^ 2 + p ^ (2 * k) * u ^ 3 * z))
    have e1 : p ^ (k + 1 + 1) = p * p * p ^ k := by rw [Nat.pow_succ, Nat.pow_succ]; grind
    have e2 : p ^ (k + 1) = p * p ^ k := by rw [Nat.pow_succ]; grind
    have e3 : p ^ (2 * k) = p ^ k * p ^ k := by rw [Nat.two_mul, Nat.pow_add]
    rw [e1, e2, e3]; generalize p ^ k = A; grind

theorem lte {p u : Nat} (hp : p % 2 = 1) (hu : Nat.Coprime p u) :
    ∀ n, ∃ w, Nat.Coprime p w ∧ (1 + p * u) ^ (p ^ n) = 1 + p ^ (n + 1) * w
  | 0 => ⟨u, hu, by simp⟩
  | n + 1 => by
    obtain ⟨w, hw, hx⟩ := lte hp hu n
    obtain ⟨w', hw', hx'⟩ := lte_step (j := n + 1) hp (by omega) hw
    exact ⟨w', hw', by rw [Nat.pow_succ, Nat.pow_mul, hx, hx']⟩

theorem order_iff {p u : Nat} (hp : p % 2 = 1) (hp3 : 3 ≤ p) (hu : Nat.Coprime p u) :
    ∀ K m, (1 + p * u) ^ m % p ^ (K + 1) = 1 ↔ p ^ K ∣ m := by
  have hP : ∀ K, 1 < p ^ (K + 1) := fun K =>
    Nat.lt_of_lt_of_le (by omega) (Nat.le_self_pow (by omega) p)
  intro K
  induction K with
  | zero =>
    intro m
    obtain ⟨z, hz⟩ := pow_expand2 (p * u) m
    simp only [Nat.pow_zero, Nat.one_dvd, iff_true, Nat.zero_add, Nat.pow_one]
    rw [hz, show 1 + m * (p * u) + (p * u) ^ 2 * z = 1 + p * (m * u + p * u ^ 2 * z) by grind,
      Nat.add_mul_mod_self_left]; exact Nat.mod_eq_of_lt (by omega)
  | succ K ih =>
    intro m
    constructor
    · intro h
      have h1 : (1 + p * u) ^ m % p ^ (K + 1) = 1 := by
        rw [← Nat.mod_mod_of_dvd _ (Nat.pow_dvd_pow p (by omega : K + 1 ≤ K + 1 + 1)), h]
        exact Nat.mod_eq_of_lt (hP K)
      obtain ⟨k, rfl⟩ := (ih m).1 h1
      by_cases hpk : p ∣ k
      · obtain ⟨k', rfl⟩ := hpk; exact ⟨k', by rw [Nat.pow_succ]; grind⟩
      · exfalso
        obtain ⟨w, hw, hx⟩ := lte hp hu K
        obtain ⟨z, hz⟩ := pow_expand2 (p ^ (K + 1) * w) k
        rw [Nat.pow_mul, hx, hz,
          show 1 + k * (p ^ (K + 1) * w) + (p ^ (K + 1) * w) ^ 2 * z
            = 1 + p ^ (K + 1) * (k * w + p ^ (K + 1) * (w ^ 2 * z)) by grind,
          show p ^ (K + 1 + 1) = p ^ (K + 1) * p by rw [Nat.pow_succ]] at h
        have hd : p ^ (K + 1) * p ∣ p ^ (K + 1) * (k * w + p ^ (K + 1) * (w ^ 2 * z)) := by
          have h2 := Nat.sub_mod_eq_zero_of_mod_eq
            (h.trans (Nat.mod_eq_of_lt (by have := hP (K + 1); rwa [Nat.pow_succ] at this)).symm)
          simpa using Nat.dvd_of_mod_eq_zero h2
        have hd2 := Nat.dvd_of_mul_dvd_mul_left (Nat.pow_pos (by omega)) hd
        have hd3 : p ∣ p ^ (K + 1) * (w ^ 2 * z) :=
          Nat.dvd_trans ⟨p ^ K, by rw [Nat.pow_succ, Nat.mul_comm]⟩ (Nat.dvd_mul_right _ _)
        have hkw : p ∣ k * w := (Nat.dvd_add_left hd3).1 hd2
        exact hpk (Nat.Coprime.dvd_of_dvd_mul_right hw hkw)
    · rintro ⟨k, rfl⟩
      obtain ⟨w, hw, hx⟩ := lte hp hu (K + 1)
      rw [Nat.pow_mul, hx, Nat.pow_mod, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt (hP _),
        Nat.one_pow, Nat.mod_eq_of_lt (hP _)]

def Cong (n : Nat) (a b : Int) : Prop := (n : Int) ∣ a - b

theorem Cong.refl (n : Nat) (a : Int) : Cong n a a := by simp [Cong]
theorem Cong.symm {n : Nat} {a b : Int} (h : Cong n a b) : Cong n b a := by
  unfold Cong at *; have := Int.dvd_neg.2 h; rwa [Int.neg_sub] at this
theorem Cong.trans {n : Nat} {a b c : Int} (h1 : Cong n a b) (h2 : Cong n b c) : Cong n a c := by
  unfold Cong at *; have := Int.dvd_add h1 h2; rwa [show a - b + (b - c) = a - c by omega] at this
theorem Cong.mul {n : Nat} {a b c d : Int} (h1 : Cong n a b) (h2 : Cong n c d) : Cong n (a * c) (b * d) := by
  unfold Cong at *
  have e : a * c - b * d = (a - b) * c + b * (c - d) := by
    rw [Int.sub_mul, Int.mul_sub]; omega
  rw [e]; exact Int.dvd_add (Int.dvd_trans h1 (Int.dvd_mul_right _ c)) (Int.dvd_trans h2 (Int.dvd_mul_left b _))
theorem Cong.of_dvd {n n' : Nat} {a b : Int} (hd : n ∣ n') (h : Cong n' a b) : Cong n a b :=
  Int.dvd_trans (Int.natCast_dvd_natCast.2 hd) h
theorem Cong.pow_one {n : Nat} {a : Int} (h : Cong n a 1) : ∀ k, Cong n (a ^ k) 1
  | 0 => by simp [Cong]
  | k + 1 => by rw [Int.pow_succ, show (1 : Int) = 1 * 1 from rfl]; exact (Cong.pow_one h k).mul h
theorem Cong.cancel {n c : Nat} {a b : Int} (hc : Nat.Coprime n c) (h : Cong n ((c : Int) * a) ((c : Int) * b)) :
    Cong n a b := by
  unfold Cong at *
  rw [← Int.mul_sub, Int.ofNat_dvd_left, Int.natAbs_mul, Int.natAbs_natCast] at h
  exact Int.ofNat_dvd_left.2 (Nat.Coprime.dvd_of_dvd_mul_left hc h)
theorem Cong.sub {n : Nat} {a b c d : Int} (h1 : Cong n a b) (h2 : Cong n c d) : Cong n (a - c) (b - d) := by
  unfold Cong at *; have := Int.dvd_sub h1 h2; rwa [show a - c - (b - d) = a - b - (c - d) by omega]

theorem coprime_two_of_odd {p : Nat} (hp : p % 2 = 1) : Nat.Coprime p 2 := by
  unfold Nat.Coprime; rw [Nat.gcd_comm, Nat.gcd_rec, hp]; rfl

theorem period_general (p K q i₀ T : Nat) (hp : p % 2 = 1) (hq1 : 1 < q) (hqp : Nat.Coprime q p)
    (hT1 : 1 ≤ T) (hT : Cong (p ^ (K + 1)) (2 ^ T) 1)
    (hA : ∀ m, Cong (p ^ (K + 1)) (2 ^ m) 1 → Cong q (2 ^ m) 1)
    (hi₀ : Cong (p ^ (K + 1)) (2 * 2 ^ i₀) (p + 1))
    (hGen : ∀ m, ∃ i, Cong (p ^ (K + 1)) (2 * 2 ^ i) (p * 2 ^ m + 1))
    (hB : ∀ i m, Cong (p ^ (K + 1)) (2 * 2 ^ i) (p * 2 ^ m + 1) →
      Cong q (p * 2 ^ m + 2 * 2 ^ i₀) (p + 2 * 2 ^ i)) : False := by
  have hTq : Cong q (2 ^ T) 1 := hA T hT
  have S : ∀ d, d ≤ K + 1 → ∀ m, Cong (p ^ (K + 1 - d)) (2 ^ m) 1 → Cong q (2 ^ m) 1 := by
    intro d
    induction d with
    | zero => intro _ m h; exact hA m h
    | succ d ih =>
      intro hd m hm
      have hj : K + 1 - d = (K + 1 - (d + 1)) + 1 := by omega
      have hdiv : p ^ (K + 1 - d) ∣ p ^ (K + 1) := Nat.pow_dvd_pow p (by omega)
      obtain ⟨i, hi⟩ := hGen m

      have hpm : Cong (p ^ (K + 1 - d)) ((p : Int) * 2 ^ m) p := by
        unfold Cong at hm ⊢
        rw [hj, Nat.pow_succ, Nat.mul_comm, Int.natCast_mul,
          show (p : Int) * 2 ^ m - p = p * (2 ^ m - 1) by rw [Int.mul_sub, Int.mul_one]]
        exact Int.mul_dvd_mul_left _ hm
      have h2 : Cong (p ^ (K + 1 - d)) (2 * 2 ^ i) (2 * 2 ^ i₀) := by
        have a := (hi.of_dvd hdiv).sub (hi₀.of_dvd hdiv)
        have b := (hpm.sub (Cong.refl _ (p : Int)))
        refine Cong.trans (b := (p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀) ?_ ?_
        · unfold Cong at a ⊢; rwa [show (2 : Int) * 2 ^ i - ((p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀)
            = 2 * 2 ^ i - 2 * 2 ^ i₀ - ((p : Int) * 2 ^ m + 1 - (p + 1)) by omega]
        · unfold Cong at b ⊢; rwa [show (p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀ - 2 * 2 ^ i₀
            = (p : Int) * 2 ^ m - p - (p - p) by omega]
      have h2' : Cong (p ^ (K + 1 - d)) (2 ^ i) (2 ^ i₀) :=
        Cong.cancel (c := 2) (Nat.Coprime.pow_left _ (coprime_two_of_odd hp)) (by exact_mod_cast h2)
      let m' := i + i₀ * (T - 1)
      have hsplit : (2 : Int) ^ m' * 2 ^ i₀ = 2 ^ i * (2 ^ T) ^ i₀ := by
        rw [← Int.pow_add, ← Int.pow_mul, ← Int.pow_add]; congr 1
        show i + i₀ * (T - 1) + i₀ = i + T * i₀
        rw [Nat.mul_comm T, Nat.add_assoc, ← Nat.mul_succ, show (T - 1).succ = T by omega]
      have hm'P : Cong (p ^ (K + 1 - d)) (2 ^ m' * 2 ^ i₀) (1 * 2 ^ i₀) := by
        rw [hsplit, Int.one_mul]
        have := (Cong.refl _ ((2 : Int) ^ i)).mul ((hT.of_dvd hdiv).pow_one i₀)
        rw [Int.mul_one] at this; exact this.trans h2'
      have hm' : Cong (p ^ (K + 1 - d)) (2 ^ m') 1 := by
        rw [Int.mul_comm, Int.mul_comm (1 : Int)] at hm'P
        exact Cong.cancel (c := 2 ^ i₀) (Nat.Coprime.pow _ _ (coprime_two_of_odd hp))
          (by exact_mod_cast hm'P)
      have hq' := ih (by omega) m' hm'
      have hiq : Cong q (2 ^ i) (2 ^ i₀) := by
        have a := hq'.mul (Cong.refl q ((2 : Int) ^ i₀))
        rw [hsplit, Int.one_mul] at a
        have b := (Cong.refl q ((2 : Int) ^ i)).mul (hTq.pow_one i₀)
        rw [Int.mul_one] at b; exact b.symm.trans a
      have hBq := hB i m hi
      have c1 : Cong q ((p : Int) * 2 ^ m) ((p : Int) * 1) := by
        have := hBq.sub ((Cong.refl q (2 : Int)).mul hiq |>.symm)
        unfold Cong at this ⊢
        rwa [show (p : Int) * 2 ^ m + 2 * 2 ^ i₀ - 2 * 2 ^ i₀ - (p + 2 * 2 ^ i - 2 * 2 ^ i)
          = p * 2 ^ m - p * 1 by omega] at this
      exact Cong.cancel hqp c1
  have h := S (K + 1) (Nat.le_refl _) 1 (by rw [Nat.sub_self, Nat.pow_zero]; exact Int.one_dvd _)
  unfold Cong at h
  have := Int.le_of_dvd (by decide) h
  omega

theorem cong_of_mod {n a b : Nat} (h : a % n = b % n) : Cong n (a : Int) (b : Int) := by
  have h' : ((a:Int) % n) = ((b:Int) % n) := by exact_mod_cast h
  exact Int.dvd_of_emod_eq_zero (Int.emod_eq_emod_iff_emod_sub_eq_zero.mp h')

theorem mod_of_cong {n a b : Nat} (h : Cong n (a : Int) (b : Int)) : a % n = b % n := by
  have := Int.emod_eq_emod_iff_emod_sub_eq_zero.mpr (Int.emod_eq_zero_of_dvd h)
  exact_mod_cast this

theorem mod_cancel_mul_left {m a x y : Nat} (hcop : Nat.Coprime m a) (hxy : y ≤ x)
    (h : (a * x) % m = (a * y) % m) : x % m = y % m := by
  have h1 := Nat.sub_mod_eq_zero_of_mod_eq h
  have h2 : a * x - a * y = a * (x - y) := (Nat.mul_sub a x y).symm
  rw [h2] at h1
  have h3 : m ∣ a * (x - y) := Nat.dvd_of_mod_eq_zero h1
  have h4 : m ∣ x - y := Nat.Coprime.dvd_of_dvd_mul_left hcop h3
  have h5 := Nat.mod_eq_zero_of_dvd h4
  have h6 : x = y + (x - y) := by omega
  rw [h6, Nat.add_mod, h5]; simp

theorem coprime_of_mod_one {p x : Nat} (h : x % p = 1) : Nat.Coprime p x := by
  unfold Nat.Coprime; rw [Nat.gcd_rec, h, Nat.gcd_one_left]

theorem pow_mod_one {p x : Nat} (hp : 2 ≤ p) (h : x % p = 1) (t : Nat) : x ^ t % p = 1 := by
  rw [Nat.pow_mod, h, Nat.one_pow]; exact Nat.mod_eq_of_lt (by omega)

theorem gen_unit {p u : Nat} (hp : p % 2 = 1) (hp3 : 3 ≤ p) (hu : Nat.Coprime p u)
    (K x : Nat) (hx : x % p = 1) : ∃ t, t < p ^ K ∧ (1 + p * u) ^ t % p ^ (K + 1) = x % p ^ (K + 1) := by
  apply Classical.byContradiction
  intro hno
  have hP : 0 < p ^ (K + 1) := Nat.pow_pos (by omega)
  have hpK : 0 < p ^ K := Nat.pow_pos (by omega)
  have hPe : p ^ (K + 1) = p * p ^ K := by rw [Nat.pow_succ, Nat.mul_comm]
  have hdv : p ∣ p ^ (K + 1) := ⟨p ^ K, hPe⟩
  have hc1 : (1 + p * u) % p = 1 := by rw [Nat.add_mul_mod_self_left]; exact Nat.mod_eq_of_lt (by omega)
  have hcop : Nat.Coprime (p ^ (K + 1)) (1 + p * u) := Nat.Coprime.pow_left _ (coprime_of_mod_one hc1)
  let U : List Nat := (List.range (p ^ (K + 1))).filter (fun y => decide (y % p = 1))
  let L1 : List Nat := (List.range (p ^ K)).map (fun t => (1 + p * u) ^ t % p ^ (K + 1))
  have hUnodup : U.Nodup := List.Pairwise.filter _ List.nodup_range
  have key : ∀ a b, a ≤ b → b < p ^ K →
      (1 + p * u) ^ a % p ^ (K + 1) = (1 + p * u) ^ b % p ^ (K + 1) → a = b := by
    intro a b hab hb h
    have hb' : (1 + p * u) ^ b = (1 + p * u) ^ a * (1 + p * u) ^ (b - a) := by
      rw [← Nat.pow_add]; congr 1; omega
    have h' : ((1 + p * u) ^ a * (1 + p * u) ^ (b - a)) % p ^ (K + 1)
        = ((1 + p * u) ^ a * 1) % p ^ (K + 1) := by rw [← hb', Nat.mul_one]; exact h.symm
    have h'' := mod_cancel_mul_left (Nat.Coprime.pow_right a hcop)
      (Nat.pow_pos (Nat.lt_of_lt_of_le Nat.one_pos (Nat.le_add_right 1 _))) h'
    have h1P : 1 % p ^ (K + 1) = 1 :=
      Nat.mod_eq_of_lt (Nat.lt_of_lt_of_le (by omega) (Nat.le_self_pow (by omega) p))
    rw [h1P] at h''
    have hd := (order_iff hp hp3 hu K (b - a)).1 h''
    have : b - a = 0 := Nat.eq_zero_of_dvd_of_lt hd (by omega)
    omega
  have hL1nodup : L1.Nodup := by
    apply List.pairwise_map.2
    apply List.Pairwise.imp_of_mem _ List.nodup_range
    intro a b ha hb hab heq
    rw [List.mem_range] at ha hb
    rcases Nat.le_total a b with hle | hle
    · exact hab (key a b hle hb heq)
    · exact hab (key b a hle ha heq.symm).symm
  have hL1U : L1 ⊆ U := by
    intro y hy
    rw [List.mem_map] at hy
    obtain ⟨t, _, rfl⟩ := hy
    rw [List.mem_filter, List.mem_range]
    refine ⟨Nat.mod_lt _ hP, ?_⟩
    rw [Nat.mod_mod_of_dvd _ hdv, pow_mod_one (by omega) hc1]; simp
  have hxU : x % p ^ (K + 1) ∈ U := by
    rw [List.mem_filter, List.mem_range]
    refine ⟨Nat.mod_lt _ hP, ?_⟩
    rw [Nat.mod_mod_of_dvd _ hdv, hx]; simp
  have hxL : x % p ^ (K + 1) ∉ L1 := by
    intro h; rw [List.mem_map] at h
    obtain ⟨t, ht, he⟩ := h
    exact hno ⟨t, List.mem_range.1 ht, he⟩
  have hsub : (x % p ^ (K + 1) :: L1) ⊆ U := by
    intro y hy
    rcases List.mem_cons.1 hy with h | h
    · rw [h]; exact hxU
    · exact hL1U h
  have hlen1 := (List.nodup_cons.2 ⟨hxL, hL1nodup⟩).length_le_of_subset hsub
  have hUsub : U ⊆ (List.range (p ^ K)).map (fun j => p * j + 1) := by
    intro y hy
    rw [List.mem_filter, List.mem_range] at hy
    obtain ⟨hy1, hy2⟩ := hy
    have hy2' : y % p = 1 := by simpa using hy2
    rw [List.mem_map]
    refine ⟨y / p, List.mem_range.2 ((Nat.div_lt_iff_lt_mul (by omega)).2 (by rw [← hPe, Nat.mul_comm] at *; rw [Nat.mul_comm]; rwa [hPe] at hy1)), ?_⟩
    have := Nat.div_add_mod y p; omega
  have hlen2 : U.length ≤ p ^ K := by
    have := hUnodup.length_le_of_subset hUsub; simpa using this
  have hL1len : L1.length = p ^ K := by simp [L1]
  simp only [List.length_cons] at hlen1
  omega

end Gen
