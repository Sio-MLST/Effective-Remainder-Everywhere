import PX1

namespace PX

def PrimeLike (p : Nat) : Prop := ∀ N, N % p ≠ 0 → Nat.Coprime p N

section Words
variable (p : Nat)

def oneCount : List Nat → Nat
  | [] => 0
  | e :: u => oneCount u + e

def offset : List Nat → Nat
  | [] => 0
  | e :: u => p ^ oneCount u * e + 2 * offset u

theorem collatz_odd [Base p] (y : Nat) :
    collatz p (2 * y + 1) = 2 * (p * y + (p + 1) / 2) := by
  have := Base.odd (p := p)
  unfold collatz
  rw [ite_eq_right (by omega)]
  have h : p + 1 = 2 * ((p + 1) / 2) := by omega
  generalize (p + 1) / 2 = c at h ⊢
  grind

theorem integrality [Base p] : ∀ (u : List Nat), (∀ e ∈ u, e ≤ 1) → ∀ x : Nat,
    2 ^ u.length ∣ p ^ oneCount u * x + offset p u →
    ∃ k, iter (collatz p) k x = (p ^ oneCount u * x + offset p u) / 2 ^ u.length
  | [], _, x, _ => ⟨0, by simp [oneCount, offset, iter]⟩
  | e :: u, hu, x, h => by
    have he : e = 0 ∨ e = 1 := by have := hu e (by simp); omega
    have hu' : ∀ d ∈ u, d ≤ 1 := fun d hd => hu d (by simp [hd])
    have hp : p ^ oneCount u % 2 = 1 := powp_odd p _
    have hc : p + 1 = 2 * ((p + 1) / 2) := by have := Base.odd (p := p); omega
    have h2 : 2 ∣ 2 ^ (u.length + 1) := ⟨2 ^ u.length, by grind⟩
    have hpow : 2 ^ (u.length + 1) = 2 * 2 ^ u.length := by grind
    simp only [List.length_cons, oneCount, offset] at h ⊢
    rcases he with rfl | rfl
    · have h0 := Nat.dvd_trans h2 h
      obtain ⟨y, hy | hy⟩ : ∃ y, x = 2 * y ∨ x = 2 * y + 1 := ⟨x / 2, by omega⟩
      · subst hy
        have hn : p ^ (oneCount u + 0) * (2 * y) + (p ^ oneCount u * 0 + 2 * offset p u)
            = 2 * (p ^ oneCount u * y + offset p u) := by grind
        rw [hn, hpow] at h
        have h' := (Nat.mul_dvd_mul_iff_left (by omega : 0 < 2)).1 h
        obtain ⟨k, hk⟩ := integrality u hu' y h'
        refine ⟨k + 1, ?_⟩
        show iter (collatz p) k (collatz p (2 * y)) = _
        rw [collatz_double, hk, hn, hpow, Nat.mul_div_mul_left _ _ (by omega : 0 < 2)]
      · subst hy
        exfalso
        have hn : p ^ (oneCount u + 0) * (2 * y + 1) + (p ^ oneCount u * 0 + 2 * offset p u)
            = 2 * (p ^ oneCount u * y + offset p u) + p ^ oneCount u := by grind
        rw [hn] at h0
        generalize p ^ oneCount u * y + offset p u = P at h0
        omega
    · have h0 := Nat.dvd_trans h2 h
      obtain ⟨y, hy | hy⟩ : ∃ y, x = 2 * y ∨ x = 2 * y + 1 := ⟨x / 2, by omega⟩
      · subst hy
        exfalso
        have hn : p ^ (oneCount u + 1) * (2 * y) + (p ^ oneCount u * 1 + 2 * offset p u)
            = 2 * (p ^ oneCount u * (p * y) + offset p u) + p ^ oneCount u := by grind
        rw [hn] at h0
        generalize p ^ oneCount u * (p * y) + offset p u = P at h0
        omega
      · subst hy
        have hn : p ^ (oneCount u + 1) * (2 * y + 1) + (p ^ oneCount u * 1 + 2 * offset p u)
            = 2 * (p ^ oneCount u * (p * y + (p + 1) / 2) + offset p u) := by
          rw [Nat.pow_succ]
          generalize (p + 1) / 2 = c at hc ⊢
          grind
        rw [hn, hpow] at h
        have h' := (Nat.mul_dvd_mul_iff_left (by omega : 0 < 2)).1 h
        obtain ⟨k, hk⟩ := integrality u hu' (p * y + (p + 1) / 2) h'
        refine ⟨k + 2, ?_⟩
        show iter (collatz p) k (collatz p (collatz p (2 * y + 1))) = _
        rw [collatz_odd, collatz_double, hk, hn, hpow, Nat.mul_div_mul_left _ _ (by omega : 0 < 2)]

theorem integrality_reaches [Base p] (u : List Nat) (hu : ∀ e ∈ u, e ≤ 1) (x : Nat)
    (h : 2 ^ u.length ∣ p ^ oneCount u * x + offset p u) :
    Reaches p ((p ^ oneCount u * x + offset p u) / 2 ^ u.length) x := integrality p u hu x h

theorem oneCount_le : ∀ u : List Nat, (∀ e ∈ u, e ≤ 1) → oneCount u ≤ u.length
  | [], _ => by simp [oneCount]
  | e :: u, hu => by
    have h1 := oneCount_le u (fun d hd => hu d (by simp [hd]))
    have h2 := hu e (by simp)
    simp only [oneCount, List.length_cons]; omega

theorem offset_le [Base p] : ∀ u : List Nat, (∀ e ∈ u, e ≤ 1) → offset p u ≤ (2 * p) ^ u.length
  | [], _ => by simp [offset]
  | e :: u, hu => by
    have hu' : ∀ d ∈ u, d ≤ 1 := fun d hd => hu d (by simp [hd])
    have ih := offset_le u hu'
    have hj := oneCount_le u hu'
    have h3 : p ^ oneCount u ≤ p ^ u.length :=
      Nat.pow_le_pow_right (by have := Base.three_le (p := p); omega) hj
    have h36 : p ^ u.length ≤ (2 * p) ^ u.length := Nat.pow_le_pow_left (by omega) _
    have he := hu e (by simp)
    have h6 : (2 * p) ^ (u.length + 1) = (2 * p) ^ u.length * (2 * p) := Nat.pow_succ ..
    have h8 := Nat.mul_le_mul_left ((2 * p) ^ u.length)
      (show 3 ≤ 2 * p by have := Base.three_le (p := p); omega)
    have h7 : p ^ oneCount u * e ≤ p ^ oneCount u := by
      rcases (by omega : e = 0 ∨ e = 1) with rfl | rfl <;> simp
    simp only [offset, List.length_cons]
    rw [h6]
    omega

theorem parity_word [Base p] : ∀ (a r : Nat), ∃ q : List Nat, q.length = a ∧ (∀ e ∈ q, e ≤ 1) ∧
    2 ^ a ∣ p ^ oneCount q * r + offset p q
  | 0, r => ⟨[], rfl, by simp, by simp [oneCount, offset]⟩
  | a + 1, r => by
    obtain ⟨y, hy | hy⟩ : ∃ y, r = 2 * y ∨ r = 2 * y + 1 := ⟨r / 2, by omega⟩
    · obtain ⟨q, hl, hq, hd⟩ := parity_word a y
      refine ⟨0 :: q, by simp [hl], ?_, ?_⟩
      · intro e he
        rcases List.mem_cons.1 he with rfl | he
        · omega
        · exact hq e he
      · have h2 := Nat.mul_dvd_mul_left 2 hd
        rw [hy]
        have e1 : p ^ oneCount (0 :: q) * (2 * y) + offset p (0 :: q) = 2 * (p ^ oneCount q * y + offset p q) := by
          simp only [oneCount, offset, Nat.add_zero, Nat.mul_zero]; grind
        rw [e1, show 2 ^ (a + 1) = 2 * 2 ^ a by rw [Nat.pow_succ]; grind]
        exact h2
    · have hc : p + 1 = 2 * ((p + 1) / 2) := by have := Base.odd (p := p); omega
      obtain ⟨q, hl, hq, hd⟩ := parity_word a (p * y + (p + 1) / 2)
      refine ⟨1 :: q, by simp [hl], ?_, ?_⟩
      · intro e he
        rcases List.mem_cons.1 he with rfl | he
        · omega
        · exact hq e he
      · have h2 := Nat.mul_dvd_mul_left 2 hd
        rw [hy]
        have e1 : p ^ oneCount (1 :: q) * (2 * y + 1) + offset p (1 :: q)
            = 2 * (p ^ oneCount q * (p * y + (p + 1) / 2) + offset p q) := by
          simp only [oneCount, offset]
          rw [Nat.pow_succ]
          generalize (p + 1) / 2 = c at hc ⊢
          grind
        rw [e1, show 2 ^ (a + 1) = 2 * 2 ^ a by rw [Nat.pow_succ]; grind]
        exact h2

theorem reaches_pow2 [Base p] (w : Nat) : ∀ n, Reaches p w (2 ^ n * w)
  | 0 => ⟨0, by simp [iter]⟩
  | n + 1 => by
    obtain ⟨k, hk⟩ := reaches_pow2 w n
    refine ⟨k + 1, ?_⟩
    rw [iter_add]
    show iter (collatz p) k (collatz p (2 ^ (n + 1) * w)) = w
    rw [show 2 ^ (n + 1) * w = 2 * (2 ^ n * w) by rw [Nat.pow_succ]; grind, collatz_double]; exact hk

end Words

theorem mod_lin {Q a b : Nat} (c d : Nat) (h : a % Q = b % Q) : (c * a + d) % Q = (c * b + d) % Q := by
  rw [Nat.add_mod, Nat.mul_mod, h, ← Nat.mul_mod, ← Nat.add_mod]

theorem closure_word (p Q w : Nat) {x : Nat} (h : Closure p Q w x) :
    ∃ (u : List Nat) (k : Nat), (∀ e ∈ u, e ≤ 1) ∧
      (p ^ oneCount u * x + offset p u) % Q = (2 ^ (u.length + k) * w) % Q := by
  induction h with
  | base k x hx => exact ⟨[], k, by simp, by unfold SameMod at hx; simpa [oneCount, offset] using hx⟩
  | @dbl z hz ih =>
    obtain ⟨u, k, hu, h⟩ := ih
    refine ⟨0 :: u, k, ?_, ?_⟩
    · intro e he
      rcases List.mem_cons.1 he with rfl | he
      · omega
      · exact hu e he
    · have hh := mod_lin 2 0 h
      have e1 : p ^ oneCount (0 :: u) * (2 * z) + offset p (0 :: u) = 2 * (p ^ oneCount u * z + offset p u) + 0 := by
        simp only [oneCount, offset, Nat.add_zero, Nat.mul_zero]; grind
      have e2 : 2 ^ ((0 :: u).length + k) * w = 2 * (2 ^ (u.length + k) * w) + 0 := by
        rw [List.length_cons, show u.length + 1 + k = (u.length + k) + 1 by omega, Nat.pow_succ]; grind
      rw [e1, e2]; exact hh
  | @undo z x hz hx ih =>
    obtain ⟨u, k, hu, h⟩ := ih
    refine ⟨1 :: u, k, ?_, ?_⟩
    · intro e he
      rcases List.mem_cons.1 he with rfl | he
      · omega
      · exact hu e he
    · have hh := mod_lin 2 0 h
      have hx' := mod_lin (p ^ oneCount u) (2 * offset p u) (show (p * x + 1) % Q = (2 * z) % Q from hx)
      have e1 : p ^ oneCount (1 :: u) * x + offset p (1 :: u) = p ^ oneCount u * (p * x + 1) + 2 * offset p u := by
        simp only [oneCount, offset]; grind
      have e3 : p ^ oneCount u * (2 * z) + 2 * offset p u = 2 * (p ^ oneCount u * z + offset p u) + 0 := by grind
      have e2 : 2 ^ ((1 :: u).length + k) * w = 2 * (2 ^ (u.length + k) * w) + 0 := by
        rw [List.length_cons, show u.length + 1 + k = (u.length + k) + 1 by omega, Nat.pow_succ]; grind
      rw [e1, e2]
      exact hx'.trans (by rw [e3]; exact hh)
  | @cong z x hz hx ih =>
    obtain ⟨u, k, hu, h⟩ := ih
    exact ⟨u, k, hu, (mod_lin (p ^ oneCount u) (offset p u) (show x % Q = z % Q from hx)).trans h⟩

section Short
variable (p Q w : Nat)

def HasWord (n x : Nat) : Prop :=
  ∃ (u : List Nat) (k : Nat), (∀ e ∈ u, e ≤ 1) ∧ u.length ≤ n ∧
    (p ^ oneCount u * x + offset p u) % Q = (2 ^ (u.length + k) * w) % Q

theorem hasWord_mono {n x : Nat} (h : HasWord p Q w n x) : HasWord p Q w (n + 1) x := by
  obtain ⟨u, k, hu, hl, he⟩ := h
  exact ⟨u, k, hu, by omega, he⟩

theorem hasWord_le {a b x : Nat} (h : a ≤ b) (hx : HasWord p Q w a x) : HasWord p Q w b x := by
  obtain ⟨d, rfl⟩ : ∃ d, b = a + d := ⟨b - a, by omega⟩
  induction d with
  | zero => exact hx
  | succ d ih => exact hasWord_mono p Q w (ih (by omega))

theorem hasWord_mod {n x : Nat} : HasWord p Q w n x ↔ HasWord p Q w n (x % Q) := by
  constructor
  · rintro ⟨u, k, hu, hl, he⟩
    exact ⟨u, k, hu, hl, (mod_lin (p ^ oneCount u) (offset p u) (Nat.mod_mod x Q)).trans he⟩
  · rintro ⟨u, k, hu, hl, he⟩
    exact ⟨u, k, hu, hl, (mod_lin (p ^ oneCount u) (offset p u) (Nat.mod_mod x Q).symm).trans he⟩

theorem hasWord_base {x k : Nat} (h : x % Q = (2 ^ k * w) % Q) : HasWord p Q w 0 x :=
  ⟨[], k, by simp, by simp, by simpa [oneCount, offset] using h⟩

theorem hasWord_step {n x y ε : Nat} (hε : ε ≤ 1) (hy : HasWord p Q w n y)
    (h : (2 * y) % Q = (p ^ ε * x + ε) % Q) : HasWord p Q w (n + 1) x := by
  obtain ⟨u, k, hu, hl, he⟩ := hy
  refine ⟨ε :: u, k, ?_, by simp; omega, ?_⟩
  · intro e he'
    rcases List.mem_cons.1 he' with rfl | he'
    · exact hε
    · exact hu e he'
  · have hx' := mod_lin (p ^ oneCount u) (2 * offset p u) (show (p ^ ε * x + ε) % Q = (2 * y) % Q from h.symm)
    have hh := mod_lin 2 0 he
    have e1 : p ^ oneCount (ε :: u) * x + offset p (ε :: u) = p ^ oneCount u * (p ^ ε * x + ε) + 2 * offset p u := by
      simp only [oneCount, offset, Nat.pow_add]; grind
    have e3 : p ^ oneCount u * (2 * y) + 2 * offset p u = 2 * (p ^ oneCount u * y + offset p u) + 0 := by grind
    have e2 : 2 ^ ((ε :: u).length + k) * w = 2 * (2 ^ (u.length + k) * w) + 0 := by
      rw [List.length_cons, show u.length + 1 + k = (u.length + k) + 1 by omega, Nat.pow_succ]; grind
    rw [e1, e2]
    exact hx'.trans (by rw [e3]; exact hh)

theorem hasWord_inv (hQ2 : Q % 2 = 1) {n x : Nat} (h : HasWord p Q w (n + 1) x) :
    HasWord p Q w 0 x ∨ ∃ ε, ε ≤ 1 ∧ ∃ y, HasWord p Q w n y ∧ (2 * y) % Q = (p ^ ε * x + ε) % Q := by
  have hcop : Nat.Coprime Q 2 := by
    unfold Nat.Coprime; rw [Nat.gcd_comm, Nat.gcd_rec, hQ2]; simp
  obtain ⟨u, k, hu, hl, he⟩ := h
  cases u with
  | nil => left; exact hasWord_base p Q w (k := k) (by simpa [oneCount, offset] using he)
  | cons ε u' =>
    right
    refine ⟨ε, hu ε (by simp), ((Q + 1) / 2) * (p ^ ε * x + ε), ?_, ?_⟩
    · have h2y : (2 * (((Q + 1) / 2) * (p ^ ε * x + ε))) % Q = (p ^ ε * x + ε) % Q := by
        have : 2 * (((Q + 1) / 2) * (p ^ ε * x + ε)) = (p ^ ε * x + ε) + Q * (p ^ ε * x + ε) := by
          have h2 : 2 * ((Q + 1) / 2) = Q + 1 := by omega
          rw [← Nat.mul_assoc, h2]; grind
        rw [this, Nat.add_mul_mod_self_left]
      refine ⟨u', k, fun e he' => hu e (by simp [he']), by simp at hl; omega, ?_⟩
      have e1 : p ^ oneCount (ε :: u') * x + offset p (ε :: u') = p ^ oneCount u' * (p ^ ε * x + ε) + 2 * offset p u' := by
        simp only [oneCount, offset, Nat.pow_add]; grind
      have e2 : 2 ^ ((ε :: u').length + k) * w = 2 * (2 ^ (u'.length + k) * w) := by
        rw [List.length_cons, show u'.length + 1 + k = (u'.length + k) + 1 by omega, Nat.pow_succ]; grind
      rw [e1, e2] at he
      have hz := mod_lin (p ^ oneCount u') (2 * offset p u')
        (show (p ^ ε * x + ε) % Q = (2 * (((Q + 1) / 2) * (p ^ ε * x + ε))) % Q from h2y.symm)
      have hA : ((p ^ oneCount u' * (((Q + 1) / 2) * (p ^ ε * x + ε)) + offset p u') * 2) % Q
          = ((2 ^ (u'.length + k) * w) * 2) % Q := by
        have e3 : (p ^ oneCount u' * (((Q + 1) / 2) * (p ^ ε * x + ε)) + offset p u') * 2
            = p ^ oneCount u' * (2 * (((Q + 1) / 2) * (p ^ ε * x + ε))) + 2 * offset p u' := by grind
        have e4 : (2 ^ (u'.length + k) * w) * 2 = 2 * (2 ^ (u'.length + k) * w) := by grind
        rw [e3, e4]; exact hz.symm.trans he
      exact mod_cancel_mul_right hcop hA
    · have h2 : 2 * (((Q + 1) / 2) * (p ^ ε * x + ε)) = (p ^ ε * x + ε) + Q * (p ^ ε * x + ε) := by
        have h2' : 2 * ((Q + 1) / 2) = Q + 1 := by omega
        rw [← Nat.mul_assoc, h2']; grind
      rw [h2, Nat.add_mul_mod_self_left]

theorem cardinality_le_modulus {Q : Nat} (S : Fin Q → Prop) : cardinality S ≤ Q := by
  classical
  unfold cardinality
  calc ((List.finRange Q).filter (fun t => decide (S t))).length ≤ (List.finRange Q).length :=
        List.length_filter_le _ _
    _ = Q := List.length_finRange

theorem hasWord_stable [NeZero Q] :
    ∃ n, n ≤ Q ∧ ∀ t : Fin Q, HasWord p Q w (n + 1) t.val → HasWord p Q w n t.val := by
  apply Classical.byContradiction
  intro hno
  have hno' : ∀ n, n ≤ Q → ∃ t : Fin Q, HasWord p Q w (n + 1) t.val ∧ ¬ HasWord p Q w n t.val := by
    intro n hn
    apply Classical.byContradiction
    intro hc
    exact hno ⟨n, hn, fun t ht => Classical.byContradiction fun h => hc ⟨t, ht, h⟩⟩
  have hc : ∀ n, n ≤ Q + 1 → n + 1 ≤ cardinality (fun t : Fin Q => HasWord p Q w n t.val) := by
    intro n
    induction n with
    | zero =>
      intro _
      exact cardinality_pos (t0 := ⟨w % Q, Nat.mod_lt _ (Nat.pos_of_ne_zero (NeZero.ne Q))⟩)
        (hasWord_base p Q w (k := 0) (by simp))
    | succ n ih =>
      intro hn
      obtain ⟨t, h1, h2⟩ := hno' n (by omega)
      have hlt : cardinality (fun t : Fin Q => HasWord p Q w n t.val) < cardinality (fun t : Fin Q => HasWord p Q w (n + 1) t.val) := by
        apply Classical.byContradiction
        intro hge
        exact h2 (cardinality_eq_of_sub (S := fun t : Fin Q => HasWord p Q w n t.val)
          (T := fun t : Fin Q => HasWord p Q w (n + 1) t.val) (fun t h => hasWord_mono p Q w h)
          (Nat.le_of_not_lt hge) t h1)
      have := ih (by omega)
      omega
  have h1 := hc (Q + 1) (Nat.le_refl _)
  have h2 := cardinality_le_modulus (Q := Q) (fun t : Fin Q => HasWord p Q w (Q + 1) t.val)
  omega

theorem hasWord_all_short [NeZero Q] (hQ2 : Q % 2 = 1) (hall : ∀ x, ∃ n, HasWord p Q w n x) :
    ∀ x, HasWord p Q w Q x := by
  obtain ⟨n, hnQ, hst⟩ := hasWord_stable p Q w
  have hQpos : 0 < Q := Nat.pos_of_ne_zero (NeZero.ne Q)
  have hst' : ∀ x, HasWord p Q w (n + 1) x → HasWord p Q w n x := by
    intro x hx
    have := hst ⟨x % Q, Nat.mod_lt _ hQpos⟩ ((hasWord_mod p Q w).1 hx)
    exact (hasWord_mod p Q w).2 this
  have hstab : ∀ d x, HasWord p Q w (n + d) x → HasWord p Q w n x := by
    intro d
    induction d with
    | zero => exact fun x h => h
    | succ d ih =>
      intro x hx
      rcases hasWord_inv p Q w hQ2 (show HasWord p Q w (n + d + 1) x from hx) with h0 | ⟨ε, hε, y, hy, h⟩
      · exact hasWord_le p Q w (Nat.zero_le n) h0
      · exact hst' x (hasWord_step p Q w hε (ih y hy) h)
  intro x
  obtain ⟨m, hm⟩ := hall x
  by_cases hnm : n ≤ m
  · obtain ⟨d, rfl⟩ : ∃ d, m = n + d := ⟨m - n, by omega⟩
    exact hasWord_le p Q w hnQ (hstab d x hm)
  · exact hasWord_le p Q w (by omega) hm

end Short

theorem closure_word_short (p : Nat) [Base p] (M K w : Nat) [NeZero M] (hM : Nat.Coprime M (2 * p))
    (hw : ∃ i, w % p = 2 ^ i % p) (x : Nat) :
    ∃ (u : List Nat) (k : Nat), (∀ e ∈ u, e ≤ 1) ∧ u.length ≤ p ^ (K + 1) * M ∧
      (p ^ oneCount u * x + offset p u) % (p ^ (K + 1) * M) = (2 ^ (u.length + k) * w) % (p ^ (K + 1) * M) := by
  haveI : NeZero (p ^ (K + 1) * M) :=
    ⟨Nat.ne_of_gt (Nat.mul_pos (powp_pos p _) (Nat.pos_of_ne_zero (NeZero.ne M)))⟩
  have hM2 : M % 2 = 1 := by
    apply Classical.byContradiction
    intro h
    have h2 : 2 ∣ M := Nat.dvd_of_mod_eq_zero (by omega)
    have := Nat.Coprime.eq_one_of_dvd (Nat.Coprime.symm (cop_M_two hM)) h2
    omega
  have hQ2 : (p ^ (K + 1) * M) % 2 = 1 := by
    rw [Nat.mul_mod, powp_odd p, hM2]
  have hall : ∀ x, ∃ n, HasWord p (p ^ (K + 1) * M) w n x := by
    intro x
    obtain ⟨u, k, hu, h⟩ := closure_word p _ w (closure_all p M K w hM hw x)
    exact ⟨u.length, u, k, hu, Nat.le_refl _, h⟩
  exact hasWord_all_short p _ w hQ2 hall x

theorem exists_pow2_period (M : Nat) (hM : 0 < M) (hc : Nat.Coprime M 2) :
    ∃ D, 0 < D ∧ D ≤ M ∧ 2 ^ D % M = 1 % M := by
  apply Classical.byContradiction
  intro hno
  have hinj : ∀ a b, a < b → b ≤ M → 2 ^ a % M ≠ 2 ^ b % M := by
    intro a b hab hb heq
    apply hno
    refine ⟨b - a, by omega, by omega, ?_⟩
    have hcop : Nat.Coprime M (2 ^ a) := Nat.Coprime.pow_right _ hc
    exact mod_cancel_mul_right (x := 2 ^ (b - a)) (y := 1) hcop
      (by rw [← Nat.pow_add, Nat.sub_add_cancel (by omega), Nat.one_mul]; exact heq.symm)
  have hnd : ((List.range (M + 1)).map (fun i => 2 ^ i % M)).Nodup := by
    apply List.pairwise_map.2
    apply List.Pairwise.imp_of_mem _ List.nodup_range
    intro a b ha hb hab
    rw [List.mem_range] at ha hb
    rcases Nat.lt_or_gt_of_ne hab with h | h
    · exact hinj a b h (by omega)
    · exact fun h' => hinj b a h (by omega) h'.symm
  have hsub : ((List.range (M + 1)).map (fun i => 2 ^ i % M)) ⊆ List.range M := by
    intro v hv
    rw [List.mem_map] at hv
    obtain ⟨i, _, rfl⟩ := hv
    rw [List.mem_range]; exact Nat.mod_lt _ hM
  have := hnd.length_le_of_subset hsub
  simp at this
  omega

theorem split_p (p : Nat) [Base p] (D : Nat) (hD : 0 < D) : ∃ ν d, D = p ^ ν * d ∧ d % p ≠ 0 := by
  have hp3 := Base.three_le (p := p)
  induction D using Nat.strongRecOn with
  | _ D ih =>
    by_cases h : D % p = 0
    · have hDp : p * (D / p) = D := Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero h)
      have hpos : 0 < D / p := Nat.pos_of_ne_zero fun h0 => by rw [h0] at hDp; omega
      obtain ⟨ν, d, hd, h3⟩ := ih (D / p) (Nat.div_lt_self hD (by omega)) hpos
      refine ⟨ν + 1, d, ?_, h3⟩
      rw [← hDp, hd, Nat.pow_succ]; grind
    · exact ⟨0, D, by simp, h⟩

theorem coprime2p_of_not_dvd (p : Nat) [Base p] (hpr : PrimeLike p) (N : Nat)
    (h2 : N % 2 ≠ 0) (hp : N % p ≠ 0) : Nat.Coprime N (2 * p) := by
  apply Nat.Coprime.mul_right _ (hpr N hp).symm
  unfold Nat.Coprime; rw [Nat.gcd_comm, Nat.gcd_rec, show N % 2 = 1 by omega]; rfl

theorem split_two_p (p : Nat) [Base p] (hpr : PrimeLike p) (N : Nat) (hN : 1 ≤ N) :
    ∃ a b M, N = 2 ^ a * p ^ b * M ∧ Nat.Coprime M (2 * p) := by
  have hp3 := Base.three_le (p := p)
  induction N using Nat.strongRecOn with
  | _ N ih =>
    by_cases h2 : N % 2 = 0
    · obtain ⟨a, b, M, hM, hc⟩ := ih (N / 2) (by omega) (by omega)
      refine ⟨a + 1, b, M, ?_, hc⟩
      have : N = 2 * (N / 2) := by omega
      rw [this, hM, Nat.pow_succ]; grind
    · by_cases h5 : N % p = 0
      · have hNp : p * (N / p) = N := Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero h5)
        have hpos : 1 ≤ N / p := Nat.pos_of_ne_zero fun h0 => by rw [h0] at hNp; omega
        obtain ⟨a, b, M, hM, hc⟩ := ih (N / p) (Nat.div_lt_self (by omega) (by omega)) hpos
        refine ⟨a, b + 1, M, ?_, hc⟩
        rw [← hNp, hM, Nat.pow_succ p b]; grind
      · exact ⟨0, 0, N, by simp, coprime2p_of_not_dvd p hpr N h2 h5⟩

section Lift
variable (p : Nat) [Base p]

theorem mod_mul_right_cong {Q a b : Nat} (c : Nat) (h : a % Q = b % Q) :
    (a * c) % Q = (b * c) % Q := by
  rw [Nat.mul_mod, h, ← Nat.mul_mod]

end Lift

theorem cop_w (p : Nat) [Base p] {w : Nat} (hw : ∃ i, w % p = 2 ^ i % p) : Nat.Coprime p w := by
  obtain ⟨i, hi⟩ := hw
  have h : Nat.Coprime p (2 ^ i) := Nat.Coprime.pow_right i (coprime_p_two p)
  unfold Nat.Coprime at h ⊢
  rw [Nat.gcd_rec, hi, ← Nat.gcd_rec]; exact h

theorem exp_lift_cong (p : Nat) [Base p] (K j w Z κ : Nat) (hw : ∃ i, w % p = 2 ^ i % p)
    (hZ : Z % p ^ (K + 1) = (2 ^ κ * w) % p ^ (K + 1)) :
    ∃ x, x % p ^ (K + 1) = 1 % p ^ (K + 1) ∧ (2 ^ κ * w * x) % p ^ (K + j + 1) = Z % p ^ (K + j + 1) := by
  haveI : NeZero (p ^ (K + j + 1)) := ⟨Nat.pos_iff_ne_zero.1 (powp_pos p _)⟩
  have hcp : Nat.Coprime p (2 ^ κ * w) :=
    Nat.Coprime.mul_right (Nat.Coprime.pow_right κ (coprime_p_two p)) (cop_w p hw)
  obtain ⟨b, hb⟩ := exists_inv_residue (M := p ^ (K + j + 1)) (2 ^ κ * w) (Nat.Coprime.pow_left _ hcp)
  have hb' : (2 ^ κ * w * b.val) % p ^ (K + j + 1) = 1 % p ^ (K + j + 1) := by
    rw [← residue_eq_iff, residue_mul, residue_self_val, hb]; rfl
  have hZb : ∀ Q, Q ∣ p ^ (K + j + 1) → (Z * (2 ^ κ * w * b.val)) % Q = Z % Q := by
    intro Q hQ
    rw [Nat.mul_mod, mod_of_dvd_mod hQ hb', ← Nat.mul_mod, Nat.mul_one]
  refine ⟨Z * b.val, ?_, ?_⟩
  · have hd : p ^ (K + 1) ∣ p ^ (K + j + 1) := Nat.pow_dvd_pow p (by omega)
    apply mod_cancel_mul_right (Nat.Coprime.pow_left (K + 1) hcp)
    rw [Nat.one_mul, ← hZ, ← hZb _ hd]; congr 1; grind
  · rw [← hZb _ (Nat.dvd_refl _)]; congr 1; grind

theorem exp_lift_t (p : Nat) [Base p] {u : Nat} (hu : Nat.Coprime p u) (K j x : Nat)
    (hx : x % p ^ (K + 1) = 1 % p ^ (K + 1)) :
    ∃ t', t' < p ^ j ∧ (1 + p * u) ^ (p ^ K * t') % p ^ (K + j + 1) = x % p ^ (K + j + 1) := by
  have hxp : x % p = 1 := by
    have := mod_of_dvd_mod (p_dvd_pow p K) hx
    rw [this]
    exact Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)
  obtain ⟨t, ht, hte⟩ := Gen.gen_unit Base.odd Base.three_le hu (K + j) x hxp
  have hdvd : p ^ (K + 1) ∣ p ^ (K + j + 1) := Nat.pow_dvd_pow p (by omega)
  have h1 : (1 + p * u) ^ t % p ^ (K + 1) = 1 := by
    have := mod_of_dvd_mod hdvd hte
    rw [this, hx, one_mod_P p K]
  obtain ⟨t', rfl⟩ := (Gen.order_iff Base.odd Base.three_le hu K t).1 h1
  refine ⟨t', ?_, hte⟩
  rw [Nat.pow_add] at ht
  exact Nat.lt_of_mul_lt_mul_left ht

theorem exp_lift_s (p : Nat) [Base p] (hpr : PrimeLike p) (j t' D' B : Nat) (hD0 : 0 < D') (hD3 : D' % p ≠ 0) :
    ∃ s, B ≤ s ∧ s < D' + D' * B ∧ D' ∣ t' + p ^ j * s := by
  haveI : NeZero D' := ⟨by omega⟩
  have hc : Nat.Coprime D' (p ^ j) := Nat.Coprime.pow_right j (Nat.Coprime.symm (hpr D' hD3))
  obtain ⟨b, hb⟩ := exists_inv_residue (p ^ j) hc
  have hb' : (p ^ j * b.val) % D' = 1 % D' := by
    rw [← residue_eq_iff, residue_mul, residue_self_val, hb]; rfl
  have hdvd : ∀ y, y % D' = (y * (p ^ j * b.val)) % D' := by
    intro y; rw [Nat.mul_mod y, hb', ← Nat.mul_mod, Nat.mul_one]
  refine ⟨(D' - t' % D') * b.val % D' + D' * B, by
    have := Nat.le_mul_of_pos_left B hD0; omega, by
    have := Nat.mod_lt ((D' - t' % D') * b.val) hD0; omega, ?_⟩
  apply Nat.dvd_of_mod_eq_zero
  have ht : t' % D' < D' := Nat.mod_lt _ hD0
  have key : (p ^ j * ((D' - t' % D') * b.val % D')) % D' = (D' - t' % D') % D' := by
    rw [Nat.mul_mod, Nat.mod_mod, ← Nat.mul_mod, hdvd (D' - t' % D')]
    congr 1; grind
  rw [Nat.mul_add, ← Nat.add_assoc, Nat.mul_left_comm, Nat.add_mul_mod_self_left,
    Nat.add_mod, key, Nat.add_mod_mod, Nat.mod_add_mod,
    show t' + (D' - t' % D') = D' * (t' / D' + 1) by have := Nat.div_add_mod t' D'; grind,
    Nat.mul_mod_right]

theorem exp_lift (p : Nat) [Base p] (hpr : PrimeLike p) {d u : Nat} (hd0 : 0 < d) (hd : 2 ^ d = 1 + p * u)
    (hu : Nat.Coprime p u)
    (M K j w Z κ D' B : Nat) (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p)
    (hD0 : 0 < D') (hD3 : D' % p ≠ 0) (hD : 2 ^ (p ^ K * D') % M = 1 % M)
    (hZ : Z % (p ^ (K + 1) * M) = (2 ^ κ * w) % (p ^ (K + 1) * M)) :
    ∃ k, B ≤ k ∧
      k ≤ d * p ^ (K + j) * (κ + 1) + d * p ^ (K + j) * (D' * D' * (d * p ^ (K + j) * (κ + 1))
        + p ^ K * D' * B) ∧
      Z % (p ^ (K + j + 1) * M) = (2 ^ k * w) % (p ^ (K + j + 1) * M) := by
  obtain ⟨x, hx1, hxZ⟩ := exp_lift_cong p K j w Z κ hw (mod_of_dvd_mod (Nat.dvd_mul_right _ _) hZ)
  obtain ⟨t', ht', hte⟩ := exp_lift_t p hu K j x hx1
  obtain ⟨s, hBs, hsl, ⟨c, hc⟩⟩ := exp_lift_s p hpr j t' D' B hD0 hD3
  have hpK := powp_pos p K
  have hpj := powp_pos p j
  have hpow : p ^ (K + j) = p ^ K * p ^ j := Nat.pow_add p K j
  refine ⟨κ + d * p ^ K * (t' + p ^ j * s), ?_, ?_, ?_⟩
  ·
    have : s ≤ d * p ^ K * (t' + p ^ j * s) := by
      have h1 : s ≤ p ^ j * s := Nat.le_mul_of_pos_left s hpj
      have h2 : 1 ≤ d * p ^ K := Nat.mul_pos hd0 hpK
      calc s ≤ t' + p ^ j * s := by omega
        _ ≤ d * p ^ K * (t' + p ^ j * s) := Nat.le_mul_of_pos_left _ h2
    omega
  ·
    have hA : 1 ≤ d * p ^ (K + j) := Nat.mul_pos hd0 (powp_pos p _)
    have e1 : d * p ^ K * (t' + p ^ j * s) = d * p ^ K * t' + d * p ^ (K + j) * s := by
      rw [hpow, Nat.mul_add]; grind
    have e2 : d * p ^ K * t' ≤ d * p ^ (K + j) := by
      rw [hpow, ← Nat.mul_assoc]; exact Nat.mul_le_mul_left _ (Nat.le_of_lt ht')
    have e3 : s ≤ D' + D' * B := Nat.le_of_lt hsl
    have e4 : D' ≤ D' * D' * (d * p ^ (K + j) * (κ + 1)) := by
      have h := Nat.mul_pos hD0 (Nat.mul_pos hA (Nat.succ_pos κ))
      have := Nat.le_mul_of_pos_right D' h
      rw [Nat.mul_assoc D' D']; exact this
    have e5 : D' * B ≤ p ^ K * D' * B := by
      rw [Nat.mul_assoc]; exact Nat.le_mul_of_pos_left _ hpK
    have e6 : d * p ^ (K + j) * s ≤ d * p ^ (K + j) * (D' * D' * (d * p ^ (K + j) * (κ + 1)) + p ^ K * D' * B) :=
      Nat.mul_le_mul_left _ (by omega)
    have e7 : κ + d * p ^ (K + j) ≤ d * p ^ (K + j) * (κ + 1) := by
      rw [Nat.mul_add, Nat.mul_one]; have := Nat.le_mul_of_pos_left κ hA; omega
    omega
  ·
    have hPM : Nat.Coprime (p ^ (K + j + 1)) M :=
      Nat.Coprime.pow_left _ (Nat.Coprime.symm (cop_M_p hM))
    symm
    apply mod_combine hPM
    · have hord : (1 + p * u) ^ (p ^ (K + j) * s) % p ^ (K + j + 1) = 1 :=
        (Gen.order_iff Base.odd Base.three_le hu (K + j) _).2 (Nat.dvd_mul_right _ _)
      have hk : 2 ^ (κ + d * p ^ K * (t' + p ^ j * s)) * w
          = 2 ^ κ * w * (1 + p * u) ^ (p ^ K * t') * (1 + p * u) ^ (p ^ (K + j) * s) := by
        have hex : κ + d * p ^ K * (t' + p ^ j * s) = κ + d * (p ^ K * t') + d * (p ^ (K + j) * s) := by
          rw [hpow]; grind
        rw [hex, Nat.pow_add, Nat.pow_add, Nat.pow_mul 2 d (p ^ K * t'), Nat.pow_mul 2 d (p ^ (K + j) * s), hd]
        ac_rfl
      rw [hk, Nat.mul_mod, hord, Nat.mul_one, Nat.mod_mod, Nat.mul_mod, hte, ← Nat.mul_mod, hxZ]
    · have hk : κ + d * p ^ K * (t' + p ^ j * s) = κ + p ^ K * D' * (d * c) := by
        rw [hc]; grind
      rw [hk, Nat.mul_mod, pow_mod_period hD κ, ← Nat.mul_mod]
      exact (mod_of_dvd_mod (Nat.dvd_mul_left _ _) hZ).symm

theorem pow2bound_mul {x y a b : Nat} (hx : x ≤ 2 ^ a) (hy : y ≤ 2 ^ b) : x * y ≤ 2 ^ (a + b) := by
  rw [Nat.pow_add]; exact Nat.mul_le_mul hx hy
theorem pow2bound_le {x a a' : Nat} (hx : x ≤ 2 ^ a) (h : a ≤ a') : x ≤ 2 ^ a' :=
  Nat.le_trans hx (Nat.pow_le_pow_right (by omega) h)
theorem pow2bound_add {x y a : Nat} (hx : x ≤ 2 ^ a) (hy : y ≤ 2 ^ a) : x + y ≤ 2 ^ (a + 1) := by
  rw [Nat.pow_succ]; omega
theorem pow_le_of_le (p L n : Nat) (hpL : p ≤ 2 ^ L) : p ^ n ≤ 2 ^ (L * n) := by
  rw [Nat.pow_mul]; exact Nat.pow_le_pow_left hpL n
theorem two_p_pow_le (p L n : Nat) (hpL : p ≤ 2 ^ L) : (2 * p) ^ n ≤ 2 ^ ((L + 1) * n) := by
  rw [Nat.pow_mul, Nat.pow_succ, Nat.mul_comm (2 ^ L)]
  exact Nat.pow_le_pow_left (Nat.mul_le_mul_left 2 hpL) n
theorem bound_arith (p L X K jv len d d' κ C B : Nat) (hL : 2 ≤ L) (hpL : p ≤ 2 ^ L) (hX3 : 3 ≤ X)
    (hd : d ≤ p) (hpX : p ≤ X) (hK : p ^ K ≤ X) (hjv : jv ≤ X)
    (hlen : len ≤ X) (hd' : d' ≤ X) (hκ : κ ≤ 2 * X) (hC : C ≤ (2 * p) ^ X) (hB : B ≤ X) :
    d * p ^ (K + jv) * (κ + 1) + d * p ^ (K + jv) * (d' * d' * (d * p ^ (K + jv) * (κ + 1))
      + p ^ K * d' * (C + len + p ^ jv * (B + 1))) ≤ 2 ^ ((3 * L + 7) * X) := by
  have hXp : X < 2 ^ X := Nat.lt_two_pow_self
  have eq1 : (L + 1) * X = L * X + X := by rw [Nat.add_mul, Nat.one_mul]
  have eqT : (3 * L + 7) * X = 3 * (L * X) + 7 * X := by rw [Nat.add_mul, Nat.mul_assoc]
  have hq : 2 * X ≤ L * X := Nat.mul_le_mul_right X hL
  have hpj : p ^ jv ≤ 2 ^ (L * X) :=
    pow2bound_le (pow_le_of_le p L jv hpL) (Nat.mul_le_mul_left L hjv)
  have hCq : C ≤ 2 ^ (L * X + X) := by rw [← eq1]; exact Nat.le_trans hC (two_p_pow_le p L X hpL)
  rw [eqT]
  generalize L * X = q at hpj hCq hq
  have hdX : d ≤ 2 ^ X := by omega
  have hKX : p ^ K ≤ 2 ^ X := by omega
  have hd'X : d' ≤ 2 ^ X := by omega
  have hlX : len ≤ 2 ^ X := by omega
  have hBX : B + 1 ≤ 2 ^ X := by omega
  have hκX : κ + 1 ≤ 2 ^ (2 * X) := by
    have : 2 * X < 2 ^ (2 * X) := Nat.lt_two_pow_self; omega
  have hA : d * p ^ (K + jv) ≤ 2 ^ (X + (X + q)) := by
    rw [Nat.pow_add]; exact pow2bound_mul hdX (pow2bound_mul hKX hpj)
  have h1 : d * p ^ (K + jv) * (κ + 1) ≤ 2 ^ (X + (X + q) + 2 * X) := pow2bound_mul hA hκX
  have h2 : d' * d' * (d * p ^ (K + jv) * (κ + 1)) ≤ 2 ^ (X + X + (X + (X + q) + 2 * X)) :=
    pow2bound_mul (pow2bound_mul hd'X hd'X) h1
  have h3 : p ^ jv * (B + 1) ≤ 2 ^ (q + X) := pow2bound_mul hpj hBX
  have h4 : C + len + p ^ jv * (B + 1) ≤ 2 ^ (q + X + 2) := by
    have a : C + len ≤ 2 ^ (q + X + 1) := pow2bound_add hCq (pow2bound_le hlX (by omega))
    have b : p ^ jv * (B + 1) ≤ 2 ^ (q + X + 1) := pow2bound_le h3 (by omega)
    exact pow2bound_add a b
  have h5 : p ^ K * d' * (C + len + p ^ jv * (B + 1)) ≤ 2 ^ (X + X + (q + X + 2)) :=
    pow2bound_mul (pow2bound_mul hKX hd'X) h4
  have h6 : d' * d' * (d * p ^ (K + jv) * (κ + 1)) + p ^ K * d' * (C + len + p ^ jv * (B + 1))
      ≤ 2 ^ (q + 6 * X + 1) := pow2bound_add (pow2bound_le h2 (by omega)) (pow2bound_le h5 (by omega))
  have h7 := pow2bound_mul hA h6
  exact pow2bound_le (pow2bound_add (pow2bound_le h1 (by omega : _ ≤ X + (X + q) + (q + 6 * X + 1))) h7) (by omega)

theorem pow2_period_lift (p : Nat) [Base p] {d u : Nat} (hd : 2 ^ d = 1 + p * u) (hu : Nat.Coprime p u)
    (M K D' : Nat) (hM : Nat.Coprime M (2 * p)) (hD : 2 ^ (p ^ K * D') % M = 1 % M) :
    2 ^ (d * p ^ K * D') % (p ^ (K + 1) * M) = 1 % (p ^ (K + 1) * M) := by
  apply mod_combine (Nat.Coprime.pow_left _ (Nat.Coprime.symm (cop_M_p hM)))
  · rw [Nat.mul_assoc, Nat.pow_mul, hd, one_mod_P p K]
    exact (Gen.order_iff Base.odd Base.three_le hu K _).2 (Nat.dvd_mul_right _ _)
  · rw [Nat.mul_assoc, Nat.mul_comm d, Nat.pow_mul, Nat.pow_mod, hD, ← Nat.pow_mod, Nat.one_pow]

theorem hit_residue (p : Nat) [Base p] (hpr : PrimeLike p) (L : Nat) (hpL : p ≤ 2 ^ L)
    (M b' e B w X : Nat) (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p)
    (hX : p * (p ^ b' * M * M) ≤ X) (hBX : B ≤ X) :
    ∃ m, B < m ∧ m % (p ^ b' * M) = e % (p ^ b' * M) ∧ Reaches p w m ∧
      m ≤ w * 2 ^ (2 ^ ((3 * L + 7) * X)) := by
  have hp3 := Base.three_le (p := p)
  have hL : 2 ≤ L := Classical.byContradiction fun h => by
    have h2 : 2 ^ L ≤ 2 ^ 1 := Nat.pow_le_pow_right (by omega) (by omega)
    rw [Nat.pow_one] at h2; omega
  have hM0 : 0 < M := by
    rcases Nat.eq_zero_or_pos M with h | h
    · subst h; unfold Nat.Coprime at hM; rw [Nat.gcd_zero_left] at hM; omega
    · exact h
  haveI : NeZero M := ⟨by omega⟩
  obtain ⟨dg, ug, hdg0, hdgp, hdg, hug⟩ := Base.gen (p := p)
  obtain ⟨D, hD0, hDM, hD⟩ := exists_pow2_period M hM0 (cop_M_two hM)
  obtain ⟨ν, d', hDd, hd3⟩ := split_p p D hD0
  obtain ⟨K, hKd⟩ : ∃ K, K = ν + b' := ⟨_, rfl⟩
  have hKν : ν ≤ K := by omega
  have hKb : b' ≤ K + 1 := by omega
  have hd'pos : 1 ≤ d' := by
    rcases Nat.eq_zero_or_pos d' with h | h
    · subst h; omega
    · exact h
  have h3ν : 0 < p ^ ν := powp_pos p ν
  have hper : 2 ^ (p ^ K * d') % M = 1 % M := by
    have e1 : p ^ K = p ^ ν * p ^ (K - ν) := by rw [← Nat.pow_add, Nat.add_sub_cancel' hKν]
    have e2 : p ^ K * d' = D * p ^ (K - ν) := by rw [hDd, e1]; grind
    rw [e2, Nat.pow_mul, Nat.pow_mod, hD, ← Nat.pow_mod, Nat.one_pow]
  have hν3 : p ^ ν ≤ M := by
    have := Nat.le_mul_of_pos_right (p ^ ν) hd'pos
    rw [← hDd] at this; omega
  have hd'M : d' ≤ M := by
    have := Nat.le_mul_of_pos_left d' h3ν
    rw [← hDd] at this; omega
  have hK3 : p ^ K ≤ p ^ b' * M := by
    rw [hKd, Nat.pow_add]
    calc p ^ ν * p ^ b' ≤ M * p ^ b' := Nat.mul_le_mul_right _ hν3
      _ = p ^ b' * M := Nat.mul_comm _ _
  have hS : 0 < p ^ b' * M := Nat.mul_pos (powp_pos p _) hM0
  rw [← Nat.mul_assoc] at hX
  have hSX : p ^ b' * M ≤ X := by
    have h1 := Nat.le_mul_of_pos_right (p * (p ^ b' * M)) hM0
    have h2 := Nat.le_mul_of_pos_left (p ^ b' * M) (show 0 < p by omega)
    omega
  have hMX : M ≤ X := by
    have := Nat.le_mul_of_pos_left M (show 0 < p * (p ^ b' * M) by exact Nat.mul_pos (by omega) hS)
    omega
  have hpX : p ≤ X := by
    have h1 := Nat.le_mul_of_pos_right p hS
    have h2 := Nat.le_mul_of_pos_right (p * (p ^ b' * M)) hM0
    omega
  have hX3 : 3 ≤ X := by omega
  have hQ : p ^ (K + 1) * M = p * p ^ K * M := by rw [Nat.pow_succ]; grind
  have hQX : p ^ (K + 1) * M ≤ X := by
    rw [hQ]
    exact Nat.le_trans (Nat.mul_le_mul_right M (Nat.mul_le_mul_left p hK3)) hX
  have hK3X : p ^ K ≤ X := Nat.le_trans hK3 hSX
  have hd'X : d' ≤ X := Nat.le_trans hd'M hMX
  have hπX : dg * p ^ K * d' ≤ X := by
    have h1 := Nat.mul_le_mul (Nat.mul_le_mul hdgp hK3) hd'M
    exact Nat.le_trans h1 hX
  have hπpos : 0 < dg * p ^ K * d' := Nat.mul_pos (Nat.mul_pos hdg0 (powp_pos p _)) hd'pos
  obtain ⟨u, kk, hu, hlen, hk'⟩ := closure_word_short p M K w hM hw e
  have hlenX : u.length ≤ X := Nat.le_trans hlen hQX
  have hπ := pow2_period_lift p hdg hug M K d' hM hper
  have hkr : (p ^ oneCount u * e + offset p u) % (p ^ (K + 1) * M)
      = (2 ^ (u.length + kk % (dg * p ^ K * d')) * w) % (p ^ (K + 1) * M) := by
    have h1 : 2 ^ (u.length + kk) % (p ^ (K + 1) * M)
        = 2 ^ (u.length + kk % (dg * p ^ K * d')) % (p ^ (K + 1) * M) := by
      have e' : u.length + kk = (u.length + kk % (dg * p ^ K * d')) + (dg * p ^ K * d') * (kk / (dg * p ^ K * d')) := by
        have := Nat.mod_add_div kk (dg * p ^ K * d'); omega
      rw [e']; exact pow_mod_period hπ _ _
    exact hk'.trans (mod_mul_right_cong w h1)
  have hκ : u.length + kk % (dg * p ^ K * d') ≤ 2 * X := by
    have := Nat.mod_lt kk hπpos; omega
  have hw1 : 1 ≤ w := by
    rcases Nat.eq_zero_or_pos w with h | h
    · subst h; have := cop_w p hw; unfold Nat.Coprime at this; rw [Nat.gcd_zero_right] at this; omega
    · exact h
  obtain ⟨k, hk, hkU, hkZ⟩ := exp_lift p hpr hdg0 hdg hug M K (oneCount u) w (p ^ oneCount u * e + offset p u)
    (u.length + kk % (dg * p ^ K * d')) d' (offset p u + u.length + p ^ oneCount u * (B + 1)) hM hw hd'pos hd3 hper hkr
  have hU := bound_arith p L X K (oneCount u) u.length dg d' (u.length + kk % (dg * p ^ K * d')) (offset p u) B
    hL hpL hX3 hdgp hpX hK3X (Nat.le_trans (oneCount_le u hu) hlenX) hlenX hd'X hκ
    (Nat.le_trans (offset_le p u hu) (Nat.pow_le_pow_right (by omega) hlenX)) hBX
  have hkX : k ≤ 2 ^ ((3 * L + 7) * X) := Nat.le_trans hkU hU
  have hbig : offset p u + u.length + p ^ oneCount u * (B + 1) < 2 ^ k * w :=
    Nat.lt_of_le_of_lt hk (Nat.lt_of_lt_of_le Nat.lt_two_pow_self (Nat.le_mul_of_pos_right _ hw1))
  have hj0 : 0 < p ^ oneCount u := powp_pos p _
  have hdv : p ^ oneCount u ∣ p ^ (K + oneCount u + 1) * M :=
    Nat.dvd_trans (Nat.pow_dvd_pow p (by omega)) (Nat.dvd_mul_right _ _)
  have hd : (2 ^ k * w - offset p u) % p ^ oneCount u = 0 := by
    apply Nat.sub_mod_eq_zero_of_mod_eq
    rw [mod_of_dvd_mod hdv hkZ.symm, Nat.add_mod, Nat.mul_mod_right, Nat.zero_add, Nat.mod_mod]
  have hm3 := Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero hd)
  obtain ⟨m, hm⟩ : ∃ m, m = (2 ^ k * w - offset p u) / p ^ oneCount u := ⟨_, rfl⟩
  rw [← hm] at hm3
  rw [Nat.mul_add, Nat.mul_one] at hbig
  have heq : p ^ oneCount u * m + offset p u = 2 ^ k * w := by omega
  have hmB : B < m := by
    apply Classical.byContradiction
    intro hc
    have := Nat.mul_le_mul_left (p ^ oneCount u) (Nat.le_of_not_lt hc)
    omega
  refine ⟨m, hmB, ?_, ?_, ?_⟩
  · have h1 : (offset p u + p ^ oneCount u * m) % (p ^ (K + oneCount u + 1) * M) = (offset p u + p ^ oneCount u * e) % (p ^ (K + oneCount u + 1) * M) := by
      rw [Nat.add_comm (offset p u) (p ^ oneCount u * m), Nat.add_comm (offset p u) (p ^ oneCount u * e), heq]
      exact hkZ.symm
    have h2 := mod_add_left_cancel h1
    have hBig : p ^ (K + oneCount u + 1) * M = p ^ oneCount u * (p ^ (K + 1) * M) := by
      rw [show K + oneCount u + 1 = oneCount u + (K + 1) by omega, Nat.pow_add, Nat.mul_assoc]
    rw [hBig, Nat.mul_mod_mul_left, Nat.mul_mod_mul_left] at h2
    have h3 := Nat.eq_of_mul_eq_mul_left hj0 h2
    exact mod_of_dvd_mod (Nat.mul_dvd_mul_right (Nat.pow_dvd_pow p hKb) M) h3
  · have hak : u.length ≤ k := by omega
    have hdiv : 2 ^ u.length ∣ p ^ oneCount u * m + offset p u :=
      ⟨2 ^ (k - u.length) * w, by rw [heq, ← Nat.mul_assoc, ← Nat.pow_add, Nat.add_sub_cancel' hak]⟩
    have hq : (p ^ oneCount u * m + offset p u) / 2 ^ u.length = 2 ^ (k - u.length) * w := by
      rw [heq, show 2 ^ k * w = 2 ^ u.length * (2 ^ (k - u.length) * w) by
        rw [← Nat.mul_assoc, ← Nat.pow_add, Nat.add_sub_cancel' hak]]
      exact Nat.mul_div_cancel_left _ (Nat.pow_pos (by omega))
    have hr := integrality_reaches p u hu m hdiv
    rw [hq] at hr
    exact reaches_trans p hr (reaches_pow2 p w _)
  · have h1 : m ≤ p ^ oneCount u * m := Nat.le_mul_of_pos_left m hj0
    have h2 : m ≤ 2 ^ k * w := by omega
    have h3 : 2 ^ k ≤ 2 ^ (2 ^ ((3 * L + 7) * X)) := Nat.pow_le_pow_right (by omega) hkX
    calc m ≤ 2 ^ k * w := h2
      _ ≤ 2 ^ (2 ^ ((3 * L + 7) * X)) * w := Nat.mul_le_mul_right w h3
      _ = w * 2 ^ (2 ^ ((3 * L + 7) * X)) := Nat.mul_comm _ _

theorem remainder_bounded (p : Nat) [Base p] (hpr : PrimeLike p) (L : Nat) (hpL : p ≤ 2 ^ L)
    (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : ∃ i, w % p = 2 ^ i % p) (r B : Nat) :
    ∃ n : Nat, B < n ∧ Reaches p w n ∧ n % N = r % N ∧
      n ≤ w * 2 ^ (2 ^ ((3 * L + 8) * (p * N ^ (L + 2) * (B + 1)))) := by
  have hp3 := Base.three_le (p := p)
  obtain ⟨α, b, M, hNd, h6⟩ := split_two_p p hpr N hN
  have hM0 : 0 < M := by
    rcases Nat.eq_zero_or_pos M with h | h
    · subst h; unfold Nat.Coprime at h6; rw [Nat.gcd_zero_left] at h6; omega
    · exact h
  obtain ⟨q, hql, hqe, e, he0⟩ := parity_word p α (r % N)
  have hr0 : r % N < N := Nat.mod_lt _ (by omega)
  have h2pos : 0 < 2 ^ α := Nat.pow_pos (by omega)
  have h3bM : 0 < p ^ b * M := Nat.mul_pos (powp_pos p _) hM0
  have hNe : N = 2 ^ α * (p ^ b * M) := by rw [hNd]; grind
  have h2aN : 2 ^ α ≤ N := by
    rw [hNe]; exact Nat.le_mul_of_pos_right _ h3bM
  have h3bMN : p ^ b * M ≤ N := by
    rw [hNe]; exact Nat.le_mul_of_pos_left _ h2pos
  have hMN : M ≤ N := Nat.le_trans (Nat.le_mul_of_pos_left M (powp_pos p _)) h3bMN
  have h3αN : p ^ α ≤ N ^ L := by
    have h1 := pow_le_of_le p L α hpL
    have h2 : 2 ^ (L * α) = (2 ^ α) ^ L := by rw [Nat.mul_comm, Nat.pow_mul]
    exact Nat.le_trans h1 (by rw [h2]; exact Nat.pow_le_pow_left h2aN L)
  have hjp : oneCount q ≤ α := by have := oneCount_le q hqe; rw [hql] at this; exact this
  have h3jp : p ^ oneCount q ≤ N ^ L :=
    Nat.le_trans (Nat.pow_le_pow_right (by omega) hjp) h3αN
  have hN4 : N ^ (L + 1) = N ^ L * N := Nat.pow_succ N L
  have hN5 : N ^ (L + 2) = N ^ (L + 1) * N := Nat.pow_succ N (L + 1)
  have h13 : N ^ L ≤ N ^ (L + 1) := Nat.pow_le_pow_right (by omega) (by omega)
  have h14 : N ^ (L + 1) ≤ N ^ (L + 2) := Nat.pow_le_pow_right (by omega) (by omega)
  have hS3 : p ^ (oneCount q + b) * M ≤ N ^ (L + 1) := by
    rw [Nat.pow_add, Nat.mul_assoc, hN4]; exact Nat.mul_le_mul h3jp h3bMN
  have hSM : p ^ (oneCount q + b) * M * M ≤ N ^ (L + 2) := by
    rw [hN5]; exact Nat.mul_le_mul hS3 hMN
  have hXe : p * N ^ (L + 2) * (B + 1) = p * (N ^ (L + 2) * B) + p * N ^ (L + 2) := by grind
  have hX : p * (p ^ (oneCount q + b) * M * M) ≤ p * N ^ (L + 2) * (B + 1) := by
    have := Nat.mul_le_mul_left p hSM
    have h2 := Nat.le_mul_of_pos_left (N ^ (L + 2) * B) (show 0 < p by omega)
    omega
  have hcc : offset p q ≤ 2 ^ α * N ^ L := by
    have h1 := offset_le p q hqe
    rw [hql, Nat.mul_pow] at h1
    exact Nat.le_trans h1 (Nat.mul_le_mul (Nat.le_refl _) h3αN)
  have h3r : p ^ oneCount q * (r % N) ≤ N ^ (L + 1) := by
    rw [hN4]; exact Nat.mul_le_mul h3jp (Nat.le_of_lt hr0)
  have h2N3 : 2 ^ α * N ^ L ≤ N ^ (L + 1) := by
    calc 2 ^ α * N ^ L ≤ N * N ^ L := Nat.mul_le_mul_right _ h2aN
      _ = N ^ (L + 1) := by rw [hN4]; grind
  have he1 : e ≤ 2 * N ^ (L + 1) := by
    have h1 : e ≤ 2 ^ α * e := Nat.le_mul_of_pos_left e h2pos
    omega
  have hBX : e + p ^ oneCount q * B ≤ p * N ^ (L + 2) * (B + 1) := by
    have h2 : p ^ oneCount q * B ≤ N ^ (L + 2) * B :=
      Nat.mul_le_mul_right B (Nat.le_trans h3jp (Nat.le_trans h13 h14))
    have h3 := Nat.le_mul_of_pos_left (N ^ (L + 2) * B) (show 0 < p by omega)
    have h4 := Nat.mul_le_mul_right (N ^ (L + 2)) hp3
    omega
  obtain ⟨m, hmB, hmc, hmw, hmbd⟩ :=
    hit_residue p hpr L hpL M (oneCount q + b) e (e + p ^ oneCount q * B) w (p * N ^ (L + 2) * (B + 1)) h6 hw hX hBX
  have hj0 : 0 < p ^ oneCount q := powp_pos p _
  have h0 := Nat.sub_mod_eq_zero_of_mod_eq hmc
  obtain ⟨s, hs⟩ := Nat.dvd_of_mod_eq_zero h0
  have hm' : m = e + p ^ oneCount q * (p ^ b * M * s) := by
    have : m - e = p ^ oneCount q * (p ^ b * M * s) := by rw [hs, Nat.pow_add]; grind
    omega
  have htB : B < p ^ b * M * s := by
    apply Classical.byContradiction
    intro hc
    have := Nat.mul_le_mul_left (p ^ oneCount q) (Nat.le_of_not_lt hc)
    omega
  have htm : p ^ b * M * s ≤ m := by
    have := Nat.le_mul_of_pos_left (p ^ b * M * s) hj0
    omega
  have hn : p ^ oneCount q * (r % N + 2 ^ α * (p ^ b * M * s)) + offset p q
      = 2 ^ α * (e + p ^ oneCount q * (p ^ b * M * s)) := by
    have : p ^ oneCount q * (r % N + 2 ^ α * (p ^ b * M * s)) + offset p q
        = (p ^ oneCount q * (r % N) + offset p q) + 2 ^ α * (p ^ oneCount q * (p ^ b * M * s)) := by grind
    rw [this, he0]; grind
  have hm1 : 1 ≤ m := by omega
  generalize hXdef : p * N ^ (L + 2) * (B + 1) = X at hmbd hXe
  refine ⟨r % N + 2 ^ α * (p ^ b * M * s), ?_, ?_, ?_, ?_⟩
  · have := Nat.le_mul_of_pos_left (p ^ b * M * s) h2pos
    omega
  · have hdiv : 2 ^ q.length ∣ p ^ oneCount q * (r % N + 2 ^ α * (p ^ b * M * s)) + offset p q := by
      rw [hql, hn]; exact Nat.dvd_mul_right _ _
    have hr := integrality_reaches p q hqe _ hdiv
    rw [hql, hn, Nat.mul_div_cancel_left _ h2pos, ← hm'] at hr
    exact reaches_trans p hr hmw
  · rw [show 2 ^ α * (p ^ b * M * s) = N * s by rw [hNe]; grind, Nat.add_mul_mod_self_left, Nat.mod_mod]
  · have hn1 : r % N + 2 ^ α * (p ^ b * M * s) ≤ 2 * (N * m) := by
      have h1 : 2 ^ α * (p ^ b * M * s) ≤ N * m := Nat.mul_le_mul h2aN htm
      have h2 : N ≤ N * m := Nat.le_mul_of_pos_right N hm1
      omega
    have hX1 : N ≤ X := by
      have := Nat.le_self_pow (show L + 2 ≠ 0 by omega) N
      have := Nat.le_mul_of_pos_left (N ^ (L + 2) * B) (show 0 < p by omega)
      have := Nat.mul_le_mul_right (N ^ (L + 2)) hp3
      omega
    have hE8 : (3 * L + 8) * X = (3 * L + 7) * X + X := by rw [Nat.add_mul (3 * L + 7) 1, Nat.one_mul]
    have hE7 : X ≤ (3 * L + 7) * X := Nat.le_mul_of_pos_left X (by omega)
    rw [hE8]
    generalize (3 * L + 7) * X = E at hmbd hE7
    have hN2 : 2 * N ≤ 2 ^ (N + 1) := by
      have := Nat.lt_two_pow_self (n := N)
      rw [Nat.pow_succ]; omega
    have hN1 : N + 1 ≤ 2 ^ E :=
      Nat.le_trans Nat.lt_two_pow_self (Nat.pow_le_pow_right (by omega) (by omega))
    have hexp : N + 1 + 2 ^ E ≤ 2 ^ (E + X) := by
      have h1 : 2 ^ (E + 1) ≤ 2 ^ (E + X) := Nat.pow_le_pow_right (by omega) (by omega)
      have h2 : 2 ^ (E + 1) = 2 ^ E * 2 := Nat.pow_succ 2 _
      omega
    calc r % N + 2 ^ α * (p ^ b * M * s) ≤ 2 * (N * m) := hn1
      _ ≤ 2 * (N * (w * 2 ^ (2 ^ E))) := Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left N hmbd)
      _ = (2 * N) * w * 2 ^ (2 ^ E) := by grind
      _ ≤ 2 ^ (N + 1) * w * 2 ^ (2 ^ E) := Nat.mul_le_mul_right _ (Nat.mul_le_mul_right w hN2)
      _ = w * 2 ^ (N + 1 + 2 ^ E) := by rw [Nat.pow_add]; grind
      _ ≤ w * 2 ^ (2 ^ (E + X)) := Nat.mul_le_mul_left w (Nat.pow_le_pow_right (by omega) hexp)

theorem effective_remainder_everywhere (p : Nat) [Base p] (hpr : PrimeLike p) (L : Nat)
    (hpL : p ≤ 2 ^ L) (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : ∃ i, w % p = 2 ^ i % p) (r : Nat) :
    ∃ n : Nat, Reaches p w n ∧ n % N = r % N ∧
      n ≤ w * 2 ^ (2 ^ ((3 * L + 8) * (p * N ^ (L + 2)))) := by
  obtain ⟨n, _, h1, h2, h3⟩ := remainder_bounded p hpr L hpL N hN w hw r 0
  exact ⟨n, h1, h2, by rw [Nat.zero_add, Nat.mul_one] at h3; exact h3⟩

instance base3 : Base 3 := ⟨by decide, by decide, ⟨2, 1, by decide, by decide, by decide, by decide⟩⟩
instance base5 : Base 5 := ⟨by decide, by decide, ⟨4, 3, by decide, by decide, by decide, by decide⟩⟩

theorem primeLike3 : PrimeLike 3 := by
  intro N hN; unfold Nat.Coprime; rw [Nat.gcd_rec]
  rcases (by omega : N % 3 = 1 ∨ N % 3 = 2) with h | h <;> rw [h] <;> rfl

theorem primeLike5 : PrimeLike 5 := by
  intro N hN; unfold Nat.Coprime; rw [Nat.gcd_rec]
  rcases (by omega : N % 5 = 1 ∨ N % 5 = 2 ∨ N % 5 = 3 ∨ N % 5 = 4) with h | h | h | h <;> rw [h] <;> rfl

theorem bound_mono (w E E' n : Nat) (h : n ≤ w * 2 ^ (2 ^ E)) (hE : E ≤ E') : n ≤ w * 2 ^ (2 ^ E') :=
  Nat.le_trans h (Nat.mul_le_mul_left w (Nat.pow_le_pow_right (by omega) (Nat.pow_le_pow_right (by omega) hE)))

theorem cor_p3 (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : w % 3 ≠ 0) (r : Nat) :
    ∃ n : Nat, Reaches 3 w n ∧ n % N = r % N ∧ n ≤ w * 2 ^ (2 ^ (48 * N ^ 4)) := by
  have hw' : ∃ i, w % 3 = 2 ^ i % 3 := by
    rcases (by omega : w % 3 = 1 ∨ w % 3 = 2) with h | h
    · exact ⟨0, by rw [h]⟩
    · exact ⟨1, by rw [h]⟩
  obtain ⟨n, h1, h2, h3⟩ := effective_remainder_everywhere 3 primeLike3 2 (by decide) N hN w hw' r
  exact ⟨n, h1, h2, bound_mono w _ _ n h3 (by rw [show (2 + 2 : Nat) = 4 from rfl]; omega)⟩

theorem cor_p5 (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : w % 5 ≠ 0) (r : Nat) :
    ∃ n : Nat, Reaches 5 w n ∧ n % N = r % N ∧ n ≤ w * 2 ^ (2 ^ (105 * N ^ 5)) := by
  have hw' : ∃ i, w % 5 = 2 ^ i % 5 := by
    rcases (by omega : w % 5 = 1 ∨ w % 5 = 2 ∨ w % 5 = 3 ∨ w % 5 = 4) with h | h | h | h
    · exact ⟨0, by rw [h]⟩
    · exact ⟨1, by rw [h]⟩
    · exact ⟨3, by rw [h]⟩
    · exact ⟨2, by rw [h]⟩
  obtain ⟨n, h1, h2, h3⟩ := effective_remainder_everywhere 5 primeLike5 3 (by decide) N hN w hw' r
  exact ⟨n, h1, h2, bound_mono w _ _ n h3 (by rw [show (3 + 2 : Nat) = 5 from rfl]; omega)⟩

end PX
