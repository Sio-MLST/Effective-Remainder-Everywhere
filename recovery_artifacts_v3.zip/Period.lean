namespace Gen

def Cong (n : Nat) (a b : Int) : Prop := (n : Int) ∣ a - b

theorem Cong.refl (n : Nat) (a : Int) : Cong n a a := by simp [Cong]
theorem Cong.symm {n : Nat} {a b : Int} (h : Cong n a b) : Cong n b a := by
  unfold Cong at *; have := Int.dvd_neg.2 h; rwa [Int.neg_sub] at this
theorem Cong.trans {n : Nat} {a b c : Int} (h1 : Cong n a b) (h2 : Cong n b c) : Cong n a c := by
  unfold Cong at *; have := Int.dvd_add h1 h2; rwa [show a - b + (b - c) = a - c by omega] at this
theorem Cong.mul {n : Nat} {a b c d : Int} (h1 : Cong n a b) (h2 : Cong n c d) : Cong n (a * c) (b * d) := by
  unfold Cong at *
  have e : a * c - b * d = (a - b) * c + b * (c - d) := by
    rw [Int.sub_mul, Int.mul_sub]; omega
  rw [e]; exact Int.dvd_add (Int.dvd_trans h1 (Int.dvd_mul_right _ c)) (Int.dvd_trans h2 (Int.dvd_mul_left b _))
theorem Cong.of_dvd {n n' : Nat} {a b : Int} (hd : n ∣ n') (h : Cong n' a b) : Cong n a b :=
  Int.dvd_trans (Int.natCast_dvd_natCast.2 hd) h
theorem Cong.pow_one {n : Nat} {a : Int} (h : Cong n a 1) : ∀ k, Cong n (a ^ k) 1
  | 0 => by simp [Cong]
  | k + 1 => by rw [Int.pow_succ, show (1 : Int) = 1 * 1 from rfl]; exact (Cong.pow_one h k).mul h
theorem Cong.cancel {n c : Nat} {a b : Int} (hc : Nat.Coprime n c) (h : Cong n ((c : Int) * a) ((c : Int) * b)) :
    Cong n a b := by
  unfold Cong at *
  rw [← Int.mul_sub, Int.ofNat_dvd_left, Int.natAbs_mul, Int.natAbs_natCast] at h
  exact Int.ofNat_dvd_left.2 (Nat.Coprime.dvd_of_dvd_mul_left hc h)
theorem Cong.sub {n : Nat} {a b c d : Int} (h1 : Cong n a b) (h2 : Cong n c d) : Cong n (a - c) (b - d) := by
  unfold Cong at *; have := Int.dvd_sub h1 h2; rwa [show a - c - (b - d) = a - b - (c - d) by omega]

theorem coprime_two_of_odd {p : Nat} (hp : p % 2 = 1) : Nat.Coprime p 2 := by
  unfold Nat.Coprime; rw [Nat.gcd_comm, Nat.gcd_rec, hp]; rfl

/-- Universal period lemma for the map x ↦ px+1 (p odd). -/
theorem period_general (p K q i₀ T : Nat) (hp : p % 2 = 1) (hq1 : 1 < q) (hqp : Nat.Coprime q p)
    (hT1 : 1 ≤ T) (hT : Cong (p ^ (K + 1)) (2 ^ T) 1)
    (hA : ∀ m, Cong (p ^ (K + 1)) (2 ^ m) 1 → Cong q (2 ^ m) 1)
    (hi₀ : Cong (p ^ (K + 1)) (2 * 2 ^ i₀) (p + 1))
    (hGen : ∀ m, ∃ i, Cong (p ^ (K + 1)) (2 * 2 ^ i) (p * 2 ^ m + 1))
    (hB : ∀ i m, Cong (p ^ (K + 1)) (2 * 2 ^ i) (p * 2 ^ m + 1) →
      Cong q (p * 2 ^ m + 2 * 2 ^ i₀) (p + 2 * 2 ^ i)) : False := by
  have hTq : Cong q (2 ^ T) 1 := hA T hT
  have S : ∀ d, d ≤ K + 1 → ∀ m, Cong (p ^ (K + 1 - d)) (2 ^ m) 1 → Cong q (2 ^ m) 1 := by
    intro d
    induction d with
    | zero => intro _ m h; exact hA m h
    | succ d ih =>
      intro hd m hm
      have hj : K + 1 - d = (K + 1 - (d + 1)) + 1 := by omega
      have hdiv : p ^ (K + 1 - d) ∣ p ^ (K + 1) := Nat.pow_dvd_pow p (by omega)
      obtain ⟨i, hi⟩ := hGen m
      -- 2·2^i ≡ 2·2^i₀ mod p^(j+1), since p(2^m - 1) ≡ 0 there
      have hpm : Cong (p ^ (K + 1 - d)) ((p : Int) * 2 ^ m) p := by
        unfold Cong at hm ⊢
        rw [hj, Nat.pow_succ, Nat.mul_comm, Int.natCast_mul,
          show (p : Int) * 2 ^ m - p = p * (2 ^ m - 1) by rw [Int.mul_sub, Int.mul_one]]
        exact Int.mul_dvd_mul_left _ hm
      have h2 : Cong (p ^ (K + 1 - d)) (2 * 2 ^ i) (2 * 2 ^ i₀) := by
        have a := (hi.of_dvd hdiv).sub (hi₀.of_dvd hdiv)
        have b := (hpm.sub (Cong.refl _ (p : Int)))
        refine Cong.trans (b := (p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀) ?_ ?_
        · unfold Cong at a ⊢; rwa [show (2 : Int) * 2 ^ i - ((p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀)
            = 2 * 2 ^ i - 2 * 2 ^ i₀ - ((p : Int) * 2 ^ m + 1 - (p + 1)) by omega]
        · unfold Cong at b ⊢; rwa [show (p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀ - 2 * 2 ^ i₀
            = (p : Int) * 2 ^ m - p - (p - p) by omega]
      have h2' : Cong (p ^ (K + 1 - d)) (2 ^ i) (2 ^ i₀) :=
        Cong.cancel (c := 2) (Nat.Coprime.pow_left _ (coprime_two_of_odd hp)) (by exact_mod_cast h2)
      let m' := i + i₀ * (T - 1)
      have hsplit : (2 : Int) ^ m' * 2 ^ i₀ = 2 ^ i * (2 ^ T) ^ i₀ := by
        rw [← Int.pow_add, ← Int.pow_mul, ← Int.pow_add]; congr 1
        show i + i₀ * (T - 1) + i₀ = i + T * i₀
        rw [Nat.mul_comm T, Nat.add_assoc, ← Nat.mul_succ, show (T - 1).succ = T by omega]
      have hm'P : Cong (p ^ (K + 1 - d)) (2 ^ m' * 2 ^ i₀) (1 * 2 ^ i₀) := by
        rw [hsplit, Int.one_mul]
        have := (Cong.refl _ ((2 : Int) ^ i)).mul ((hT.of_dvd hdiv).pow_one i₀)
        rw [Int.mul_one] at this; exact this.trans h2'
      have hm' : Cong (p ^ (K + 1 - d)) (2 ^ m') 1 := by
        rw [Int.mul_comm, Int.mul_comm (1 : Int)] at hm'P
        exact Cong.cancel (c := 2 ^ i₀) (Nat.Coprime.pow _ _ (coprime_two_of_odd hp))
          (by exact_mod_cast hm'P)
      have hq' := ih (by omega) m' hm'
      have hiq : Cong q (2 ^ i) (2 ^ i₀) := by
        have a := hq'.mul (Cong.refl q ((2 : Int) ^ i₀))
        rw [hsplit, Int.one_mul] at a
        have b := (Cong.refl q ((2 : Int) ^ i)).mul (hTq.pow_one i₀)
        rw [Int.mul_one] at b; exact b.symm.trans a
      have hBq := hB i m hi
      have c1 : Cong q ((p : Int) * 2 ^ m) ((p : Int) * 1) := by
        have := hBq.sub ((Cong.refl q (2 : Int)).mul hiq |>.symm)
        unfold Cong at this ⊢
        rwa [show (p : Int) * 2 ^ m + 2 * 2 ^ i₀ - 2 * 2 ^ i₀ - (p + 2 * 2 ^ i - 2 * 2 ^ i)
          = p * 2 ^ m - p * 1 by omega] at this
      exact Cong.cancel hqp c1
  have h := S (K + 1) (Nat.le_refl _) 1 (by rw [Nat.sub_self, Nat.pow_zero]; exact Int.one_dvd _)
  unfold Cong at h
  have := Int.le_of_dvd (by decide) h
  omega

end Gen
#print axioms Gen.period_general
