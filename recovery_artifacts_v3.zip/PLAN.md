> **Superseded in part (2026-11-04, session 3):** see START_HERE.md for precedence. Status lines and next steps here are historical; PLAN_V3.md is the current plan.

# Plan and status (2026-11-04). Paper-level only; no builds, no installs.
Rule: each step ends with a one-paragraph explanation I could give without notes. Notes for each step are in UNDERSTANDING_NOTES.md (section in brackets).

## Original 8 steps and status
1. Pin the statement (weak vs strong, audited against Lean)      DONE      [§1]
2. Own the dichotomy (Thm 1 generation, Thm 2 necessity)         DONE      [§2] (p=1093 test not rerun; rests on handoff)
3. Find a cleaner Part A (replace Lemma 9 descent)                PARTIAL   [§3] reframing only (Stab mod q abelian); clean replacement NOT found
4. Demystify Part B (circularity, lift)                           DONE      [§4]
5. Account for the bound (source of each factor)                  PARTIAL   [§4,§8] double-exponential source found; N^(L+2) NOT traced (remainder_bounded, split_two_p unread)
6. Strong-theorem lemma plan at core-Lean granularity             PARTIAL   [§5] three pieces listed (Fermat d|p-1, prime bridge, necessity); route not chosen, no fine lemma list
7. Exposition skeleton                                            THIN      [§6] five-line outline
8. Formalisation design note (file/lemma map, no code)            NOT DONE

## Added after the plan
- Mazur paper read; takeaway and the shared question t(M)         [§7, §9]
- Single-exponential derivation for N=2^α p^b (paper-level, flagged for a second check of the prefix+end-step combination)   [§8]

## Revised order (current recommendation)
1. Read remainder_bounded / split_two_p: close step 5, test N^(L+2)=N^L·N^2 guess.
2. Choose Fermat route; write lemma list (step 6).
3. Formalisation design note (step 8).
4. Re-derive the single-exponential case carefully.
5. t(M): least number of odd steps whose sums Σ p^(t-i)2^(e_i) cover Z/M (frontier; also the point of contact with Mazur).
6. Steps 3 and 7 only if there is room (3 demoted to optional; 7 moved last).
Track A (logistics, finishes strong theorem): items 1-3. Track B (mathematics): items 4-5.
