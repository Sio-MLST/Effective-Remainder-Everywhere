# px+1 coverage: vision and working plan (v3, 2026-11-04). CURRENT PLAN.
Supersedes PLAN.md and the "next steps" lists in INSIGHTS_SESSION2.md §5 and UNDERSTANDING_NOTES. Those were merged in here.

## Where we stand
- Lean proof (EREp.lean, core Lean 4.35, 0 sorry): Base p, PrimeLike p, p ≤ 2^L, w mod p ∈ ⟨2⟩ ⇒ every class r mod N has n ⇝ w with n ≤ w·2^(2^((3L+8)·p·N^(L+2))). Doubly exponential.
- Necessity (paper, UNDERSTANDING_NOTES §2): if w mod p ∉ ⟨2⟩, predecessors of w are only 2^k·w. The condition is sharp.
- New paper proof (PROOF_SKETCH.md): p-adic contraction of u to 1/(2−p) + translation by 1/4 on ℤ/M. Steps 1–2 argued and tested; Step 3 (CRT choice of E) and Step 4 (bound) only sketched.
- Checks done, do not repeat: 2,335 reachability, 1,817 odd-step-bound, 836 end-to-end (scripts/).
- Tooling: single Mathlib files fetch fine from raw.githubusercontent.com; file subsets are not viable (mathlib_probe/).

## Vision: a book proof. "Stronger" = four layers, in order of certainty
1. Cleaner proof: contraction + translation replace fibre/stabiliser/descent (Part A); cite standard facts (Fermat, CRT, LTE, Terras).
2. Stronger statement: Nat-style primality, 2^(p−1) ≢ 1 (mod p²), and an IFF: coverage ⇔ w mod p ∈ ⟨2⟩.
3. Better bound (smaller upper bound on n): target 1 inner exponent ≈ L·N (sketched); target 2 singly exponential (open, needs t(M) = O(log M)).
4. More general (speculative): Wieferich primes, composite p, other affine maps.
Each layer stands alone; failure in 3–4 does not undo 1–2.

## Roadmap (each stage has a gate)
1. Finish paper proof: write Steps 3 and 4 in full. Gate: an independent reader (or fresh session told only to check them) finds no gap.
2. Blueprint: numbered lemma list (statement, borrowed/proved, dependencies) = paper outline + Lean to-do. Replaces the old "formalisation design note" (old step 8). Gate: each lemma has a proof paragraph or citation.
3. Strong statement on the OLD Lean proof: Fermat (ord_p 2 ∣ p−1), Prime def + bridge to PrimeLike, necessity lemma; optionally tighter corollaries (42N^4, 85N^5) and Base 7. Gate: IFF theorem compiles, standard axioms. Old proof untouched. Cheapest real gain.
4. Mini-library spec: exact Lean statements, before proofs. Gate: user agrees.
5. New proof in Lean, lemma by lemma, alongside the old file. Gate: improved bound compiles.
6. Research thread t(M) (fewest odd steps covering ℤ/M), in parallel; never blocks 1–5. First case M = 2^s − 1.

## Lean strategy: core Lean + hand-written mini-library; Mathlib read, never imported
Why: transitive imports of Data.Nat.Prime.Basic = 1,359 files (409k lines), Data.ZMod.Basic = 1,402, FieldTheory.Finite.Basic = 1,952; Mathlib master's toolchain vs Lean 4.35 unchecked.
| Piece | Used in | Status |
|---|---|---|
| Fermat base 2: ord_p(2) ∣ p−1 | Lemma 0, stage 3 | to write |
| Prime def + bridge to PrimeLike | stage 3 | to write |
| Modular inverses 1/2, 1/4, 1/(2−p) (gcd/Bézout) | Step 2 | to write |
| CRT coprime moduli + lcm | Step 3 | to write |
| Finite reachability (bijections, < size steps) | Step 2(b) | partly in old BFS machinery |
| Terras parity bookkeeping | Steps 1, 3 | in EREp.lean (parity_word, integrality) |
| LTE for 2^d = 1+pu | Lemma 0 | in EREp.lean (Gen.order_iff, gen_unit) |
Use Mathlib by fetching ONE file to copy a lemma's shape. GitHub API is rate-limited without a token; raw URLs are not.

## Working rules (save quota)
- Run an experiment only if its result could surprise us; write the expected outcome first.
- Never repeat a logged check; extend only to a genuinely new regime.
- No one-shots: one lemma / section / script per step, checked before the next.
- Paper before code. Smallest tool first. No busy work (no re-summarising understood notes).
- End every session with a checkpoint and a single zip. Ask the user when a choice is theirs.

## Open questions
- t(M) — the frontier; shared with Mazur's work (UNDERSTANDING_NOTES §7, §9).
- Wieferich primes: coverage under a condition on w mod p²? Unchecked.
- Composite odd p: what replaces Lemma 0? Unchecked.
- Other maps (an+b)/2: does contraction + translation extend? Unchecked.
- Is coverage mod N already in the 3x+1 literature? One search before writing the paper.
