# EREp — Effective remainder theorem for the px+1 map, formalised in Lean 4

Formal proof, in core Lean 4.35.0 (no Mathlib, no lake project), of an effective
"every residue class is hit by a bounded predecessor" theorem for the map
  C_p(n) = n/2 (n even),  p·n + 1 (n odd),   p an odd parameter.
It generalises two earlier single-prime files, ERE3 (3x+1) and ERE5 (5x+1); ERE5 is in `reference/`.
A paper based on the code is planned.

## Status (verified 2026-11-04)
- Complete: 0 `sorry`, 0 errors, 0 warnings.
- `#print axioms` for the three final theorems: `propext`, `Classical.choice`, `Quot.sound`.
- See `verification.log` for the exact build and axiom output.

## Contents
| Path | What it is |
|---|---|
| `EREp.lean` | Monolithic standalone file (1932 lines); the canonical artifact (formerly `PX_all.lean`). |
| `split/PXGen.lean` | `Gen` namespace: order of 1+pu mod p^(K+1) (`order_iff`, `period_general`, `gen_unit`). |
| `split/PX1.lean` | Part A (`import PXGen`): `Base p`, subgroup ⟨2⟩ (`InG`), fibre/stabiliser/translation layer, `closure_all`. |
| `split/PX2.lean` | Parts B, C (`import PX1`): parity words, exponent lift, bounds, main theorem, corollaries. |
| `reference/ERE5.lean` | The 5x+1 original that Parts B/C were ported from (5 → p). |
| `verification.log` | Build times and axiom output for both forms. |

The split files and `EREp.lean` contain exactly the same 173 top-level declarations. `EREp.lean` is the
split files concatenated with the `import` lines removed. If you edit one form, regenerate the other.
Only `EREp.lean` keeps a single header comment; the split files have no comments at all.

## Build
```
# toolchain (the sandbox has no zstd binary; use python):
curl -sLO https://github.com/leanprover/lean4/releases/download/v4.35.0/lean-4.35.0-linux.tar.zst
pip install zstandard   # then extract with zstandard + tarfile
export PATH=/opt/lean-4.35.0-linux/bin:$PATH
lean EREp.lean                                   # standalone, ~16 s
cd split && lean -o PXGen.olean PXGen.lean && LEAN_PATH=. lean -o PX1.olean PX1.lean \
  && LEAN_PATH=. lean -o PX2.olean PX2.lean      # ~16 s total; PX2 alone ~10 s once PX1.olean exists
```
To check axioms, append `#print axioms PX.effective_remainder_everywhere` (also `PX.cor_p3`, `PX.cor_p5`) and run `lean`.

## What is proved
`PX.effective_remainder_everywhere`: suppose p satisfies `Base p` and `PrimeLike p`, p ≤ 2^L, and w ≡ 2^i (mod p) for some i.
Then for every N ≥ 1 and every r there is an n with all three of:
- `Reaches p w n`, i.e. iterating C_p from n reaches w;
- n ≡ r (mod N);
- n ≤ w · 2^(2^((3L+8)·p·N^(L+2))).

`PX.remainder_bounded` is the same statement with an extra B < n, and exponent (3L+8)·p·N^(L+2)·(B+1).

Corollaries (hypothesis p ∤ w; `Base` and `PrimeLike` are discharged by `decide`):
- `PX.cor_p3`: bound 2^(2^(48·N^4)). This is ERE3's statement; the general theorem actually gives 42·N^4.
- `PX.cor_p5`: bound 2^(2^(105·N^5)). This is ERE5's statement; the general theorem actually gives 85·N^5.

### Hypotheses, and how they differ from the stronger result we want
- **`Base p`** (a class): p odd, 3 ≤ p, and there are d, u with 0 < d ≤ p, 2^d = 1 + p·u and gcd(p, u) = 1.
  - In words, 2 has some order d ≤ p mod p, and 2^d ≢ 1 (mod p²). This is a non-Wieferich condition, written so that core Lean can prove it.
  - The intended statement is the natural hypothesis 2^(p−1) ≢ 1 (mod p²). Getting there needs base-2 Fermat's little theorem; see Future work.
  - Primality of p is not used for `Base`, nor anywhere in Part A.
- **`PrimeLike p := ∀ N, N % p ≠ 0 → Nat.Coprime p N`**.
  - For p ≥ 2 this is equivalent to p being prime: if p = ab is composite, take N = a.
  - It is a convenience form rather than a weakening; a bridge to `Nat.Prime` is still missing.
- **w ∈ ⟨2⟩ mod p** (`∃ i, w % p = 2^i % p`).
  - This is the genuine restriction relative to ERE3/ERE5, which only assume p ∤ w. The two agree when 2 is a primitive root mod p, as for p = 3 and 5.
  - For a prime like p = 7, where 2 has order 3, only w ≡ 1, 2, 4 (mod 7) are covered.
  - The hypothesis comes from `closure_all`. Whether the theorem can hold for w outside ⟨2⟩, or whether those w are genuinely excluded, has **not been investigated**.
- **L** is any number with p ≤ 2^L; inside the proof L ≥ 2 is forced by p ≥ 3.

### The stronger result we ultimately want
The statement for every odd prime p with 2^(p−1) ≢ 1 (mod p²), stated with `Nat.Prime`, ideally under the condition p ∤ w alone, or else with a proof that w ∈ ⟨2⟩ is necessary.

## Proof architecture
- **Gen** (`PXGen`): for odd p ≥ 3 with p ∤ u, `order_iff` says (1+pu)^m ≡ 1 (mod p^(K+1)) exactly when p^K ∣ m. `gen_unit` says every x ≡ 1 (mod p) is congruent to (1+pu)^t mod p^(K+1) for some t < p^K; it is proved by counting.
- **Part A** (`PX1`): `closure_all`. For M coprime to 2p and w ∈ ⟨2⟩, every x lies in the backward closure `Closure p (p^(K+1)·M) w`.
  - The argument works on residues `Fin M` and fibres, using stabilisers and translation periods.
  - It works directly with membership in ⟨2⟩ (`InG`), so primitivity of 2 is never needed.
- **Part B** (`PX2`, ported from ERE5):
  - The parity-word machinery is `oneCount`, `offset`, `integrality`, `parity_word` and `HasWord`.
  - `closure_word_short` bounds the word length by the modulus.
  - The split lemmas are `split_p` and `split_two_p`; `exists_pow2_period` supplies the period of 2 mod M.
- **Exponent lift** (`exp_lift`, new; it replaces ERE5's `exponent_class`):
  1. `exp_lift_cong`: invert 2^κ·w mod p^(K+j+1).
  2. `exp_lift_t`: apply `gen_unit` and `order_iff` to get t = p^K·t′ with t′ < p^j.
  3. `exp_lift_s`: choose s ≥ B with D′ ∣ t′ + p^j·s.
  4. Take k = κ + d·p^K·(t′ + p^j·s).
- **Part C**: `bound_arith` and `hit_residue` combine into `remainder_bounded`, and then `effective_remainder_everywhere` with B = 0.
  - `bound_arith` puts every quantity below a power of 2; writing L·X as a single variable q keeps the exponent arithmetic linear, so `omega` closes it.
  - The constant (3L+7) has room to spare: (2L+8)·X + 2 is enough.

## Future work (none started)
1. **Fermat base 2** in core Lean: show 2^(p−1) ≡ 1 (mod p) for prime p. Then 2^(p−1) ≢ 1 (mod p²) gives `Base p`, by taking d = the order of 2 (d ∣ p−1, so d ≤ p) and using that p² ∤ 2^d − 1.
2. **Bridge** `Nat.Prime p → PrimeLike p`, so the theorem can be stated with standard primality.
3. **Tighter corollaries**: state `cor_p3` and `cor_p5` with 42·N^4 and 85·N^5, the bounds the general theorem already gives. This is a one-line change to each `bound_mono` call.
4. **w ∉ ⟨2⟩**: investigate whether this case can be removed, which is the main mathematical gap.
5. Optional: give `Base` instances for more primes (p = 11 and 13 have 2 as a primitive root), and add primes where 2 is not primitive (7, 17, …) as test cases.

## Notes for the next session
- **Earlier deprecation warning (resolved):** `if_neg` in `collatz_odd` was replaced with `ite_eq_right`.
- **Unused-code audit:** run a dependency closure from the three final theorems (`ConstantInfo.getUsedConstantsAsSet`, which needs `import Lean`). Every declaration is reachable; only compiler-generated `congr_simp` lemmas show up.
- **Edits made after the skeleton stage:**
  - `bound_arith` gained `hL : 2 ≤ L`.
  - `exp_lift_cong` was simplified: it no longer uses T′ or the period hypothesis.
  - `reaches_pow2` and `offset_le` gained `[Base p]`.
  - The helper lemmas `cop_w`, `mod_lin`, `pow2bound_add` and `bound_mono` were added.
- **Sandbox lessons:**
  - `/bin/sh` has no `time` and no `<(...)`.
  - Background jobs are killed when a tool call ends, so run builds in the foreground.
  - `grind` closes the `Fin` and `Nat` ring identities. Put `generalize (p + 1) / 2 = c` in front of `grind` when the goal contains a division.
- **Archived files:** the original ERE3 file and the period/handoff notes are not included here. They live in the project's knowledge files.
