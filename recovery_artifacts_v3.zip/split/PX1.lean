import PXGen

namespace PX

set_option linter.unusedSectionVars false

class Base (p : Nat) : Prop where
  odd : p % 2 = 1
  three_le : 3 ≤ p
  gen : ∃ d u, 0 < d ∧ d ≤ p ∧ 2 ^ d = 1 + p * u ∧ Nat.Coprime p u

theorem pow_mod_period {b y n : Nat} (h : b ^ y % n = 1 % n) (x : Nat) :
    ∀ N, b ^ (x + y * N) % n = b ^ x % n
  | 0 => by simp
  | N + 1 => by
    rw [Nat.mul_succ, ← Nat.add_assoc, Nat.pow_add, Nat.mul_mod, pow_mod_period h x N, h,
      ← Nat.mul_mod, Nat.mul_one]

section Basics
variable (p : Nat) [Base p]

theorem p_dvd_pow (K : Nat) : p ∣ p ^ (K + 1) := ⟨p ^ K, by rw [Nat.pow_succ, Nat.mul_comm]⟩

theorem one_lt_powp (K : Nat) : 1 < p ^ (K + 1) :=
  Nat.one_lt_pow (Nat.succ_ne_zero K) (by have := Base.three_le (p := p); omega)

theorem powp_pos (K : Nat) : 0 < p ^ K := Nat.pow_pos (by have := Base.three_le (p := p); omega)

theorem coprime_p_two : Nat.Coprime p 2 := Gen.coprime_two_of_odd Base.odd

theorem powp_odd (n : Nat) : p ^ n % 2 = 1 := by
  rw [Nat.pow_mod, Base.odd (p := p), Nat.one_pow]

theorem one_mod_P (K : Nat) : 1 % p ^ (K + 1) = 1 := Nat.mod_eq_of_lt (one_lt_powp p K)

theorem period (K : Nat) : ∃ T, 0 < T ∧ 2 ^ T % p ^ (K + 1) = 1 % p ^ (K + 1) := by
  obtain ⟨d, u, hd0, -, hd, hu⟩ := Base.gen (p := p)
  refine ⟨d * p ^ K, Nat.mul_pos hd0 (powp_pos p K), ?_⟩
  rw [Nat.pow_mul, hd, one_mod_P]
  exact (Gen.order_iff Base.odd Base.three_le hu K _).2 (Nat.dvd_refl _)

theorem two_gen (K x : Nat) (hx : x % p = 1) : ∃ s, 2 ^ s % p ^ (K + 1) = x % p ^ (K + 1) := by
  obtain ⟨d, u, _, -, hd, hu⟩ := Base.gen (p := p)
  obtain ⟨t, _, ht⟩ := Gen.gen_unit Base.odd Base.three_le hu K x hx
  exact ⟨d * t, by rw [Nat.pow_mul, hd]; exact ht⟩

def InG (K a : Nat) : Prop := ∃ m, 2 ^ m % p ^ (K + 1) = a % p ^ (K + 1)

theorem inG_ratio {K a b : Nat} (ha : InG p K a) (hb : InG p K b) :
    ∃ j, (2 ^ j * a) % p ^ (K + 1) = b % p ^ (K + 1) := by
  obtain ⟨m, hm⟩ := ha
  obtain ⟨n, hn⟩ := hb
  obtain ⟨T, hT0, hT⟩ := period p K
  refine ⟨n + m * (T - 1), ?_⟩
  rw [Nat.mul_mod, ← hm, ← Nat.mul_mod, ← Nat.pow_add, ← hn]
  have e : n + m * (T - 1) + m = n + T * m := by
    rw [Nat.add_assoc, Nat.mul_comm T m]
    have : m * (T - 1) + m = m * T := by
      rw [← Nat.mul_succ]; congr 1; omega
    omega
  rw [e]; exact pow_mod_period hT n m

theorem inG_pow (K m : Nat) : InG p K (2 ^ m) := ⟨m, rfl⟩

theorem undo_class (K a : Nat) : ∃ i, (2 * 2 ^ i) % p ^ (K + 1) = (p * a + 1) % p ^ (K + 1) := by
  have h1 : (p * a + 1) % p = 1 := by
    rw [Nat.mul_add_mod]; exact Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)
  obtain ⟨s, hs⟩ := two_gen p K _ h1
  obtain ⟨T, hT0, hT⟩ := period p K
  refine ⟨s + (T - 1), ?_⟩
  rw [← hs, show 2 * 2 ^ (s + (T - 1)) = 2 ^ (s + T * 1) by
    rw [← Nat.pow_succ']; congr 1; omega]
  exact pow_mod_period hT s 1

theorem w_inG {w i : Nat} (hw : w % p = 2 ^ i % p) (K : Nat) : InG p K w := by
  obtain ⟨T, hT0, hT⟩ := period p K
  have hTp : 2 ^ T % p = 1 := by
    rw [← Nat.mod_mod_of_dvd _ (p_dvd_pow p K), hT, one_mod_P,
      Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)]
  have h1 : (2 ^ (i * (T - 1)) * w) % p = 1 := by
    rw [Nat.mul_mod, hw, ← Nat.mul_mod, ← Nat.pow_add,
      show i * (T - 1) + i = T * i by rw [Nat.mul_comm T i, ← Nat.mul_succ]; congr 1; omega,
      Nat.pow_mul, Nat.pow_mod, hTp, Nat.one_pow]
    exact Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)
  obtain ⟨s, hs⟩ := two_gen p K _ h1
  refine ⟨s + i, ?_⟩
  rw [Nat.pow_add, Nat.mul_mod, hs, ← Nat.mul_mod, Nat.mul_assoc, Nat.mul_comm w, ← Nat.mul_assoc,
    ← Nat.pow_add, show i * (T - 1) + i = 0 + T * i by
      rw [Nat.zero_add, Nat.mul_comm T i, ← Nat.mul_succ]; congr 1; omega,
    Nat.mul_mod, pow_mod_period hT 0 i, ← Nat.mul_mod, Nat.pow_zero, Nat.one_mul]

end Basics

section Map
variable (p : Nat) [Base p]

def collatz (n : Nat) : Nat := if n % 2 = 0 then n / 2 else p * n + 1

def iter (f : Nat → Nat) : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => iter f k (f n)

theorem iter_add (f : Nat → Nat) (m n : Nat) : ∀ x, iter f (m + n) x = iter f m (iter f n x) := by
  induction n with
  | zero => intro x; rfl
  | succ n ih => intro x; exact ih (f x)

def Reaches (v n : Nat) : Prop := ∃ k, iter (collatz p) k n = v

theorem collatz_double (a : Nat) : collatz p (2 * a) = a := by
  unfold collatz; split <;> omega

theorem reaches_trans {a b c : Nat} (h1 : Reaches p b a) (h2 : Reaches p c b) : Reaches p c a := by
  obtain ⟨k1, hk1⟩ := h1
  obtain ⟨k2, hk2⟩ := h2
  exact ⟨k2 + k1, by rw [iter_add, hk1, hk2]⟩

end Map

theorem mod_cancel_mul_left {m a x y : Nat} (hcop : Nat.Coprime m a) (hxy : y ≤ x)
    (h : (a * x) % m = (a * y) % m) : x % m = y % m := by
  have h1 := Nat.sub_mod_eq_zero_of_mod_eq h
  have h2 : a * x - a * y = a * (x - y) := (Nat.mul_sub a x y).symm
  rw [h2] at h1
  have h3 : m ∣ a * (x - y) := Nat.dvd_of_mod_eq_zero h1
  have h4 : m ∣ x - y := Nat.Coprime.dvd_of_dvd_mul_left hcop h3
  have h5 := Nat.mod_eq_zero_of_dvd h4
  have h6 : x = y + (x - y) := by omega
  rw [h6, Nat.add_mod, h5]; simp

theorem mod_cancel_mul_right {m c x y : Nat} (hcop : Nat.Coprime m c)
    (h : (x * c) % m = (y * c) % m) : x % m = y % m := by
  rcases Nat.le_total y x with hle | hle
  · exact mod_cancel_mul_left hcop hle (by rwa [Nat.mul_comm c x, Nat.mul_comm c y])
  · exact (mod_cancel_mul_left hcop hle (by rw [Nat.mul_comm c x, Nat.mul_comm c y]; exact h.symm)).symm

section Residues
variable (M : Nat) [NeZero M]

def residue (n : Nat) : Fin M := Fin.ofNat M n

theorem residue_val (n : Nat) : (residue M n).val = n % M := Fin.val_ofNat M n

theorem residue_eq_iff (a b : Nat) : residue M a = residue M b ↔ a % M = b % M := by
  constructor
  · intro h; have := congrArg Fin.val h; rwa [residue_val, residue_val] at this
  · intro h; apply Fin.ext; rw [residue_val, residue_val]; exact h

theorem residue_add (a b : Nat) : residue M (a + b) = residue M a + residue M b := by
  apply Fin.ext; rw [Fin.val_add, residue_val, residue_val, residue_val, Nat.add_mod]

theorem residue_mul (a b : Nat) : residue M (a * b) = residue M a * residue M b := by
  apply Fin.ext; rw [Fin.val_mul, residue_val, residue_val, residue_val, Nat.mul_mod]

theorem residue_zero : residue M 0 = (0 : Fin M) := rfl
theorem residue_one : residue M 1 = (1 : Fin M) := rfl
theorem residue_two : residue M 2 = (2 : Fin M) := rfl
class TwoPInv (p M : Nat) [NeZero M] : Prop where
  two : ∃ b : Fin M, (2 : Fin M) * b = 1
  pinv : ∃ b : Fin M, residue M p * b = 1

open Classical in
noncomputable def unitInv (a : Fin M) : Fin M := if h : ∃ b : Fin M, a * b = 1 then h.choose else 0

theorem mul_unitInv {a : Fin M} (h : ∃ b : Fin M, a * b = 1) : a * unitInv M a = 1 := by
  unfold unitInv
  split
  · rename_i h'; exact h'.choose_spec
  · rename_i h'; exact absurd h h'

theorem two_mul_unitInv {p : Nat} [TwoPInv p M] : (2 : Fin M) * unitInv M 2 = 1 := mul_unitInv M (TwoPInv.two (p := p))
theorem p_mul_unitInv {p : Nat} [TwoPInv p M] : residue M p * unitInv M (residue M p) = 1 := mul_unitInv M TwoPInv.pinv

theorem hA_id (p : Nat) (T r v : Fin M) (h5 : residue M p * v = 1) :
    residue M p * ((0 : Fin M) + v - T * (0 : Fin M) - r * v) = residue M 1 - r := by
  rw [residue_one]
  grind

theorem hB_id (p m i i₀ : Nat) (u v : Fin M)
    (hu : residue M (2 ^ m) * u = 1) (h5 : residue M p * v = 1) :
    residue M p * (residue M (p * 2 ^ m) * (-(u * v) + v
        - v * (2 * residue M (2 ^ i₀)) * -(u * v)
        - u * v * 2 * residue M (2 ^ i) * v))
      = residue M (p * 2 ^ m + 2 * 2 ^ i₀) - residue M (p + 2 * 2 ^ i) := by
  rw [residue_mul M p (2 ^ m), residue_add M (p * 2 ^ m) (2 * 2 ^ i₀),
    residue_add M p (2 * 2 ^ i), residue_mul M p (2 ^ m), residue_mul M 2 (2 ^ i₀),
    residue_mul M 2 (2 ^ i), residue_two]
  grind

theorem cancel_invertible {u v a b : Fin M} (hu : u * v = 1) (h : u * a = u * b) : a = b := by
  calc a = (u * v) * a := by rw [hu]; grind
    _ = v * (u * a) := by grind
    _ = v * (u * b) := by rw [h]
    _ = (u * v) * b := by grind
    _ = b := by rw [hu]; grind

def IsInvertible (a : Fin M) : Prop := ∃ b : Fin M, a * b = 1

theorem isInvertible_mul {a b : Fin M} (ha : IsInvertible M a) (hb : IsInvertible M b) : IsInvertible M (a * b) := by
  obtain ⟨ia, hia⟩ := ha
  obtain ⟨ib, hib⟩ := hb
  exact ⟨ib * ia, by
    calc a * b * (ib * ia) = (a * ia) * (b * ib) := by grind
      _ = 1 := by rw [hia, hib]; grind⟩

theorem unitInv_eq_of_mul {a b : Fin M} (h : a * b = 1) : unitInv M a = b :=
  cancel_invertible M h ((mul_unitInv M ⟨b, h⟩).trans h.symm)

theorem isInvertible_unitInv {a : Fin M} (h : IsInvertible M a) : IsInvertible M (unitInv M a) :=
  ⟨a, by have := mul_unitInv M h; grind⟩

end Residues

section Counting
variable {M : Nat}

open Classical in
noncomputable def cardinality (S : Fin M → Prop) : Nat :=
  ((List.finRange M).filter (fun t => decide (S t))).length

open Classical in
theorem mem_cardlist {S : Fin M → Prop} {t : Fin M} :
    t ∈ (List.finRange M).filter (fun t => decide (S t)) ↔ S t := by
  rw [List.mem_filter]; simp [List.mem_finRange]

open Classical in
theorem cardinality_le_of_inj {S T : Fin M → Prop} (g : Fin M → Fin M)
    (hinj : ∀ a b, g a = g b → a = b) (hmap : ∀ t, S t → T (g t)) : cardinality S ≤ cardinality T := by
  unfold cardinality
  have hnd : ((List.finRange M).filter (fun t => decide (S t))).Nodup :=
    List.Pairwise.filter _ (List.nodup_finRange M)
  have hnd2 : (((List.finRange M).filter (fun t => decide (S t))).map g).Nodup := by
    apply List.pairwise_map.2
    apply List.Pairwise.imp_of_mem _ hnd
    intro a b _ _ hab hg
    exact hab (hinj a b hg)
  have hsub : ((List.finRange M).filter (fun t => decide (S t))).map g
      ⊆ (List.finRange M).filter (fun t => decide (T t)) := by
    intro u hu
    rw [List.mem_map] at hu
    obtain ⟨t, ht, rfl⟩ := hu
    rw [mem_cardlist] at ht ⊢
    exact hmap t ht
  have := hnd2.length_le_of_subset hsub
  simpa using this

open Classical in
theorem cardinality_eq_of_sub {S T : Fin M → Prop} (hsub : ∀ t, S t → T t) (hc : cardinality T ≤ cardinality S) :
    ∀ t, T t → S t := by
  intro t0 ht0
  apply Classical.byContradiction
  intro hn
  unfold cardinality at hc
  have hnd : ((List.finRange M).filter (fun t => decide (S t))).Nodup :=
    List.Pairwise.filter _ (List.nodup_finRange M)
  have hnd2 : (t0 :: (List.finRange M).filter (fun t => decide (S t))).Nodup := by
    rw [List.nodup_cons]
    exact ⟨fun h => hn ((mem_cardlist).1 h), hnd⟩
  have hsub2 : (t0 :: (List.finRange M).filter (fun t => decide (S t)))
      ⊆ (List.finRange M).filter (fun t => decide (T t)) := by
    intro u hu
    rcases List.mem_cons.1 hu with rfl | hu
    · exact (mem_cardlist).2 ht0
    · exact (mem_cardlist).2 (hsub u ((mem_cardlist).1 hu))
  have := hnd2.length_le_of_subset hsub2
  simp only [List.length_cons] at this
  omega

open Classical in
theorem cardinality_pos {S : Fin M → Prop} {t0 : Fin M} (h : S t0) : 1 ≤ cardinality S := by
  unfold cardinality
  exact List.length_pos_of_mem ((mem_cardlist).2 h)

end Counting

theorem exists_inv_of_coprime {M : Nat} [NeZero M] (a : Fin M) (hcop : Nat.Coprime M a.val) :
    ∃ b : Fin M, a * b = 1 := by
  have hinj : ∀ s t : Fin M, a * s = a * t → s = t := by
    intro s t h
    have h1 := congrArg Fin.val h
    rw [Fin.val_mul, Fin.val_mul] at h1
    have h2 : (s.val * a.val) % M = (t.val * a.val) % M := by
      rw [Nat.mul_comm s.val, Nat.mul_comm t.val]; exact h1
    have h3 := mod_cancel_mul_right hcop h2
    rw [Nat.mod_eq_of_lt s.isLt, Nat.mod_eq_of_lt t.isLt] at h3
    exact Fin.ext h3
  have hc : cardinality (fun _ : Fin M => True) ≤ cardinality (fun t : Fin M => ∃ s, a * s = t) :=
    cardinality_le_of_inj (fun t => a * t) hinj (fun t _ => ⟨t, rfl⟩)
  exact cardinality_eq_of_sub (S := fun t : Fin M => ∃ s, a * s = t) (T := fun _ : Fin M => True)
    (fun _ _ => trivial) hc 1 trivial

theorem exists_inv_residue {M : Nat} [NeZero M] (n : Nat) (hcop : Nat.Coprime M n) :
    ∃ b : Fin M, residue M n * b = 1 := by
  apply exists_inv_of_coprime
  rw [residue_val]
  unfold Nat.Coprime at hcop ⊢
  rw [Nat.gcd_comm, ← Nat.gcd_rec]; exact hcop

theorem twoPInv_of_coprime {p M : Nat} [NeZero M] (h : Nat.Coprime M (2 * p)) : TwoPInv p M :=
  ⟨exists_inv_residue 2 (Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_right 2 p) h),
   exists_inv_residue p (Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_left p 2) h)⟩

theorem mod_combine_le {P Q n r : Nat} (hPQ : Nat.Coprime P Q) (hle : r ≤ n)
    (hP : n % P = r % P) (hQ : n % Q = r % Q) : n % (P * Q) = r % (P * Q) := by
  have h1 : P ∣ n - r := Nat.dvd_of_mod_eq_zero (Nat.sub_mod_eq_zero_of_mod_eq hP)
  have h2 : Q ∣ n - r := Nat.dvd_of_mod_eq_zero (Nat.sub_mod_eq_zero_of_mod_eq hQ)
  obtain ⟨k, hk⟩ := Nat.Coprime.mul_dvd_of_dvd_of_dvd hPQ h1 h2
  have : n = r + (P * Q) * k := by omega
  rw [this, Nat.add_mul_mod_self_left]

theorem mod_combine {P Q n r : Nat} (hPQ : Nat.Coprime P Q)
    (hP : n % P = r % P) (hQ : n % Q = r % Q) : n % (P * Q) = r % (P * Q) := by
  rcases Nat.le_total r n with h | h
  · exact mod_combine_le hPQ h hP hQ
  · exact (mod_combine_le hPQ h hP.symm hQ.symm).symm

theorem residue_self_val {n : Nat} [NeZero n] (v : Fin n) : residue n v.val = v :=
  Fin.ext (by rw [residue_val, Nat.mod_eq_of_lt v.isLt])

theorem crt_exists {m n : Nat} [NeZero n] (h : Nat.Coprime n m) (a b : Nat) :
    ∃ y, y % m = a % m ∧ y % n = b % n := by
  obtain ⟨v, hv⟩ := exists_inv_residue (M := n) m h
  refine ⟨a + m * (v.val * (b + (n - 1) * a)), Nat.add_mul_mod_self_left a m _, ?_⟩
  have hn1 : residue n (n - 1) + 1 = 0 := by
    rw [← residue_one n, ← residue_add]
    apply Fin.ext; rw [residue_val, show n - 1 + 1 = n by have := NeZero.ne n; omega, Nat.mod_self]; rfl
  rw [← residue_eq_iff]
  rw [residue_add, residue_mul, residue_mul, residue_add, residue_mul, residue_self_val]
  grind

section Least
variable (M : Nat) [NeZero M]
theorem residue_val_self (e : Fin M) : residue M e.val = e := by
  apply Fin.ext; rw [residue_val, Nat.mod_eq_of_lt e.isLt]

theorem residue_self : residue M M = 0 := by
  rw [← residue_zero M]; apply (residue_eq_iff M _ _).2; simp

theorem exists_least (P : Nat → Prop) : (∃ n, P n) → ∃ n, P n ∧ ∀ r, r < n → ¬ P r := by
  rintro ⟨n, hn⟩
  revert hn
  induction n using Nat.strongRecOn with
  | _ n ih =>
    intro hn
    by_cases h : ∀ r, r < n → ¬ P r
    · exact ⟨n, hn, h⟩
    · obtain ⟨r, hr, hPr⟩ : ∃ r, r < n ∧ P r := by
        apply Classical.byContradiction
        intro hh
        apply h
        intro r hr hp
        exact hh ⟨r, hr, hp⟩
      exact ih r hr hPr

end Least

theorem mod_eq_of_le_sub {m X Y : Nat} (hle : Y ≤ X) (h : (X - Y) % m = 0) : X % m = Y % m := by
  obtain ⟨k, hk⟩ := Nat.dvd_of_mod_eq_zero h
  have : X = Y + m * k := by omega
  rw [this, Nat.add_mul_mod_self_left]

theorem mod_add_left_cancel {m e X Y : Nat} (h : (e + X) % m = (e + Y) % m) : X % m = Y % m := by
  rcases Nat.le_total Y X with hle | hle
  · exact mod_eq_of_le_sub hle (by
      have := Nat.sub_mod_eq_zero_of_mod_eq h
      rwa [show e + X - (e + Y) = X - Y by omega] at this)
  · exact (mod_eq_of_le_sub hle (by
      have := Nat.sub_mod_eq_zero_of_mod_eq h.symm
      rwa [show e + Y - (e + X) = Y - X by omega] at this)).symm
theorem mod_of_dvd_mod {a b P Z : Nat} (hZ : Z ∣ P) (h : a % P = b % P) : a % Z = b % Z := by
  rw [← Nat.mod_mod_of_dvd a hZ, h, Nat.mod_mod_of_dvd b hZ]

theorem cop_M_p {M p : Nat} (hM : Nat.Coprime M (2 * p)) : Nat.Coprime M p :=
  Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_left p 2) hM
theorem cop_M_two {M p : Nat} (hM : Nat.Coprime M (2 * p)) : Nat.Coprime M 2 :=
  Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_right 2 p) hM

def SameMod (n a b : Nat) : Prop := a % n = b % n

inductive Closure (p Q w : Nat) : Nat → Prop
  | base (k x : Nat) : SameMod Q x (2 ^ k * w) → Closure p Q w x
  | dbl {z : Nat} : Closure p Q w z → Closure p Q w (2 * z)
  | undo {z x : Nat} : Closure p Q w z → SameMod Q (p * x + 1) (2 * z) → Closure p Q w x
  | cong {z x : Nat} : Closure p Q w z → SameMod Q x z → Closure p Q w x

section Fibres
variable (p : Nat) [Base p] (M : Nat) [NeZero M] (K w : Nat)

def Fibre (a : Nat) (t : Fin M) : Prop :=
  ∃ x, Closure p (p ^ (K + 1) * M) w x ∧ x % p ^ (K + 1) = a % p ^ (K + 1) ∧ residue M x = t

theorem fibre_mod (a : Nat) : Fibre p M K w a = Fibre p M K w (a % p ^ (K + 1)) := by
  funext t; unfold Fibre; rw [Nat.mod_mod]

theorem fibre_dbl {a : Nat} {t : Fin M} (h : Fibre p M K w a t) : Fibre p M K w (2 * a) (2 * t) := by
  obtain ⟨x, hx, hxa, rfl⟩ := h
  refine ⟨2 * x, Closure.dbl hx, ?_, ?_⟩
  · rw [Nat.mul_mod, hxa, ← Nat.mul_mod]
  · rw [residue_mul, residue_two]

theorem two_mul_inj [TwoPInv p M] (s t : Fin M) (h : (2 : Fin M) * s = 2 * t) : s = t := by
  have h2 := two_mul_unitInv M (p := p)
  exact cancel_invertible M (u := 2) (v := unitInv M 2) (by grind) h

theorem fibre_cardinality_dbl_le [TwoPInv p M] (a : Nat) : cardinality (Fibre p M K w a) ≤ cardinality (Fibre p M K w (2 * a)) :=
  cardinality_le_of_inj (fun t => 2 * t) (two_mul_inj p M) (fun _ ht => fibre_dbl p M K w ht)

theorem fibre_cardinality_pow_le [TwoPInv p M] (a : Nat) :
    ∀ m, cardinality (Fibre p M K w a) ≤ cardinality (Fibre p M K w (2 ^ m * a))
  | 0 => by simp
  | m + 1 => by
    have h := fibre_cardinality_dbl_le p M K w (2 ^ m * a)
    rw [show 2 * (2 ^ m * a) = 2 ^ (m + 1) * a by rw [Nat.pow_succ]; grind] at h
    exact Nat.le_trans (fibre_cardinality_pow_le a m) h

theorem fibre_cardinality_le_live [TwoPInv p M] {a b : Nat} (ha : InG p K a) (hb : InG p K b) :
    cardinality (Fibre p M K w a) ≤ cardinality (Fibre p M K w b) := by
  obtain ⟨j, hj⟩ := inG_ratio p ha hb
  have h := fibre_cardinality_pow_le p M K w a j
  rw [fibre_mod p M K w (2 ^ j * a), hj, ← fibre_mod] at h
  exact h

theorem fibre_cardinality_const [TwoPInv p M] {a b : Nat} (ha : InG p K a) (hb : InG p K b) :
    cardinality (Fibre p M K w a) = cardinality (Fibre p M K w b) :=
  Nat.le_antisymm (fibre_cardinality_le_live p M K w ha hb) (fibre_cardinality_le_live p M K w hb ha)

theorem fibre_dbl_iff [TwoPInv p M] {a : Nat} (ha : InG p K a) (t : Fin M) :
    Fibre p M K w (2 * a) t ↔ ∃ s, Fibre p M K w a s ∧ t = 2 * s := by
  constructor
  · intro ht
    have h2a : InG p K (2 * a) := by
      obtain ⟨m, hm⟩ := ha
      exact ⟨m + 1, by rw [Nat.pow_succ, Nat.mul_comm, Nat.mul_mod, hm, ← Nat.mul_mod]⟩
    have hc : cardinality (Fibre p M K w (2 * a)) ≤ cardinality (fun t => ∃ s, Fibre p M K w a s ∧ t = 2 * s) := by
      rw [fibre_cardinality_const p M K w h2a ha]
      exact cardinality_le_of_inj (fun s => 2 * s) (two_mul_inj p M) (fun s hs => ⟨s, hs, rfl⟩)
    exact cardinality_eq_of_sub (S := fun t => ∃ s, Fibre p M K w a s ∧ t = 2 * s)
      (fun t ⟨s, hs, hts⟩ => hts ▸ fibre_dbl p M K w hs) hc t ht
  · rintro ⟨s, hs, rfl⟩; exact fibre_dbl p M K w hs

theorem fibre_undo_iff [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) {g a' : Nat} (hg : InG p K g) (ha : InG p K a')
    (h3 : (p * a' + 1) % p ^ (K + 1) = (2 * g) % p ^ (K + 1)) (s : Fin M) :
    Fibre p M K w a' s ↔ ∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t := by
  have back : ∀ s : Fin M, (∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t) → Fibre p M K w a' s := by
    rintro s ⟨t, ⟨x, hx, hxg, rfl⟩, hst⟩
    have hcop : Nat.Coprime M (p ^ (K + 1)) := Nat.Coprime.pow_right _ (cop_M_p hM)
    obtain ⟨y, hy3, hyM⟩ := crt_exists hcop a' s.val
    refine ⟨y, Closure.undo hx ?_, hy3, ?_⟩
    · unfold SameMod
      apply mod_combine (Nat.Coprime.symm hcop)
      · rw [Nat.add_mod, Nat.mul_mod, hy3, ← Nat.mul_mod, ← Nat.add_mod, h3,
          Nat.mul_mod, ← hxg, ← Nat.mul_mod]
      · have hys : residue M y = s := by rw [← residue_self_val s, residue_eq_iff]; exact hyM
        rw [← residue_eq_iff, residue_add, residue_mul, residue_mul, residue_one, residue_two, hys, hst]
    · rw [← residue_self_val s, residue_eq_iff]; exact hyM
  constructor
  · intro hs
    have h3i := p_mul_unitInv M (p := p)
    let φ : Fin M → Fin M := fun t => unitInv M (residue M p) * (2 * t - 1)
    have hφ : ∀ t, residue M p * φ t + 1 = 2 * t := by intro t; simp only [φ]; grind
    have hinj : ∀ t t', φ t = φ t' → t = t' := by
      intro t t' h
      apply two_mul_inj p M
      have := congrArg (fun z => residue M p * z + 1) h
      simp only [hφ] at this; exact this
    have hc : cardinality (Fibre p M K w a') ≤ cardinality (fun s => ∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t) := by
      rw [fibre_cardinality_const p M K w ha hg]
      exact cardinality_le_of_inj φ hinj (fun t ht => ⟨t, ht, hφ t⟩)
    exact cardinality_eq_of_sub (S := fun s => ∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t) back hc s hs
  · exact back s

def Stabilizer (h : Fin M → Fin M) : Prop := ∀ t, Fibre p M K w 1 t ↔ Fibre p M K w 1 (h t)

theorem stabilizer_comp {h1 h2 : Fin M → Fin M} (a : Stabilizer p M K w h1) (b : Stabilizer p M K w h2) :
    Stabilizer p M K w (fun t => h2 (h1 t)) := fun t => (a t).trans (b (h1 t))

theorem stabilizer_inv {h h' : Fin M → Fin M} (a : Stabilizer p M K w h) (hh : ∀ t, h (h' t) = t) :
    Stabilizer p M K w h' := fun t => by have := a (h' t); rw [hh] at this; exact this.symm

theorem stabilizer_ext {h h' : Fin M → Fin M} (a : Stabilizer p M K w h) (hh : ∀ t, h t = h' t) :
    Stabilizer p M K w h' := fun t => by rw [← hh]; exact a t

theorem twoPow_invertible (hM : Nat.Coprime M (2 * p)) (m : Nat) : IsInvertible M (residue M (2 ^ m)) :=
  exists_inv_residue (2 ^ m) (Nat.Coprime.pow_right m (cop_M_two hM))

theorem fibre_pow [TwoPInv p M] : ∀ m (t : Fin M),
    Fibre p M K w (2 ^ m) t ↔ ∃ s, Fibre p M K w 1 s ∧ t = residue M (2 ^ m) * s
  | 0, t => by
    simp only [Nat.pow_zero, residue_one]
    exact ⟨fun h => ⟨t, h, by grind⟩, fun ⟨s, hs, hst⟩ => by rw [hst]; grind⟩
  | m + 1, t => by
    have hl : InG p K (2 ^ m) := inG_pow p K m
    rw [show 2 ^ (m + 1) = 2 * 2 ^ m by rw [Nat.pow_succ]; grind, fibre_dbl_iff p M K w hl]
    constructor
    · rintro ⟨s', hs', rfl⟩
      obtain ⟨s, hs, rfl⟩ := (fibre_pow m s').1 hs'
      exact ⟨s, hs, by rw [residue_mul, residue_two]; grind⟩
    · rintro ⟨s, hs, rfl⟩
      exact ⟨residue M (2 ^ m) * s, (fibre_pow m _).2 ⟨s, hs, rfl⟩, by rw [residue_mul, residue_two]; grind⟩

theorem fibre_live [TwoPInv p M] {a m : Nat} (ham : (2 ^ m) % p ^ (K + 1) = a % p ^ (K + 1)) (t : Fin M) :
    Fibre p M K w a t ↔ ∃ s, Fibre p M K w 1 s ∧ t = residue M (2 ^ m) * s := by
  rw [fibre_mod p M K w a, ← ham, ← fibre_mod]; exact fibre_pow p M K w m t

theorem stabilizer_loop [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) {g a' i m : Nat}
    (h3 : (p * a' + 1) % p ^ (K + 1) = (2 * g) % p ^ (K + 1))
    (hi : (2 ^ i) % p ^ (K + 1) = g % p ^ (K + 1)) (hm : (2 ^ m) % p ^ (K + 1) = a' % p ^ (K + 1)) :
    Stabilizer p M K w (fun t => unitInv M (residue M (2 ^ m)) * (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1))) := by
  have hv := p_mul_unitInv M (p := p)
  have hu := mul_unitInv M (twoPow_invertible p M hM m)
  have hP := mul_unitInv M (twoPow_invertible p M hM i)
  intro t
  constructor
  · intro ht
    have hgt : Fibre p M K w g (residue M (2 ^ i) * t) := (fibre_live p M K w hi _).2 ⟨t, ht, rfl⟩
    have has : Fibre p M K w a' (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1)) :=
      (fibre_undo_iff p M K w hM ⟨i, hi⟩ ⟨m, hm⟩ h3 _).2 ⟨_, hgt, by grind⟩
    obtain ⟨s', hs', hss⟩ := (fibre_live p M K w hm _).1 has
    show Fibre p M K w 1 (unitInv M (residue M (2 ^ m)) * (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1)))
    rw [hss]
    have : unitInv M (residue M (2 ^ m)) * (residue M (2 ^ m) * s') = s' := by grind
    rw [this]; exact hs'
  · intro ht
    have has : Fibre p M K w a' (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1)) :=
      (fibre_live p M K w hm _).2 ⟨_, ht, by grind⟩
    obtain ⟨t', ht', hst⟩ := (fibre_undo_iff p M K w hM ⟨i, hi⟩ ⟨m, hm⟩ h3 _).1 has
    have htt : t' = residue M (2 ^ i) * t := by
      apply two_mul_inj p M; rw [← hst]; grind
    rw [htt] at ht'
    obtain ⟨s, hs, hts⟩ := (fibre_live p M K w hi _).1 ht'
    have : t = s := cancel_invertible M (u := residue M (2 ^ i)) hP hts
    rw [this]; exact hs

theorem stabilizer_mul [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) {m : Nat} (hm : (2 ^ m) % p ^ (K + 1) = 1 % p ^ (K + 1)) :
    Stabilizer p M K w (fun t => residue M (2 ^ m) * t) := by
  have hP := mul_unitInv M (twoPow_invertible p M hM m)
  intro t
  constructor
  · intro ht; exact (fibre_live p M K w hm _).2 ⟨t, ht, rfl⟩
  · intro ht
    obtain ⟨s, hs, hts⟩ := (fibre_live p M K w hm _).1 ht
    rw [cancel_invertible M hP hts]; exact hs

theorem stabilizer_special_loop [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (i₀ : Nat)
    (hi₀ : (2 * 2 ^ i₀) % p ^ (K + 1) = (p + 1) % p ^ (K + 1)) :
    Stabilizer p M K w (fun t => unitInv M (residue M p) * (2 * (residue M (2 ^ i₀) * t) - 1)) := by
  have h := stabilizer_loop p M K w hM (g := 2 ^ i₀) (a' := 1) (i := i₀) (m := 0)
    (by rw [Nat.mul_one]; exact hi₀.symm) rfl (by rw [Nat.pow_zero])
  apply stabilizer_ext p M K w h
  intro t
  have h1 : unitInv M (residue M (2 ^ 0)) = 1 := unitInv_eq_of_mul M (by rw [Nat.pow_zero, residue_one]; grind)
  rw [h1]; grind

theorem stabilizer_affine_translation [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (i₀ : Nat)
    (hi₀ : (2 * 2 ^ i₀) % p ^ (K + 1) = (p + 1) % p ^ (K + 1)) {lam μ : Fin M} (hl : IsInvertible M lam)
    (hk : Stabilizer p M K w (fun t => lam * t + μ)) :
    Stabilizer p M K w
      (fun t => t + (μ + unitInv M (residue M p) - unitInv M (residue M p) * (2 * residue M (2 ^ i₀)) * μ
        - lam * unitInv M (residue M p))) := by
  have hv := p_mul_unitInv M (p := p)
  have h2 := two_mul_unitInv M (p := p)
  have hli := mul_unitInv M hl
  have hℓ := stabilizer_special_loop p M K w hM i₀ hi₀
  have hc₀i : IsInvertible M (unitInv M (residue M p) * (2 * residue M (2 ^ i₀))) :=
    isInvertible_mul M (isInvertible_unitInv M (TwoPInv.pinv (p := p)))
      (isInvertible_mul M (TwoPInv.two (p := p)) (twoPow_invertible p M hM i₀))
  have hℓv := mul_unitInv M hc₀i
  have hℓi : Stabilizer p M K w
      (fun t => unitInv M (unitInv M (residue M p) * (2 * residue M (2 ^ i₀))) * (t + unitInv M (residue M p))) :=
    stabilizer_inv p M K w hℓ (fun t => by grind)
  have hki : Stabilizer p M K w (fun t => unitInv M lam * (t - μ)) :=
    stabilizer_inv p M K w hk (fun t => by grind)
  have hc := stabilizer_comp p M K w (stabilizer_comp p M K w (stabilizer_comp p M K w hℓi hki) hℓ) hk
  exact stabilizer_ext p M K w hc (fun t => by grind)

omit [NeZero M] in
theorem exists_of_cardinality_pos {S : Fin M → Prop} (h : 1 ≤ cardinality S) : ∃ t, S t := by
  classical
  unfold cardinality at h
  obtain ⟨t, ht⟩ := List.exists_mem_of_length_pos h
  exact ⟨t, (mem_cardlist).1 ht⟩

def IsTranslationPeriod (d : Nat) : Prop := Stabilizer p M K w (fun t => t + residue M d)

theorem translationPeriod_of_eq {d : Nat} (h : residue M d = 0) : IsTranslationPeriod p M K w d :=
  stabilizer_ext p M K w (h := fun t => t) (fun _ => Iff.rfl) (fun t => by rw [h]; grind)

theorem translationPeriod_add {a b : Nat} (ha : IsTranslationPeriod p M K w a) (hb : IsTranslationPeriod p M K w b) : IsTranslationPeriod p M K w (a + b) :=
  stabilizer_ext p M K w (stabilizer_comp p M K w ha hb) (fun t => by rw [residue_add]; grind)

theorem translationPeriod_mul {a : Nat} (ha : IsTranslationPeriod p M K w a) : ∀ n, IsTranslationPeriod p M K w (a * n)
  | 0 => translationPeriod_of_eq p M K w (by rw [Nat.mul_zero]; rfl)
  | n + 1 => by rw [Nat.mul_succ]; exact translationPeriod_add p M K w (translationPeriod_mul ha n) ha

theorem translationPeriod_sub {a b : Nat} (ha : IsTranslationPeriod p M K w a) (hb : IsTranslationPeriod p M K w b) (hle : b ≤ a) :
    IsTranslationPeriod p M K w (a - b) := by
  have hbi : Stabilizer p M K w (fun t => t - residue M b) := stabilizer_inv p M K w hb (fun t => by grind)
  have hab : residue M a = residue M (a - b) + residue M b := by rw [← residue_add, Nat.sub_add_cancel hle]
  exact stabilizer_ext p M K w (stabilizer_comp p M K w ha hbi) (fun t => by rw [hab]; grind)

theorem mod_of_dvd_sub {q X Y : Nat} (hqM : q ∣ M) (h : q ∣ (residue M X - residue M Y).val) : X % q = Y % q := by
  rw [Fin.sub_def, residue_val, residue_val] at h
  have h1 : q ∣ (M - Y % M) + X % M := by
    have := (Nat.dvd_mod_iff hqM).1 h; rw [Nat.add_comm (M - Y % M)] at this ⊢; exact this
  have hlt : Y % M < M := Nat.mod_lt _ (Nat.pos_of_ne_zero (NeZero.ne M))
  have h2 : q ∣ (M - Y % M) + Y % M := by rw [Nat.sub_add_cancel (Nat.le_of_lt hlt)]; exact hqM
  have h3 := mod_add_left_cancel (m := q) (e := M - Y % M) (X := X % M) (Y := Y % M)
    (by rw [Nat.eq_zero_of_dvd_of_lt (by exact Nat.dvd_mod_iff (Nat.dvd_refl q) |>.2 h1) (Nat.mod_lt _ (Nat.pos_of_dvd_of_pos hqM (Nat.pos_of_ne_zero (NeZero.ne M)))) ,
        Nat.eq_zero_of_dvd_of_lt (by exact Nat.dvd_mod_iff (Nat.dvd_refl q) |>.2 h2) (Nat.mod_lt _ (Nat.pos_of_dvd_of_pos hqM (Nat.pos_of_ne_zero (NeZero.ne M))))])
  rwa [Nat.mod_mod_of_dvd X hqM, Nat.mod_mod_of_dvd Y hqM] at h3

omit [NeZero M] in
theorem dvd_val_mul {q : Nat} (hqM : q ∣ M) (c z : Fin M) (h : q ∣ z.val) : q ∣ (c * z).val := by
  rw [Fin.val_mul]; exact (Nat.dvd_mod_iff hqM).2 (Nat.dvd_mul_left_of_dvd h _)

theorem translationPeriod_one [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) : IsTranslationPeriod p M K w 1 := by
  obtain ⟨q, ⟨hq0, hqP⟩, hmin⟩ := exists_least (fun n => 0 < n ∧ IsTranslationPeriod p M K w n)
    ⟨M, Nat.pos_of_ne_zero (NeZero.ne M), translationPeriod_of_eq p M K w (residue_self M)⟩
  have hiff : ∀ d, IsTranslationPeriod p M K w d → q ∣ d := by
    intro d hd
    have hm := translationPeriod_sub p M K w hd (translationPeriod_mul p M K w hqP (d / q)) (Nat.mul_div_le d q)
    rw [show d - q * (d / q) = d % q by have := Nat.div_add_mod d q; omega] at hm
    apply Nat.dvd_of_mod_eq_zero
    apply Classical.byContradiction
    intro hne
    exact hmin (d % q) (Nat.mod_lt _ hq0) ⟨by omega, hm⟩
  have hqM : q ∣ M := hiff M (translationPeriod_of_eq p M K w (residue_self M))
  have hval : ∀ z : Fin M, Stabilizer p M K w (fun t => t + z) → q ∣ z.val := by
    intro z hz; apply hiff; unfold IsTranslationPeriod; rw [residue_val_self]; exact hz
  rcases Nat.lt_or_ge 1 q with hq1 | hq1
  · exfalso
    haveI : NeZero q := ⟨by omega⟩
    have hq : Nat.Coprime q p := Nat.Coprime.coprime_dvd_left hqM (cop_M_p hM)
    have hv := p_mul_unitInv M (p := p)
    obtain ⟨i₀, hi₀⟩ := undo_class p K 1
    rw [Nat.mul_one] at hi₀
    obtain ⟨T, hT0, hT⟩ := period p K
    have hA : ∀ m, 2 ^ m % p ^ (K + 1) = 1 % p ^ (K + 1) → 2 ^ m % q = 1 % q := by
      intro m hm
      have hs := stabilizer_mul p M K w hM hm
      have hs' : Stabilizer p M K w (fun t => residue M (2 ^ m) * t + 0) :=
        stabilizer_ext p M K w hs (fun t => by grind)
      have ht := hval _ (stabilizer_affine_translation p M K w hM i₀ hi₀
        (twoPow_invertible p M hM _) hs')
      have hc := dvd_val_mul M hqM (residue M p) _ ht
      have e : residue M p * ((0 : Fin M) + unitInv M (residue M p)
          - unitInv M (residue M p) * (2 * residue M (2 ^ i₀)) * 0
          - residue M (2 ^ m) * unitInv M (residue M p))
          = residue M 1 - residue M (2 ^ m) := hA_id M p _ _ _ hv
      rw [e] at hc
      exact (mod_of_dvd_sub M (X := 1) (Y := 2 ^ m) hqM hc).symm
    have hB : ∀ i m, (p * 2 ^ m + 1) % p ^ (K + 1) = (2 * 2 ^ i) % p ^ (K + 1) →
        (p * 2 ^ m + 2 * 2 ^ i₀) % q = (p + 2 * 2 ^ i) % q := by
      intro i m h3
      have hu := mul_unitInv M (twoPow_invertible p M hM m)
      have hs := stabilizer_loop p M K w hM (g := 2 ^ i) (a' := 2 ^ m) (i := i) (m := m) h3 rfl rfl
      let u := unitInv M (residue M (2 ^ m))
      let lam := u * unitInv M (residue M p) * 2 * residue M (2 ^ i)
      let μ := - (u * unitInv M (residue M p))
      have hs' : Stabilizer p M K w (fun t => lam * t + μ) :=
        stabilizer_ext p M K w hs (fun t => by simp only [lam, μ, u]; grind)
      have hl : IsInvertible M lam := by
        refine isInvertible_mul M (isInvertible_mul M (isInvertible_mul M
          (isInvertible_unitInv M (twoPow_invertible p M hM m)) ?_) ?_) (twoPow_invertible p M hM i)
        · exact isInvertible_unitInv M (TwoPInv.pinv (p := p))
        · exact TwoPInv.two (p := p)
      have ht := hval _ (stabilizer_affine_translation p M K w hM i₀ hi₀ hl hs')
      have hc1 := dvd_val_mul M hqM (residue M (p * 2 ^ m)) _ ht
      have hc2 := dvd_val_mul M hqM (residue M p) _ hc1
      apply mod_of_dvd_sub M hqM
      have e : residue M p * (residue M (p * 2 ^ m) * (μ + unitInv M (residue M p)
          - unitInv M (residue M p) * (2 * residue M (2 ^ i₀)) * μ - lam * unitInv M (residue M p)))
          = residue M (p * 2 ^ m + 2 * 2 ^ i₀) - residue M (p + 2 * 2 ^ i) :=
        hB_id M p m i i₀ u (unitInv M (residue M p)) hu hv
      rw [← e]; exact hc2
    apply Gen.period_general p K q i₀ T Base.odd hq1 hq hT0
    · exact_mod_cast Gen.cong_of_mod hT
    · intro m hm
      have hm' : 2 ^ m % p ^ (K + 1) = 1 % p ^ (K + 1) := Gen.mod_of_cong (by exact_mod_cast hm)
      exact_mod_cast Gen.cong_of_mod (hA m hm')
    · exact_mod_cast Gen.cong_of_mod hi₀
    · intro m
      obtain ⟨i, hi⟩ := undo_class p K (2 ^ m)
      exact ⟨i, by exact_mod_cast Gen.cong_of_mod hi⟩
    · intro i m him
      have h3 : (2 * 2 ^ i) % p ^ (K + 1) = (p * 2 ^ m + 1) % p ^ (K + 1) :=
        Gen.mod_of_cong (by exact_mod_cast him)
      exact_mod_cast Gen.cong_of_mod (hB i m h3.symm)
  · have : q = 1 := by omega
    subst this
    exact translationPeriod_mul p M K w hqP 1 |> fun h => by simpa using h

theorem fibre_one_full [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) (t : Fin M) : Fibre p M K w 1 t := by
  obtain ⟨iw, hiw⟩ := hw
  have hw0 : Fibre p M K w w (residue M w) :=
    ⟨w, Closure.base 0 w (by unfold SameMod; rw [Nat.pow_zero, Nat.one_mul]), rfl, rfl⟩
  have hc : 1 ≤ cardinality (Fibre p M K w 1) :=
    Nat.le_trans (cardinality_pos hw0)
      (fibre_cardinality_le_live p M K w (w_inG p hiw K) ⟨0, by rw [Nat.pow_zero]⟩)
  obtain ⟨t0, ht0⟩ := exists_of_cardinality_pos M hc
  have hp : IsTranslationPeriod p M K w (t - t0).val := by
    have := translationPeriod_mul p M K w (translationPeriod_one p M K w hM) (t - t0).val; rwa [Nat.one_mul] at this
  have := (hp t0).1 ht0
  change Fibre p M K w 1 (t0 + residue M (t - t0).val) at this
  rw [residue_val_self] at this
  have e : t0 + (t - t0) = t := by grind
  rw [e] at this; exact this

theorem fibre_full_live [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) {a : Nat} (ha : InG p K a)
    (t : Fin M) : Fibre p M K w a t := by
  obtain ⟨m, hm⟩ := ha
  have hu := mul_unitInv M (twoPow_invertible p M hM m)
  exact (fibre_live p M K w (m := m) hm t).2
    ⟨unitInv M (residue M (2 ^ m)) * t, fibre_one_full p M K w hM hw _, by grind⟩

theorem fibre_full [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) (a : Nat) (t : Fin M) :
    Fibre p M K w a t := by
  obtain ⟨i, hi⟩ := undo_class p K a
  have h2i := two_mul_unitInv M (p := p)
  obtain ⟨y, hy, hyg, hyt⟩ := fibre_full_live p M K w hM hw (inG_pow p K i) (unitInv M 2 * (residue M p * t + 1))
  have hcop : Nat.Coprime M (p ^ (K + 1)) := Nat.Coprime.pow_right _ (cop_M_p hM)
  obtain ⟨x, hx3, hxM⟩ := crt_exists hcop a t.val
  have hxt : residue M x = t := by rw [← residue_self_val t, residue_eq_iff]; exact hxM
  refine ⟨x, Closure.undo hy ?_, hx3, hxt⟩
  unfold SameMod
  apply mod_combine (Nat.Coprime.symm hcop)
  · rw [Nat.add_mod, Nat.mul_mod, hx3, ← Nat.mul_mod, ← Nat.add_mod, ← hi,
      Nat.mul_mod, ← hyg, ← Nat.mul_mod]
  · rw [← residue_eq_iff, residue_add, residue_mul, residue_mul, residue_one, residue_two, hxt, hyt]; grind

theorem closure_all (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) (x : Nat) : Closure p (p ^ (K + 1) * M) w x := by
  haveI : TwoPInv p M := twoPInv_of_coprime hM
  obtain ⟨x', hx', h1, h2⟩ := fibre_full p M K w hM hw x (residue M x)
  apply Closure.cong hx'
  unfold SameMod
  have hcop : Nat.Coprime (p ^ (K + 1)) M := Nat.Coprime.symm (Nat.Coprime.pow_right _ (cop_M_p hM))
  exact mod_combine hcop h1.symm ((residue_eq_iff M x x').1 h2.symm)

end Fibres

end PX
