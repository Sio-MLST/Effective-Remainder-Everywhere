/- Formalisation of the effective remainder theorem for the px+1 map (odd p); intended as the basis of a later paper. -/
namespace Gen

def tri : Nat → Nat
  | 0 => 0
  | n + 1 => tri n + n

theorem tri_two (n : Nat) : 2 * tri n = n * (n - 1) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    show 2 * (tri n + n) = (n + 1) * n
    rw [Nat.mul_add, ih]; cases n with
    | zero => rfl
    | succ n => simp; grind

theorem pow_expand (a : Nat) : ∀ n, ∃ z, (1 + a) ^ n = 1 + n * a + tri n * a ^ 2 + a ^ 3 * z
  | 0 => ⟨0, by simp [tri]⟩
  | n + 1 => by
    obtain ⟨z, hz⟩ := pow_expand a n
    refine ⟨tri n + z + z * a, ?_⟩
    rw [Nat.pow_succ, hz]; show _ = 1 + (n + 1) * a + (tri n + n) * a ^ 2 + a ^ 3 * (tri n + z + z * a)
    grind

theorem pow_expand2 (a : Nat) : ∀ n, ∃ z, (1 + a) ^ n = 1 + n * a + a ^ 2 * z := by
  intro n; obtain ⟨z, hz⟩ := pow_expand a n
  exact ⟨tri n + a * z, by rw [hz]; grind⟩

theorem lte_step {p j u : Nat} (hp : p % 2 = 1) (hj : 1 ≤ j) (hu : Nat.Coprime p u) :
    ∃ w, Nat.Coprime p w ∧ (1 + p ^ j * u) ^ p = 1 + p ^ (j + 1) * w := by
  obtain ⟨z, hz⟩ := pow_expand (p ^ j * u) p
  obtain ⟨h, hh⟩ : ∃ h, tri p = p * h := by
    refine ⟨(p - 1) / 2, ?_⟩
    have := tri_two p
    have : (p - 1) % 2 = 0 := by omega
    have e : p - 1 = 2 * ((p - 1) / 2) := by omega
    rw [e] at *; grind
  obtain ⟨k, rfl⟩ : ∃ k, j = k + 1 := ⟨j - 1, by omega⟩
  let w := u + p * (h * p ^ k * u ^ 2 + p ^ (2 * k) * u ^ 3 * z)
  refine ⟨w, ?_, ?_⟩
  · show Nat.Coprime p (u + p * _)
    rw [Nat.Coprime, Nat.gcd_add_mul_left_right]; exact hu
  · rw [hz, hh]
    show _ = 1 + p ^ (k + 1 + 1) * (u + p * (h * p ^ k * u ^ 2 + p ^ (2 * k) * u ^ 3 * z))
    have e1 : p ^ (k + 1 + 1) = p * p * p ^ k := by rw [Nat.pow_succ, Nat.pow_succ]; grind
    have e2 : p ^ (k + 1) = p * p ^ k := by rw [Nat.pow_succ]; grind
    have e3 : p ^ (2 * k) = p ^ k * p ^ k := by rw [Nat.two_mul, Nat.pow_add]
    rw [e1, e2, e3]; generalize p ^ k = A; grind

theorem lte {p u : Nat} (hp : p % 2 = 1) (hu : Nat.Coprime p u) :
    ∀ n, ∃ w, Nat.Coprime p w ∧ (1 + p * u) ^ (p ^ n) = 1 + p ^ (n + 1) * w
  | 0 => ⟨u, hu, by simp⟩
  | n + 1 => by
    obtain ⟨w, hw, hx⟩ := lte hp hu n
    obtain ⟨w', hw', hx'⟩ := lte_step (j := n + 1) hp (by omega) hw
    exact ⟨w', hw', by rw [Nat.pow_succ, Nat.pow_mul, hx, hx']⟩

theorem order_iff {p u : Nat} (hp : p % 2 = 1) (hp3 : 3 ≤ p) (hu : Nat.Coprime p u) :
    ∀ K m, (1 + p * u) ^ m % p ^ (K + 1) = 1 ↔ p ^ K ∣ m := by
  have hP : ∀ K, 1 < p ^ (K + 1) := fun K =>
    Nat.lt_of_lt_of_le (by omega) (Nat.le_self_pow (by omega) p)
  intro K
  induction K with
  | zero =>
    intro m
    obtain ⟨z, hz⟩ := pow_expand2 (p * u) m
    simp only [Nat.pow_zero, Nat.one_dvd, iff_true, Nat.zero_add, Nat.pow_one]
    rw [hz, show 1 + m * (p * u) + (p * u) ^ 2 * z = 1 + p * (m * u + p * u ^ 2 * z) by grind,
      Nat.add_mul_mod_self_left]; exact Nat.mod_eq_of_lt (by omega)
  | succ K ih =>
    intro m
    constructor
    · intro h
      have h1 : (1 + p * u) ^ m % p ^ (K + 1) = 1 := by
        rw [← Nat.mod_mod_of_dvd _ (Nat.pow_dvd_pow p (by omega : K + 1 ≤ K + 1 + 1)), h]
        exact Nat.mod_eq_of_lt (hP K)
      obtain ⟨k, rfl⟩ := (ih m).1 h1
      by_cases hpk : p ∣ k
      · obtain ⟨k', rfl⟩ := hpk; exact ⟨k', by rw [Nat.pow_succ]; grind⟩
      · exfalso
        obtain ⟨w, hw, hx⟩ := lte hp hu K
        obtain ⟨z, hz⟩ := pow_expand2 (p ^ (K + 1) * w) k
        rw [Nat.pow_mul, hx, hz,
          show 1 + k * (p ^ (K + 1) * w) + (p ^ (K + 1) * w) ^ 2 * z
            = 1 + p ^ (K + 1) * (k * w + p ^ (K + 1) * (w ^ 2 * z)) by grind,
          show p ^ (K + 1 + 1) = p ^ (K + 1) * p by rw [Nat.pow_succ]] at h
        have hd : p ^ (K + 1) * p ∣ p ^ (K + 1) * (k * w + p ^ (K + 1) * (w ^ 2 * z)) := by
          have h2 := Nat.sub_mod_eq_zero_of_mod_eq
            (h.trans (Nat.mod_eq_of_lt (by have := hP (K + 1); rwa [Nat.pow_succ] at this)).symm)
          simpa using Nat.dvd_of_mod_eq_zero h2
        have hd2 := Nat.dvd_of_mul_dvd_mul_left (Nat.pow_pos (by omega)) hd
        have hd3 : p ∣ p ^ (K + 1) * (w ^ 2 * z) :=
          Nat.dvd_trans ⟨p ^ K, by rw [Nat.pow_succ, Nat.mul_comm]⟩ (Nat.dvd_mul_right _ _)
        have hkw : p ∣ k * w := (Nat.dvd_add_left hd3).1 hd2
        exact hpk (Nat.Coprime.dvd_of_dvd_mul_right hw hkw)
    · rintro ⟨k, rfl⟩
      obtain ⟨w, hw, hx⟩ := lte hp hu (K + 1)
      rw [Nat.pow_mul, hx, Nat.pow_mod, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt (hP _),
        Nat.one_pow, Nat.mod_eq_of_lt (hP _)]

def Cong (n : Nat) (a b : Int) : Prop := (n : Int) ∣ a - b

theorem Cong.refl (n : Nat) (a : Int) : Cong n a a := by simp [Cong]
theorem Cong.symm {n : Nat} {a b : Int} (h : Cong n a b) : Cong n b a := by
  unfold Cong at *; have := Int.dvd_neg.2 h; rwa [Int.neg_sub] at this
theorem Cong.trans {n : Nat} {a b c : Int} (h1 : Cong n a b) (h2 : Cong n b c) : Cong n a c := by
  unfold Cong at *; have := Int.dvd_add h1 h2; rwa [show a - b + (b - c) = a - c by omega] at this
theorem Cong.mul {n : Nat} {a b c d : Int} (h1 : Cong n a b) (h2 : Cong n c d) : Cong n (a * c) (b * d) := by
  unfold Cong at *
  have e : a * c - b * d = (a - b) * c + b * (c - d) := by
    rw [Int.sub_mul, Int.mul_sub]; omega
  rw [e]; exact Int.dvd_add (Int.dvd_trans h1 (Int.dvd_mul_right _ c)) (Int.dvd_trans h2 (Int.dvd_mul_left b _))
theorem Cong.of_dvd {n n' : Nat} {a b : Int} (hd : n ∣ n') (h : Cong n' a b) : Cong n a b :=
  Int.dvd_trans (Int.natCast_dvd_natCast.2 hd) h
theorem Cong.pow_one {n : Nat} {a : Int} (h : Cong n a 1) : ∀ k, Cong n (a ^ k) 1
  | 0 => by simp [Cong]
  | k + 1 => by rw [Int.pow_succ, show (1 : Int) = 1 * 1 from rfl]; exact (Cong.pow_one h k).mul h
theorem Cong.cancel {n c : Nat} {a b : Int} (hc : Nat.Coprime n c) (h : Cong n ((c : Int) * a) ((c : Int) * b)) :
    Cong n a b := by
  unfold Cong at *
  rw [← Int.mul_sub, Int.ofNat_dvd_left, Int.natAbs_mul, Int.natAbs_natCast] at h
  exact Int.ofNat_dvd_left.2 (Nat.Coprime.dvd_of_dvd_mul_left hc h)
theorem Cong.sub {n : Nat} {a b c d : Int} (h1 : Cong n a b) (h2 : Cong n c d) : Cong n (a - c) (b - d) := by
  unfold Cong at *; have := Int.dvd_sub h1 h2; rwa [show a - c - (b - d) = a - b - (c - d) by omega]

theorem coprime_two_of_odd {p : Nat} (hp : p % 2 = 1) : Nat.Coprime p 2 := by
  unfold Nat.Coprime; rw [Nat.gcd_comm, Nat.gcd_rec, hp]; rfl

theorem period_general (p K q i₀ T : Nat) (hp : p % 2 = 1) (hq1 : 1 < q) (hqp : Nat.Coprime q p)
    (hT1 : 1 ≤ T) (hT : Cong (p ^ (K + 1)) (2 ^ T) 1)
    (hA : ∀ m, Cong (p ^ (K + 1)) (2 ^ m) 1 → Cong q (2 ^ m) 1)
    (hi₀ : Cong (p ^ (K + 1)) (2 * 2 ^ i₀) (p + 1))
    (hGen : ∀ m, ∃ i, Cong (p ^ (K + 1)) (2 * 2 ^ i) (p * 2 ^ m + 1))
    (hB : ∀ i m, Cong (p ^ (K + 1)) (2 * 2 ^ i) (p * 2 ^ m + 1) →
      Cong q (p * 2 ^ m + 2 * 2 ^ i₀) (p + 2 * 2 ^ i)) : False := by
  have hTq : Cong q (2 ^ T) 1 := hA T hT
  have S : ∀ d, d ≤ K + 1 → ∀ m, Cong (p ^ (K + 1 - d)) (2 ^ m) 1 → Cong q (2 ^ m) 1 := by
    intro d
    induction d with
    | zero => intro _ m h; exact hA m h
    | succ d ih =>
      intro hd m hm
      have hj : K + 1 - d = (K + 1 - (d + 1)) + 1 := by omega
      have hdiv : p ^ (K + 1 - d) ∣ p ^ (K + 1) := Nat.pow_dvd_pow p (by omega)
      obtain ⟨i, hi⟩ := hGen m

      have hpm : Cong (p ^ (K + 1 - d)) ((p : Int) * 2 ^ m) p := by
        unfold Cong at hm ⊢
        rw [hj, Nat.pow_succ, Nat.mul_comm, Int.natCast_mul,
          show (p : Int) * 2 ^ m - p = p * (2 ^ m - 1) by rw [Int.mul_sub, Int.mul_one]]
        exact Int.mul_dvd_mul_left _ hm
      have h2 : Cong (p ^ (K + 1 - d)) (2 * 2 ^ i) (2 * 2 ^ i₀) := by
        have a := (hi.of_dvd hdiv).sub (hi₀.of_dvd hdiv)
        have b := (hpm.sub (Cong.refl _ (p : Int)))
        refine Cong.trans (b := (p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀) ?_ ?_
        · unfold Cong at a ⊢; rwa [show (2 : Int) * 2 ^ i - ((p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀)
            = 2 * 2 ^ i - 2 * 2 ^ i₀ - ((p : Int) * 2 ^ m + 1 - (p + 1)) by omega]
        · unfold Cong at b ⊢; rwa [show (p : Int) * 2 ^ m + 1 - (p + 1) + 2 * 2 ^ i₀ - 2 * 2 ^ i₀
            = (p : Int) * 2 ^ m - p - (p - p) by omega]
      have h2' : Cong (p ^ (K + 1 - d)) (2 ^ i) (2 ^ i₀) :=
        Cong.cancel (c := 2) (Nat.Coprime.pow_left _ (coprime_two_of_odd hp)) (by exact_mod_cast h2)
      let m' := i + i₀ * (T - 1)
      have hsplit : (2 : Int) ^ m' * 2 ^ i₀ = 2 ^ i * (2 ^ T) ^ i₀ := by
        rw [← Int.pow_add, ← Int.pow_mul, ← Int.pow_add]; congr 1
        show i + i₀ * (T - 1) + i₀ = i + T * i₀
        rw [Nat.mul_comm T, Nat.add_assoc, ← Nat.mul_succ, show (T - 1).succ = T by omega]
      have hm'P : Cong (p ^ (K + 1 - d)) (2 ^ m' * 2 ^ i₀) (1 * 2 ^ i₀) := by
        rw [hsplit, Int.one_mul]
        have := (Cong.refl _ ((2 : Int) ^ i)).mul ((hT.of_dvd hdiv).pow_one i₀)
        rw [Int.mul_one] at this; exact this.trans h2'
      have hm' : Cong (p ^ (K + 1 - d)) (2 ^ m') 1 := by
        rw [Int.mul_comm, Int.mul_comm (1 : Int)] at hm'P
        exact Cong.cancel (c := 2 ^ i₀) (Nat.Coprime.pow _ _ (coprime_two_of_odd hp))
          (by exact_mod_cast hm'P)
      have hq' := ih (by omega) m' hm'
      have hiq : Cong q (2 ^ i) (2 ^ i₀) := by
        have a := hq'.mul (Cong.refl q ((2 : Int) ^ i₀))
        rw [hsplit, Int.one_mul] at a
        have b := (Cong.refl q ((2 : Int) ^ i)).mul (hTq.pow_one i₀)
        rw [Int.mul_one] at b; exact b.symm.trans a
      have hBq := hB i m hi
      have c1 : Cong q ((p : Int) * 2 ^ m) ((p : Int) * 1) := by
        have := hBq.sub ((Cong.refl q (2 : Int)).mul hiq |>.symm)
        unfold Cong at this ⊢
        rwa [show (p : Int) * 2 ^ m + 2 * 2 ^ i₀ - 2 * 2 ^ i₀ - (p + 2 * 2 ^ i - 2 * 2 ^ i)
          = p * 2 ^ m - p * 1 by omega] at this
      exact Cong.cancel hqp c1
  have h := S (K + 1) (Nat.le_refl _) 1 (by rw [Nat.sub_self, Nat.pow_zero]; exact Int.one_dvd _)
  unfold Cong at h
  have := Int.le_of_dvd (by decide) h
  omega

theorem cong_of_mod {n a b : Nat} (h : a % n = b % n) : Cong n (a : Int) (b : Int) := by
  have h' : ((a:Int) % n) = ((b:Int) % n) := by exact_mod_cast h
  exact Int.dvd_of_emod_eq_zero (Int.emod_eq_emod_iff_emod_sub_eq_zero.mp h')

theorem mod_of_cong {n a b : Nat} (h : Cong n (a : Int) (b : Int)) : a % n = b % n := by
  have := Int.emod_eq_emod_iff_emod_sub_eq_zero.mpr (Int.emod_eq_zero_of_dvd h)
  exact_mod_cast this

theorem mod_cancel_mul_left {m a x y : Nat} (hcop : Nat.Coprime m a) (hxy : y ≤ x)
    (h : (a * x) % m = (a * y) % m) : x % m = y % m := by
  have h1 := Nat.sub_mod_eq_zero_of_mod_eq h
  have h2 : a * x - a * y = a * (x - y) := (Nat.mul_sub a x y).symm
  rw [h2] at h1
  have h3 : m ∣ a * (x - y) := Nat.dvd_of_mod_eq_zero h1
  have h4 : m ∣ x - y := Nat.Coprime.dvd_of_dvd_mul_left hcop h3
  have h5 := Nat.mod_eq_zero_of_dvd h4
  have h6 : x = y + (x - y) := by omega
  rw [h6, Nat.add_mod, h5]; simp

theorem coprime_of_mod_one {p x : Nat} (h : x % p = 1) : Nat.Coprime p x := by
  unfold Nat.Coprime; rw [Nat.gcd_rec, h, Nat.gcd_one_left]

theorem pow_mod_one {p x : Nat} (hp : 2 ≤ p) (h : x % p = 1) (t : Nat) : x ^ t % p = 1 := by
  rw [Nat.pow_mod, h, Nat.one_pow]; exact Nat.mod_eq_of_lt (by omega)

theorem gen_unit {p u : Nat} (hp : p % 2 = 1) (hp3 : 3 ≤ p) (hu : Nat.Coprime p u)
    (K x : Nat) (hx : x % p = 1) : ∃ t, t < p ^ K ∧ (1 + p * u) ^ t % p ^ (K + 1) = x % p ^ (K + 1) := by
  apply Classical.byContradiction
  intro hno
  have hP : 0 < p ^ (K + 1) := Nat.pow_pos (by omega)
  have hpK : 0 < p ^ K := Nat.pow_pos (by omega)
  have hPe : p ^ (K + 1) = p * p ^ K := by rw [Nat.pow_succ, Nat.mul_comm]
  have hdv : p ∣ p ^ (K + 1) := ⟨p ^ K, hPe⟩
  have hc1 : (1 + p * u) % p = 1 := by rw [Nat.add_mul_mod_self_left]; exact Nat.mod_eq_of_lt (by omega)
  have hcop : Nat.Coprime (p ^ (K + 1)) (1 + p * u) := Nat.Coprime.pow_left _ (coprime_of_mod_one hc1)
  let U : List Nat := (List.range (p ^ (K + 1))).filter (fun y => decide (y % p = 1))
  let L1 : List Nat := (List.range (p ^ K)).map (fun t => (1 + p * u) ^ t % p ^ (K + 1))
  have hUnodup : U.Nodup := List.Pairwise.filter _ List.nodup_range
  have key : ∀ a b, a ≤ b → b < p ^ K →
      (1 + p * u) ^ a % p ^ (K + 1) = (1 + p * u) ^ b % p ^ (K + 1) → a = b := by
    intro a b hab hb h
    have hb' : (1 + p * u) ^ b = (1 + p * u) ^ a * (1 + p * u) ^ (b - a) := by
      rw [← Nat.pow_add]; congr 1; omega
    have h' : ((1 + p * u) ^ a * (1 + p * u) ^ (b - a)) % p ^ (K + 1)
        = ((1 + p * u) ^ a * 1) % p ^ (K + 1) := by rw [← hb', Nat.mul_one]; exact h.symm
    have h'' := mod_cancel_mul_left (Nat.Coprime.pow_right a hcop)
      (Nat.pow_pos (Nat.lt_of_lt_of_le Nat.one_pos (Nat.le_add_right 1 _))) h'
    have h1P : 1 % p ^ (K + 1) = 1 :=
      Nat.mod_eq_of_lt (Nat.lt_of_lt_of_le (by omega) (Nat.le_self_pow (by omega) p))
    rw [h1P] at h''
    have hd := (order_iff hp hp3 hu K (b - a)).1 h''
    have : b - a = 0 := Nat.eq_zero_of_dvd_of_lt hd (by omega)
    omega
  have hL1nodup : L1.Nodup := by
    apply List.pairwise_map.2
    apply List.Pairwise.imp_of_mem _ List.nodup_range
    intro a b ha hb hab heq
    rw [List.mem_range] at ha hb
    rcases Nat.le_total a b with hle | hle
    · exact hab (key a b hle hb heq)
    · exact hab (key b a hle ha heq.symm).symm
  have hL1U : L1 ⊆ U := by
    intro y hy
    rw [List.mem_map] at hy
    obtain ⟨t, _, rfl⟩ := hy
    rw [List.mem_filter, List.mem_range]
    refine ⟨Nat.mod_lt _ hP, ?_⟩
    rw [Nat.mod_mod_of_dvd _ hdv, pow_mod_one (by omega) hc1]; simp
  have hxU : x % p ^ (K + 1) ∈ U := by
    rw [List.mem_filter, List.mem_range]
    refine ⟨Nat.mod_lt _ hP, ?_⟩
    rw [Nat.mod_mod_of_dvd _ hdv, hx]; simp
  have hxL : x % p ^ (K + 1) ∉ L1 := by
    intro h; rw [List.mem_map] at h
    obtain ⟨t, ht, he⟩ := h
    exact hno ⟨t, List.mem_range.1 ht, he⟩
  have hsub : (x % p ^ (K + 1) :: L1) ⊆ U := by
    intro y hy
    rcases List.mem_cons.1 hy with h | h
    · rw [h]; exact hxU
    · exact hL1U h
  have hlen1 := (List.nodup_cons.2 ⟨hxL, hL1nodup⟩).length_le_of_subset hsub
  have hUsub : U ⊆ (List.range (p ^ K)).map (fun j => p * j + 1) := by
    intro y hy
    rw [List.mem_filter, List.mem_range] at hy
    obtain ⟨hy1, hy2⟩ := hy
    have hy2' : y % p = 1 := by simpa using hy2
    rw [List.mem_map]
    refine ⟨y / p, List.mem_range.2 ((Nat.div_lt_iff_lt_mul (by omega)).2 (by rw [← hPe, Nat.mul_comm] at *; rw [Nat.mul_comm]; rwa [hPe] at hy1)), ?_⟩
    have := Nat.div_add_mod y p; omega
  have hlen2 : U.length ≤ p ^ K := by
    have := hUnodup.length_le_of_subset hUsub; simpa using this
  have hL1len : L1.length = p ^ K := by simp [L1]
  simp only [List.length_cons] at hlen1
  omega

end Gen

namespace PX

set_option linter.unusedSectionVars false

class Base (p : Nat) : Prop where
  odd : p % 2 = 1
  three_le : 3 ≤ p
  gen : ∃ d u, 0 < d ∧ d ≤ p ∧ 2 ^ d = 1 + p * u ∧ Nat.Coprime p u

theorem pow_mod_period {b y n : Nat} (h : b ^ y % n = 1 % n) (x : Nat) :
    ∀ N, b ^ (x + y * N) % n = b ^ x % n
  | 0 => by simp
  | N + 1 => by
    rw [Nat.mul_succ, ← Nat.add_assoc, Nat.pow_add, Nat.mul_mod, pow_mod_period h x N, h,
      ← Nat.mul_mod, Nat.mul_one]

section Basics
variable (p : Nat) [Base p]

theorem p_dvd_pow (K : Nat) : p ∣ p ^ (K + 1) := ⟨p ^ K, by rw [Nat.pow_succ, Nat.mul_comm]⟩

theorem one_lt_powp (K : Nat) : 1 < p ^ (K + 1) :=
  Nat.one_lt_pow (Nat.succ_ne_zero K) (by have := Base.three_le (p := p); omega)

theorem powp_pos (K : Nat) : 0 < p ^ K := Nat.pow_pos (by have := Base.three_le (p := p); omega)

theorem coprime_p_two : Nat.Coprime p 2 := Gen.coprime_two_of_odd Base.odd

theorem powp_odd (n : Nat) : p ^ n % 2 = 1 := by
  rw [Nat.pow_mod, Base.odd (p := p), Nat.one_pow]

theorem one_mod_P (K : Nat) : 1 % p ^ (K + 1) = 1 := Nat.mod_eq_of_lt (one_lt_powp p K)

theorem period (K : Nat) : ∃ T, 0 < T ∧ 2 ^ T % p ^ (K + 1) = 1 % p ^ (K + 1) := by
  obtain ⟨d, u, hd0, -, hd, hu⟩ := Base.gen (p := p)
  refine ⟨d * p ^ K, Nat.mul_pos hd0 (powp_pos p K), ?_⟩
  rw [Nat.pow_mul, hd, one_mod_P]
  exact (Gen.order_iff Base.odd Base.three_le hu K _).2 (Nat.dvd_refl _)

theorem two_gen (K x : Nat) (hx : x % p = 1) : ∃ s, 2 ^ s % p ^ (K + 1) = x % p ^ (K + 1) := by
  obtain ⟨d, u, _, -, hd, hu⟩ := Base.gen (p := p)
  obtain ⟨t, _, ht⟩ := Gen.gen_unit Base.odd Base.three_le hu K x hx
  exact ⟨d * t, by rw [Nat.pow_mul, hd]; exact ht⟩

def InG (K a : Nat) : Prop := ∃ m, 2 ^ m % p ^ (K + 1) = a % p ^ (K + 1)

theorem inG_ratio {K a b : Nat} (ha : InG p K a) (hb : InG p K b) :
    ∃ j, (2 ^ j * a) % p ^ (K + 1) = b % p ^ (K + 1) := by
  obtain ⟨m, hm⟩ := ha
  obtain ⟨n, hn⟩ := hb
  obtain ⟨T, hT0, hT⟩ := period p K
  refine ⟨n + m * (T - 1), ?_⟩
  rw [Nat.mul_mod, ← hm, ← Nat.mul_mod, ← Nat.pow_add, ← hn]
  have e : n + m * (T - 1) + m = n + T * m := by
    rw [Nat.add_assoc, Nat.mul_comm T m]
    have : m * (T - 1) + m = m * T := by
      rw [← Nat.mul_succ]; congr 1; omega
    omega
  rw [e]; exact pow_mod_period hT n m

theorem inG_pow (K m : Nat) : InG p K (2 ^ m) := ⟨m, rfl⟩

theorem undo_class (K a : Nat) : ∃ i, (2 * 2 ^ i) % p ^ (K + 1) = (p * a + 1) % p ^ (K + 1) := by
  have h1 : (p * a + 1) % p = 1 := by
    rw [Nat.mul_add_mod]; exact Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)
  obtain ⟨s, hs⟩ := two_gen p K _ h1
  obtain ⟨T, hT0, hT⟩ := period p K
  refine ⟨s + (T - 1), ?_⟩
  rw [← hs, show 2 * 2 ^ (s + (T - 1)) = 2 ^ (s + T * 1) by
    rw [← Nat.pow_succ']; congr 1; omega]
  exact pow_mod_period hT s 1

theorem w_inG {w i : Nat} (hw : w % p = 2 ^ i % p) (K : Nat) : InG p K w := by
  obtain ⟨T, hT0, hT⟩ := period p K
  have hTp : 2 ^ T % p = 1 := by
    rw [← Nat.mod_mod_of_dvd _ (p_dvd_pow p K), hT, one_mod_P,
      Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)]
  have h1 : (2 ^ (i * (T - 1)) * w) % p = 1 := by
    rw [Nat.mul_mod, hw, ← Nat.mul_mod, ← Nat.pow_add,
      show i * (T - 1) + i = T * i by rw [Nat.mul_comm T i, ← Nat.mul_succ]; congr 1; omega,
      Nat.pow_mul, Nat.pow_mod, hTp, Nat.one_pow]
    exact Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)
  obtain ⟨s, hs⟩ := two_gen p K _ h1
  refine ⟨s + i, ?_⟩
  rw [Nat.pow_add, Nat.mul_mod, hs, ← Nat.mul_mod, Nat.mul_assoc, Nat.mul_comm w, ← Nat.mul_assoc,
    ← Nat.pow_add, show i * (T - 1) + i = 0 + T * i by
      rw [Nat.zero_add, Nat.mul_comm T i, ← Nat.mul_succ]; congr 1; omega,
    Nat.mul_mod, pow_mod_period hT 0 i, ← Nat.mul_mod, Nat.pow_zero, Nat.one_mul]

end Basics

section Map
variable (p : Nat) [Base p]

def collatz (n : Nat) : Nat := if n % 2 = 0 then n / 2 else p * n + 1

def iter (f : Nat → Nat) : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => iter f k (f n)

theorem iter_add (f : Nat → Nat) (m n : Nat) : ∀ x, iter f (m + n) x = iter f m (iter f n x) := by
  induction n with
  | zero => intro x; rfl
  | succ n ih => intro x; exact ih (f x)

def Reaches (v n : Nat) : Prop := ∃ k, iter (collatz p) k n = v

theorem collatz_double (a : Nat) : collatz p (2 * a) = a := by
  unfold collatz; split <;> omega

theorem reaches_trans {a b c : Nat} (h1 : Reaches p b a) (h2 : Reaches p c b) : Reaches p c a := by
  obtain ⟨k1, hk1⟩ := h1
  obtain ⟨k2, hk2⟩ := h2
  exact ⟨k2 + k1, by rw [iter_add, hk1, hk2]⟩

end Map

theorem mod_cancel_mul_left {m a x y : Nat} (hcop : Nat.Coprime m a) (hxy : y ≤ x)
    (h : (a * x) % m = (a * y) % m) : x % m = y % m := by
  have h1 := Nat.sub_mod_eq_zero_of_mod_eq h
  have h2 : a * x - a * y = a * (x - y) := (Nat.mul_sub a x y).symm
  rw [h2] at h1
  have h3 : m ∣ a * (x - y) := Nat.dvd_of_mod_eq_zero h1
  have h4 : m ∣ x - y := Nat.Coprime.dvd_of_dvd_mul_left hcop h3
  have h5 := Nat.mod_eq_zero_of_dvd h4
  have h6 : x = y + (x - y) := by omega
  rw [h6, Nat.add_mod, h5]; simp

theorem mod_cancel_mul_right {m c x y : Nat} (hcop : Nat.Coprime m c)
    (h : (x * c) % m = (y * c) % m) : x % m = y % m := by
  rcases Nat.le_total y x with hle | hle
  · exact mod_cancel_mul_left hcop hle (by rwa [Nat.mul_comm c x, Nat.mul_comm c y])
  · exact (mod_cancel_mul_left hcop hle (by rw [Nat.mul_comm c x, Nat.mul_comm c y]; exact h.symm)).symm

section Residues
variable (M : Nat) [NeZero M]

def residue (n : Nat) : Fin M := Fin.ofNat M n

theorem residue_val (n : Nat) : (residue M n).val = n % M := Fin.val_ofNat M n

theorem residue_eq_iff (a b : Nat) : residue M a = residue M b ↔ a % M = b % M := by
  constructor
  · intro h; have := congrArg Fin.val h; rwa [residue_val, residue_val] at this
  · intro h; apply Fin.ext; rw [residue_val, residue_val]; exact h

theorem residue_add (a b : Nat) : residue M (a + b) = residue M a + residue M b := by
  apply Fin.ext; rw [Fin.val_add, residue_val, residue_val, residue_val, Nat.add_mod]

theorem residue_mul (a b : Nat) : residue M (a * b) = residue M a * residue M b := by
  apply Fin.ext; rw [Fin.val_mul, residue_val, residue_val, residue_val, Nat.mul_mod]

theorem residue_zero : residue M 0 = (0 : Fin M) := rfl
theorem residue_one : residue M 1 = (1 : Fin M) := rfl
theorem residue_two : residue M 2 = (2 : Fin M) := rfl
class TwoPInv (p M : Nat) [NeZero M] : Prop where
  two : ∃ b : Fin M, (2 : Fin M) * b = 1
  pinv : ∃ b : Fin M, residue M p * b = 1

open Classical in
noncomputable def unitInv (a : Fin M) : Fin M := if h : ∃ b : Fin M, a * b = 1 then h.choose else 0

theorem mul_unitInv {a : Fin M} (h : ∃ b : Fin M, a * b = 1) : a * unitInv M a = 1 := by
  unfold unitInv
  split
  · rename_i h'; exact h'.choose_spec
  · rename_i h'; exact absurd h h'

theorem two_mul_unitInv {p : Nat} [TwoPInv p M] : (2 : Fin M) * unitInv M 2 = 1 := mul_unitInv M (TwoPInv.two (p := p))
theorem p_mul_unitInv {p : Nat} [TwoPInv p M] : residue M p * unitInv M (residue M p) = 1 := mul_unitInv M TwoPInv.pinv

theorem hA_id (p : Nat) (T r v : Fin M) (h5 : residue M p * v = 1) :
    residue M p * ((0 : Fin M) + v - T * (0 : Fin M) - r * v) = residue M 1 - r := by
  rw [residue_one]
  grind

theorem hB_id (p m i i₀ : Nat) (u v : Fin M)
    (hu : residue M (2 ^ m) * u = 1) (h5 : residue M p * v = 1) :
    residue M p * (residue M (p * 2 ^ m) * (-(u * v) + v
        - v * (2 * residue M (2 ^ i₀)) * -(u * v)
        - u * v * 2 * residue M (2 ^ i) * v))
      = residue M (p * 2 ^ m + 2 * 2 ^ i₀) - residue M (p + 2 * 2 ^ i) := by
  rw [residue_mul M p (2 ^ m), residue_add M (p * 2 ^ m) (2 * 2 ^ i₀),
    residue_add M p (2 * 2 ^ i), residue_mul M p (2 ^ m), residue_mul M 2 (2 ^ i₀),
    residue_mul M 2 (2 ^ i), residue_two]
  grind

theorem cancel_invertible {u v a b : Fin M} (hu : u * v = 1) (h : u * a = u * b) : a = b := by
  calc a = (u * v) * a := by rw [hu]; grind
    _ = v * (u * a) := by grind
    _ = v * (u * b) := by rw [h]
    _ = (u * v) * b := by grind
    _ = b := by rw [hu]; grind

def IsInvertible (a : Fin M) : Prop := ∃ b : Fin M, a * b = 1

theorem isInvertible_mul {a b : Fin M} (ha : IsInvertible M a) (hb : IsInvertible M b) : IsInvertible M (a * b) := by
  obtain ⟨ia, hia⟩ := ha
  obtain ⟨ib, hib⟩ := hb
  exact ⟨ib * ia, by
    calc a * b * (ib * ia) = (a * ia) * (b * ib) := by grind
      _ = 1 := by rw [hia, hib]; grind⟩

theorem unitInv_eq_of_mul {a b : Fin M} (h : a * b = 1) : unitInv M a = b :=
  cancel_invertible M h ((mul_unitInv M ⟨b, h⟩).trans h.symm)

theorem isInvertible_unitInv {a : Fin M} (h : IsInvertible M a) : IsInvertible M (unitInv M a) :=
  ⟨a, by have := mul_unitInv M h; grind⟩

end Residues

section Counting
variable {M : Nat}

open Classical in
noncomputable def cardinality (S : Fin M → Prop) : Nat :=
  ((List.finRange M).filter (fun t => decide (S t))).length

open Classical in
theorem mem_cardlist {S : Fin M → Prop} {t : Fin M} :
    t ∈ (List.finRange M).filter (fun t => decide (S t)) ↔ S t := by
  rw [List.mem_filter]; simp [List.mem_finRange]

open Classical in
theorem cardinality_le_of_inj {S T : Fin M → Prop} (g : Fin M → Fin M)
    (hinj : ∀ a b, g a = g b → a = b) (hmap : ∀ t, S t → T (g t)) : cardinality S ≤ cardinality T := by
  unfold cardinality
  have hnd : ((List.finRange M).filter (fun t => decide (S t))).Nodup :=
    List.Pairwise.filter _ (List.nodup_finRange M)
  have hnd2 : (((List.finRange M).filter (fun t => decide (S t))).map g).Nodup := by
    apply List.pairwise_map.2
    apply List.Pairwise.imp_of_mem _ hnd
    intro a b _ _ hab hg
    exact hab (hinj a b hg)
  have hsub : ((List.finRange M).filter (fun t => decide (S t))).map g
      ⊆ (List.finRange M).filter (fun t => decide (T t)) := by
    intro u hu
    rw [List.mem_map] at hu
    obtain ⟨t, ht, rfl⟩ := hu
    rw [mem_cardlist] at ht ⊢
    exact hmap t ht
  have := hnd2.length_le_of_subset hsub
  simpa using this

open Classical in
theorem cardinality_eq_of_sub {S T : Fin M → Prop} (hsub : ∀ t, S t → T t) (hc : cardinality T ≤ cardinality S) :
    ∀ t, T t → S t := by
  intro t0 ht0
  apply Classical.byContradiction
  intro hn
  unfold cardinality at hc
  have hnd : ((List.finRange M).filter (fun t => decide (S t))).Nodup :=
    List.Pairwise.filter _ (List.nodup_finRange M)
  have hnd2 : (t0 :: (List.finRange M).filter (fun t => decide (S t))).Nodup := by
    rw [List.nodup_cons]
    exact ⟨fun h => hn ((mem_cardlist).1 h), hnd⟩
  have hsub2 : (t0 :: (List.finRange M).filter (fun t => decide (S t)))
      ⊆ (List.finRange M).filter (fun t => decide (T t)) := by
    intro u hu
    rcases List.mem_cons.1 hu with rfl | hu
    · exact (mem_cardlist).2 ht0
    · exact (mem_cardlist).2 (hsub u ((mem_cardlist).1 hu))
  have := hnd2.length_le_of_subset hsub2
  simp only [List.length_cons] at this
  omega

open Classical in
theorem cardinality_pos {S : Fin M → Prop} {t0 : Fin M} (h : S t0) : 1 ≤ cardinality S := by
  unfold cardinality
  exact List.length_pos_of_mem ((mem_cardlist).2 h)

end Counting

theorem exists_inv_of_coprime {M : Nat} [NeZero M] (a : Fin M) (hcop : Nat.Coprime M a.val) :
    ∃ b : Fin M, a * b = 1 := by
  have hinj : ∀ s t : Fin M, a * s = a * t → s = t := by
    intro s t h
    have h1 := congrArg Fin.val h
    rw [Fin.val_mul, Fin.val_mul] at h1
    have h2 : (s.val * a.val) % M = (t.val * a.val) % M := by
      rw [Nat.mul_comm s.val, Nat.mul_comm t.val]; exact h1
    have h3 := mod_cancel_mul_right hcop h2
    rw [Nat.mod_eq_of_lt s.isLt, Nat.mod_eq_of_lt t.isLt] at h3
    exact Fin.ext h3
  have hc : cardinality (fun _ : Fin M => True) ≤ cardinality (fun t : Fin M => ∃ s, a * s = t) :=
    cardinality_le_of_inj (fun t => a * t) hinj (fun t _ => ⟨t, rfl⟩)
  exact cardinality_eq_of_sub (S := fun t : Fin M => ∃ s, a * s = t) (T := fun _ : Fin M => True)
    (fun _ _ => trivial) hc 1 trivial

theorem exists_inv_residue {M : Nat} [NeZero M] (n : Nat) (hcop : Nat.Coprime M n) :
    ∃ b : Fin M, residue M n * b = 1 := by
  apply exists_inv_of_coprime
  rw [residue_val]
  unfold Nat.Coprime at hcop ⊢
  rw [Nat.gcd_comm, ← Nat.gcd_rec]; exact hcop

theorem twoPInv_of_coprime {p M : Nat} [NeZero M] (h : Nat.Coprime M (2 * p)) : TwoPInv p M :=
  ⟨exists_inv_residue 2 (Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_right 2 p) h),
   exists_inv_residue p (Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_left p 2) h)⟩

theorem mod_combine_le {P Q n r : Nat} (hPQ : Nat.Coprime P Q) (hle : r ≤ n)
    (hP : n % P = r % P) (hQ : n % Q = r % Q) : n % (P * Q) = r % (P * Q) := by
  have h1 : P ∣ n - r := Nat.dvd_of_mod_eq_zero (Nat.sub_mod_eq_zero_of_mod_eq hP)
  have h2 : Q ∣ n - r := Nat.dvd_of_mod_eq_zero (Nat.sub_mod_eq_zero_of_mod_eq hQ)
  obtain ⟨k, hk⟩ := Nat.Coprime.mul_dvd_of_dvd_of_dvd hPQ h1 h2
  have : n = r + (P * Q) * k := by omega
  rw [this, Nat.add_mul_mod_self_left]

theorem mod_combine {P Q n r : Nat} (hPQ : Nat.Coprime P Q)
    (hP : n % P = r % P) (hQ : n % Q = r % Q) : n % (P * Q) = r % (P * Q) := by
  rcases Nat.le_total r n with h | h
  · exact mod_combine_le hPQ h hP hQ
  · exact (mod_combine_le hPQ h hP.symm hQ.symm).symm

theorem residue_self_val {n : Nat} [NeZero n] (v : Fin n) : residue n v.val = v :=
  Fin.ext (by rw [residue_val, Nat.mod_eq_of_lt v.isLt])

theorem crt_exists {m n : Nat} [NeZero n] (h : Nat.Coprime n m) (a b : Nat) :
    ∃ y, y % m = a % m ∧ y % n = b % n := by
  obtain ⟨v, hv⟩ := exists_inv_residue (M := n) m h
  refine ⟨a + m * (v.val * (b + (n - 1) * a)), Nat.add_mul_mod_self_left a m _, ?_⟩
  have hn1 : residue n (n - 1) + 1 = 0 := by
    rw [← residue_one n, ← residue_add]
    apply Fin.ext; rw [residue_val, show n - 1 + 1 = n by have := NeZero.ne n; omega, Nat.mod_self]; rfl
  rw [← residue_eq_iff]
  rw [residue_add, residue_mul, residue_mul, residue_add, residue_mul, residue_self_val]
  grind

section Least
variable (M : Nat) [NeZero M]
theorem residue_val_self (e : Fin M) : residue M e.val = e := by
  apply Fin.ext; rw [residue_val, Nat.mod_eq_of_lt e.isLt]

theorem residue_self : residue M M = 0 := by
  rw [← residue_zero M]; apply (residue_eq_iff M _ _).2; simp

theorem exists_least (P : Nat → Prop) : (∃ n, P n) → ∃ n, P n ∧ ∀ r, r < n → ¬ P r := by
  rintro ⟨n, hn⟩
  revert hn
  induction n using Nat.strongRecOn with
  | _ n ih =>
    intro hn
    by_cases h : ∀ r, r < n → ¬ P r
    · exact ⟨n, hn, h⟩
    · obtain ⟨r, hr, hPr⟩ : ∃ r, r < n ∧ P r := by
        apply Classical.byContradiction
        intro hh
        apply h
        intro r hr hp
        exact hh ⟨r, hr, hp⟩
      exact ih r hr hPr

end Least

theorem mod_eq_of_le_sub {m X Y : Nat} (hle : Y ≤ X) (h : (X - Y) % m = 0) : X % m = Y % m := by
  obtain ⟨k, hk⟩ := Nat.dvd_of_mod_eq_zero h
  have : X = Y + m * k := by omega
  rw [this, Nat.add_mul_mod_self_left]

theorem mod_add_left_cancel {m e X Y : Nat} (h : (e + X) % m = (e + Y) % m) : X % m = Y % m := by
  rcases Nat.le_total Y X with hle | hle
  · exact mod_eq_of_le_sub hle (by
      have := Nat.sub_mod_eq_zero_of_mod_eq h
      rwa [show e + X - (e + Y) = X - Y by omega] at this)
  · exact (mod_eq_of_le_sub hle (by
      have := Nat.sub_mod_eq_zero_of_mod_eq h.symm
      rwa [show e + Y - (e + X) = Y - X by omega] at this)).symm
theorem mod_of_dvd_mod {a b P Z : Nat} (hZ : Z ∣ P) (h : a % P = b % P) : a % Z = b % Z := by
  rw [← Nat.mod_mod_of_dvd a hZ, h, Nat.mod_mod_of_dvd b hZ]

theorem cop_M_p {M p : Nat} (hM : Nat.Coprime M (2 * p)) : Nat.Coprime M p :=
  Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_left p 2) hM
theorem cop_M_two {M p : Nat} (hM : Nat.Coprime M (2 * p)) : Nat.Coprime M 2 :=
  Nat.Coprime.coprime_dvd_right (Nat.dvd_mul_right 2 p) hM

def SameMod (n a b : Nat) : Prop := a % n = b % n

inductive Closure (p Q w : Nat) : Nat → Prop
  | base (k x : Nat) : SameMod Q x (2 ^ k * w) → Closure p Q w x
  | dbl {z : Nat} : Closure p Q w z → Closure p Q w (2 * z)
  | undo {z x : Nat} : Closure p Q w z → SameMod Q (p * x + 1) (2 * z) → Closure p Q w x
  | cong {z x : Nat} : Closure p Q w z → SameMod Q x z → Closure p Q w x

section Fibres
variable (p : Nat) [Base p] (M : Nat) [NeZero M] (K w : Nat)

def Fibre (a : Nat) (t : Fin M) : Prop :=
  ∃ x, Closure p (p ^ (K + 1) * M) w x ∧ x % p ^ (K + 1) = a % p ^ (K + 1) ∧ residue M x = t

theorem fibre_mod (a : Nat) : Fibre p M K w a = Fibre p M K w (a % p ^ (K + 1)) := by
  funext t; unfold Fibre; rw [Nat.mod_mod]

theorem fibre_dbl {a : Nat} {t : Fin M} (h : Fibre p M K w a t) : Fibre p M K w (2 * a) (2 * t) := by
  obtain ⟨x, hx, hxa, rfl⟩ := h
  refine ⟨2 * x, Closure.dbl hx, ?_, ?_⟩
  · rw [Nat.mul_mod, hxa, ← Nat.mul_mod]
  · rw [residue_mul, residue_two]

theorem two_mul_inj [TwoPInv p M] (s t : Fin M) (h : (2 : Fin M) * s = 2 * t) : s = t := by
  have h2 := two_mul_unitInv M (p := p)
  exact cancel_invertible M (u := 2) (v := unitInv M 2) (by grind) h

theorem fibre_cardinality_dbl_le [TwoPInv p M] (a : Nat) : cardinality (Fibre p M K w a) ≤ cardinality (Fibre p M K w (2 * a)) :=
  cardinality_le_of_inj (fun t => 2 * t) (two_mul_inj p M) (fun _ ht => fibre_dbl p M K w ht)

theorem fibre_cardinality_pow_le [TwoPInv p M] (a : Nat) :
    ∀ m, cardinality (Fibre p M K w a) ≤ cardinality (Fibre p M K w (2 ^ m * a))
  | 0 => by simp
  | m + 1 => by
    have h := fibre_cardinality_dbl_le p M K w (2 ^ m * a)
    rw [show 2 * (2 ^ m * a) = 2 ^ (m + 1) * a by rw [Nat.pow_succ]; grind] at h
    exact Nat.le_trans (fibre_cardinality_pow_le a m) h

theorem fibre_cardinality_le_live [TwoPInv p M] {a b : Nat} (ha : InG p K a) (hb : InG p K b) :
    cardinality (Fibre p M K w a) ≤ cardinality (Fibre p M K w b) := by
  obtain ⟨j, hj⟩ := inG_ratio p ha hb
  have h := fibre_cardinality_pow_le p M K w a j
  rw [fibre_mod p M K w (2 ^ j * a), hj, ← fibre_mod] at h
  exact h

theorem fibre_cardinality_const [TwoPInv p M] {a b : Nat} (ha : InG p K a) (hb : InG p K b) :
    cardinality (Fibre p M K w a) = cardinality (Fibre p M K w b) :=
  Nat.le_antisymm (fibre_cardinality_le_live p M K w ha hb) (fibre_cardinality_le_live p M K w hb ha)

theorem fibre_dbl_iff [TwoPInv p M] {a : Nat} (ha : InG p K a) (t : Fin M) :
    Fibre p M K w (2 * a) t ↔ ∃ s, Fibre p M K w a s ∧ t = 2 * s := by
  constructor
  · intro ht
    have h2a : InG p K (2 * a) := by
      obtain ⟨m, hm⟩ := ha
      exact ⟨m + 1, by rw [Nat.pow_succ, Nat.mul_comm, Nat.mul_mod, hm, ← Nat.mul_mod]⟩
    have hc : cardinality (Fibre p M K w (2 * a)) ≤ cardinality (fun t => ∃ s, Fibre p M K w a s ∧ t = 2 * s) := by
      rw [fibre_cardinality_const p M K w h2a ha]
      exact cardinality_le_of_inj (fun s => 2 * s) (two_mul_inj p M) (fun s hs => ⟨s, hs, rfl⟩)
    exact cardinality_eq_of_sub (S := fun t => ∃ s, Fibre p M K w a s ∧ t = 2 * s)
      (fun t ⟨s, hs, hts⟩ => hts ▸ fibre_dbl p M K w hs) hc t ht
  · rintro ⟨s, hs, rfl⟩; exact fibre_dbl p M K w hs

theorem fibre_undo_iff [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) {g a' : Nat} (hg : InG p K g) (ha : InG p K a')
    (h3 : (p * a' + 1) % p ^ (K + 1) = (2 * g) % p ^ (K + 1)) (s : Fin M) :
    Fibre p M K w a' s ↔ ∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t := by
  have back : ∀ s : Fin M, (∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t) → Fibre p M K w a' s := by
    rintro s ⟨t, ⟨x, hx, hxg, rfl⟩, hst⟩
    have hcop : Nat.Coprime M (p ^ (K + 1)) := Nat.Coprime.pow_right _ (cop_M_p hM)
    obtain ⟨y, hy3, hyM⟩ := crt_exists hcop a' s.val
    refine ⟨y, Closure.undo hx ?_, hy3, ?_⟩
    · unfold SameMod
      apply mod_combine (Nat.Coprime.symm hcop)
      · rw [Nat.add_mod, Nat.mul_mod, hy3, ← Nat.mul_mod, ← Nat.add_mod, h3,
          Nat.mul_mod, ← hxg, ← Nat.mul_mod]
      · have hys : residue M y = s := by rw [← residue_self_val s, residue_eq_iff]; exact hyM
        rw [← residue_eq_iff, residue_add, residue_mul, residue_mul, residue_one, residue_two, hys, hst]
    · rw [← residue_self_val s, residue_eq_iff]; exact hyM
  constructor
  · intro hs
    have h3i := p_mul_unitInv M (p := p)
    let φ : Fin M → Fin M := fun t => unitInv M (residue M p) * (2 * t - 1)
    have hφ : ∀ t, residue M p * φ t + 1 = 2 * t := by intro t; simp only [φ]; grind
    have hinj : ∀ t t', φ t = φ t' → t = t' := by
      intro t t' h
      apply two_mul_inj p M
      have := congrArg (fun z => residue M p * z + 1) h
      simp only [hφ] at this; exact this
    have hc : cardinality (Fibre p M K w a') ≤ cardinality (fun s => ∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t) := by
      rw [fibre_cardinality_const p M K w ha hg]
      exact cardinality_le_of_inj φ hinj (fun t ht => ⟨t, ht, hφ t⟩)
    exact cardinality_eq_of_sub (S := fun s => ∃ t, Fibre p M K w g t ∧ residue M p * s + 1 = 2 * t) back hc s hs
  · exact back s

def Stabilizer (h : Fin M → Fin M) : Prop := ∀ t, Fibre p M K w 1 t ↔ Fibre p M K w 1 (h t)

theorem stabilizer_comp {h1 h2 : Fin M → Fin M} (a : Stabilizer p M K w h1) (b : Stabilizer p M K w h2) :
    Stabilizer p M K w (fun t => h2 (h1 t)) := fun t => (a t).trans (b (h1 t))

theorem stabilizer_inv {h h' : Fin M → Fin M} (a : Stabilizer p M K w h) (hh : ∀ t, h (h' t) = t) :
    Stabilizer p M K w h' := fun t => by have := a (h' t); rw [hh] at this; exact this.symm

theorem stabilizer_ext {h h' : Fin M → Fin M} (a : Stabilizer p M K w h) (hh : ∀ t, h t = h' t) :
    Stabilizer p M K w h' := fun t => by rw [← hh]; exact a t

theorem twoPow_invertible (hM : Nat.Coprime M (2 * p)) (m : Nat) : IsInvertible M (residue M (2 ^ m)) :=
  exists_inv_residue (2 ^ m) (Nat.Coprime.pow_right m (cop_M_two hM))

theorem fibre_pow [TwoPInv p M] : ∀ m (t : Fin M),
    Fibre p M K w (2 ^ m) t ↔ ∃ s, Fibre p M K w 1 s ∧ t = residue M (2 ^ m) * s
  | 0, t => by
    simp only [Nat.pow_zero, residue_one]
    exact ⟨fun h => ⟨t, h, by grind⟩, fun ⟨s, hs, hst⟩ => by rw [hst]; grind⟩
  | m + 1, t => by
    have hl : InG p K (2 ^ m) := inG_pow p K m
    rw [show 2 ^ (m + 1) = 2 * 2 ^ m by rw [Nat.pow_succ]; grind, fibre_dbl_iff p M K w hl]
    constructor
    · rintro ⟨s', hs', rfl⟩
      obtain ⟨s, hs, rfl⟩ := (fibre_pow m s').1 hs'
      exact ⟨s, hs, by rw [residue_mul, residue_two]; grind⟩
    · rintro ⟨s, hs, rfl⟩
      exact ⟨residue M (2 ^ m) * s, (fibre_pow m _).2 ⟨s, hs, rfl⟩, by rw [residue_mul, residue_two]; grind⟩

theorem fibre_live [TwoPInv p M] {a m : Nat} (ham : (2 ^ m) % p ^ (K + 1) = a % p ^ (K + 1)) (t : Fin M) :
    Fibre p M K w a t ↔ ∃ s, Fibre p M K w 1 s ∧ t = residue M (2 ^ m) * s := by
  rw [fibre_mod p M K w a, ← ham, ← fibre_mod]; exact fibre_pow p M K w m t

theorem stabilizer_loop [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) {g a' i m : Nat}
    (h3 : (p * a' + 1) % p ^ (K + 1) = (2 * g) % p ^ (K + 1))
    (hi : (2 ^ i) % p ^ (K + 1) = g % p ^ (K + 1)) (hm : (2 ^ m) % p ^ (K + 1) = a' % p ^ (K + 1)) :
    Stabilizer p M K w (fun t => unitInv M (residue M (2 ^ m)) * (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1))) := by
  have hv := p_mul_unitInv M (p := p)
  have hu := mul_unitInv M (twoPow_invertible p M hM m)
  have hP := mul_unitInv M (twoPow_invertible p M hM i)
  intro t
  constructor
  · intro ht
    have hgt : Fibre p M K w g (residue M (2 ^ i) * t) := (fibre_live p M K w hi _).2 ⟨t, ht, rfl⟩
    have has : Fibre p M K w a' (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1)) :=
      (fibre_undo_iff p M K w hM ⟨i, hi⟩ ⟨m, hm⟩ h3 _).2 ⟨_, hgt, by grind⟩
    obtain ⟨s', hs', hss⟩ := (fibre_live p M K w hm _).1 has
    show Fibre p M K w 1 (unitInv M (residue M (2 ^ m)) * (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1)))
    rw [hss]
    have : unitInv M (residue M (2 ^ m)) * (residue M (2 ^ m) * s') = s' := by grind
    rw [this]; exact hs'
  · intro ht
    have has : Fibre p M K w a' (unitInv M (residue M p) * (2 * (residue M (2 ^ i) * t) - 1)) :=
      (fibre_live p M K w hm _).2 ⟨_, ht, by grind⟩
    obtain ⟨t', ht', hst⟩ := (fibre_undo_iff p M K w hM ⟨i, hi⟩ ⟨m, hm⟩ h3 _).1 has
    have htt : t' = residue M (2 ^ i) * t := by
      apply two_mul_inj p M; rw [← hst]; grind
    rw [htt] at ht'
    obtain ⟨s, hs, hts⟩ := (fibre_live p M K w hi _).1 ht'
    have : t = s := cancel_invertible M (u := residue M (2 ^ i)) hP hts
    rw [this]; exact hs

theorem stabilizer_mul [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) {m : Nat} (hm : (2 ^ m) % p ^ (K + 1) = 1 % p ^ (K + 1)) :
    Stabilizer p M K w (fun t => residue M (2 ^ m) * t) := by
  have hP := mul_unitInv M (twoPow_invertible p M hM m)
  intro t
  constructor
  · intro ht; exact (fibre_live p M K w hm _).2 ⟨t, ht, rfl⟩
  · intro ht
    obtain ⟨s, hs, hts⟩ := (fibre_live p M K w hm _).1 ht
    rw [cancel_invertible M hP hts]; exact hs

theorem stabilizer_special_loop [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (i₀ : Nat)
    (hi₀ : (2 * 2 ^ i₀) % p ^ (K + 1) = (p + 1) % p ^ (K + 1)) :
    Stabilizer p M K w (fun t => unitInv M (residue M p) * (2 * (residue M (2 ^ i₀) * t) - 1)) := by
  have h := stabilizer_loop p M K w hM (g := 2 ^ i₀) (a' := 1) (i := i₀) (m := 0)
    (by rw [Nat.mul_one]; exact hi₀.symm) rfl (by rw [Nat.pow_zero])
  apply stabilizer_ext p M K w h
  intro t
  have h1 : unitInv M (residue M (2 ^ 0)) = 1 := unitInv_eq_of_mul M (by rw [Nat.pow_zero, residue_one]; grind)
  rw [h1]; grind

theorem stabilizer_affine_translation [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (i₀ : Nat)
    (hi₀ : (2 * 2 ^ i₀) % p ^ (K + 1) = (p + 1) % p ^ (K + 1)) {lam μ : Fin M} (hl : IsInvertible M lam)
    (hk : Stabilizer p M K w (fun t => lam * t + μ)) :
    Stabilizer p M K w
      (fun t => t + (μ + unitInv M (residue M p) - unitInv M (residue M p) * (2 * residue M (2 ^ i₀)) * μ
        - lam * unitInv M (residue M p))) := by
  have hv := p_mul_unitInv M (p := p)
  have h2 := two_mul_unitInv M (p := p)
  have hli := mul_unitInv M hl
  have hℓ := stabilizer_special_loop p M K w hM i₀ hi₀
  have hc₀i : IsInvertible M (unitInv M (residue M p) * (2 * residue M (2 ^ i₀))) :=
    isInvertible_mul M (isInvertible_unitInv M (TwoPInv.pinv (p := p)))
      (isInvertible_mul M (TwoPInv.two (p := p)) (twoPow_invertible p M hM i₀))
  have hℓv := mul_unitInv M hc₀i
  have hℓi : Stabilizer p M K w
      (fun t => unitInv M (unitInv M (residue M p) * (2 * residue M (2 ^ i₀))) * (t + unitInv M (residue M p))) :=
    stabilizer_inv p M K w hℓ (fun t => by grind)
  have hki : Stabilizer p M K w (fun t => unitInv M lam * (t - μ)) :=
    stabilizer_inv p M K w hk (fun t => by grind)
  have hc := stabilizer_comp p M K w (stabilizer_comp p M K w (stabilizer_comp p M K w hℓi hki) hℓ) hk
  exact stabilizer_ext p M K w hc (fun t => by grind)

omit [NeZero M] in
theorem exists_of_cardinality_pos {S : Fin M → Prop} (h : 1 ≤ cardinality S) : ∃ t, S t := by
  classical
  unfold cardinality at h
  obtain ⟨t, ht⟩ := List.exists_mem_of_length_pos h
  exact ⟨t, (mem_cardlist).1 ht⟩

def IsTranslationPeriod (d : Nat) : Prop := Stabilizer p M K w (fun t => t + residue M d)

theorem translationPeriod_of_eq {d : Nat} (h : residue M d = 0) : IsTranslationPeriod p M K w d :=
  stabilizer_ext p M K w (h := fun t => t) (fun _ => Iff.rfl) (fun t => by rw [h]; grind)

theorem translationPeriod_add {a b : Nat} (ha : IsTranslationPeriod p M K w a) (hb : IsTranslationPeriod p M K w b) : IsTranslationPeriod p M K w (a + b) :=
  stabilizer_ext p M K w (stabilizer_comp p M K w ha hb) (fun t => by rw [residue_add]; grind)

theorem translationPeriod_mul {a : Nat} (ha : IsTranslationPeriod p M K w a) : ∀ n, IsTranslationPeriod p M K w (a * n)
  | 0 => translationPeriod_of_eq p M K w (by rw [Nat.mul_zero]; rfl)
  | n + 1 => by rw [Nat.mul_succ]; exact translationPeriod_add p M K w (translationPeriod_mul ha n) ha

theorem translationPeriod_sub {a b : Nat} (ha : IsTranslationPeriod p M K w a) (hb : IsTranslationPeriod p M K w b) (hle : b ≤ a) :
    IsTranslationPeriod p M K w (a - b) := by
  have hbi : Stabilizer p M K w (fun t => t - residue M b) := stabilizer_inv p M K w hb (fun t => by grind)
  have hab : residue M a = residue M (a - b) + residue M b := by rw [← residue_add, Nat.sub_add_cancel hle]
  exact stabilizer_ext p M K w (stabilizer_comp p M K w ha hbi) (fun t => by rw [hab]; grind)

theorem mod_of_dvd_sub {q X Y : Nat} (hqM : q ∣ M) (h : q ∣ (residue M X - residue M Y).val) : X % q = Y % q := by
  rw [Fin.sub_def, residue_val, residue_val] at h
  have h1 : q ∣ (M - Y % M) + X % M := by
    have := (Nat.dvd_mod_iff hqM).1 h; rw [Nat.add_comm (M - Y % M)] at this ⊢; exact this
  have hlt : Y % M < M := Nat.mod_lt _ (Nat.pos_of_ne_zero (NeZero.ne M))
  have h2 : q ∣ (M - Y % M) + Y % M := by rw [Nat.sub_add_cancel (Nat.le_of_lt hlt)]; exact hqM
  have h3 := mod_add_left_cancel (m := q) (e := M - Y % M) (X := X % M) (Y := Y % M)
    (by rw [Nat.eq_zero_of_dvd_of_lt (by exact Nat.dvd_mod_iff (Nat.dvd_refl q) |>.2 h1) (Nat.mod_lt _ (Nat.pos_of_dvd_of_pos hqM (Nat.pos_of_ne_zero (NeZero.ne M)))) ,
        Nat.eq_zero_of_dvd_of_lt (by exact Nat.dvd_mod_iff (Nat.dvd_refl q) |>.2 h2) (Nat.mod_lt _ (Nat.pos_of_dvd_of_pos hqM (Nat.pos_of_ne_zero (NeZero.ne M))))])
  rwa [Nat.mod_mod_of_dvd X hqM, Nat.mod_mod_of_dvd Y hqM] at h3

omit [NeZero M] in
theorem dvd_val_mul {q : Nat} (hqM : q ∣ M) (c z : Fin M) (h : q ∣ z.val) : q ∣ (c * z).val := by
  rw [Fin.val_mul]; exact (Nat.dvd_mod_iff hqM).2 (Nat.dvd_mul_left_of_dvd h _)

theorem translationPeriod_one [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) : IsTranslationPeriod p M K w 1 := by
  obtain ⟨q, ⟨hq0, hqP⟩, hmin⟩ := exists_least (fun n => 0 < n ∧ IsTranslationPeriod p M K w n)
    ⟨M, Nat.pos_of_ne_zero (NeZero.ne M), translationPeriod_of_eq p M K w (residue_self M)⟩
  have hiff : ∀ d, IsTranslationPeriod p M K w d → q ∣ d := by
    intro d hd
    have hm := translationPeriod_sub p M K w hd (translationPeriod_mul p M K w hqP (d / q)) (Nat.mul_div_le d q)
    rw [show d - q * (d / q) = d % q by have := Nat.div_add_mod d q; omega] at hm
    apply Nat.dvd_of_mod_eq_zero
    apply Classical.byContradiction
    intro hne
    exact hmin (d % q) (Nat.mod_lt _ hq0) ⟨by omega, hm⟩
  have hqM : q ∣ M := hiff M (translationPeriod_of_eq p M K w (residue_self M))
  have hval : ∀ z : Fin M, Stabilizer p M K w (fun t => t + z) → q ∣ z.val := by
    intro z hz; apply hiff; unfold IsTranslationPeriod; rw [residue_val_self]; exact hz
  rcases Nat.lt_or_ge 1 q with hq1 | hq1
  · exfalso
    haveI : NeZero q := ⟨by omega⟩
    have hq : Nat.Coprime q p := Nat.Coprime.coprime_dvd_left hqM (cop_M_p hM)
    have hv := p_mul_unitInv M (p := p)
    obtain ⟨i₀, hi₀⟩ := undo_class p K 1
    rw [Nat.mul_one] at hi₀
    obtain ⟨T, hT0, hT⟩ := period p K
    have hA : ∀ m, 2 ^ m % p ^ (K + 1) = 1 % p ^ (K + 1) → 2 ^ m % q = 1 % q := by
      intro m hm
      have hs := stabilizer_mul p M K w hM hm
      have hs' : Stabilizer p M K w (fun t => residue M (2 ^ m) * t + 0) :=
        stabilizer_ext p M K w hs (fun t => by grind)
      have ht := hval _ (stabilizer_affine_translation p M K w hM i₀ hi₀
        (twoPow_invertible p M hM _) hs')
      have hc := dvd_val_mul M hqM (residue M p) _ ht
      have e : residue M p * ((0 : Fin M) + unitInv M (residue M p)
          - unitInv M (residue M p) * (2 * residue M (2 ^ i₀)) * 0
          - residue M (2 ^ m) * unitInv M (residue M p))
          = residue M 1 - residue M (2 ^ m) := hA_id M p _ _ _ hv
      rw [e] at hc
      exact (mod_of_dvd_sub M (X := 1) (Y := 2 ^ m) hqM hc).symm
    have hB : ∀ i m, (p * 2 ^ m + 1) % p ^ (K + 1) = (2 * 2 ^ i) % p ^ (K + 1) →
        (p * 2 ^ m + 2 * 2 ^ i₀) % q = (p + 2 * 2 ^ i) % q := by
      intro i m h3
      have hu := mul_unitInv M (twoPow_invertible p M hM m)
      have hs := stabilizer_loop p M K w hM (g := 2 ^ i) (a' := 2 ^ m) (i := i) (m := m) h3 rfl rfl
      let u := unitInv M (residue M (2 ^ m))
      let lam := u * unitInv M (residue M p) * 2 * residue M (2 ^ i)
      let μ := - (u * unitInv M (residue M p))
      have hs' : Stabilizer p M K w (fun t => lam * t + μ) :=
        stabilizer_ext p M K w hs (fun t => by simp only [lam, μ, u]; grind)
      have hl : IsInvertible M lam := by
        refine isInvertible_mul M (isInvertible_mul M (isInvertible_mul M
          (isInvertible_unitInv M (twoPow_invertible p M hM m)) ?_) ?_) (twoPow_invertible p M hM i)
        · exact isInvertible_unitInv M (TwoPInv.pinv (p := p))
        · exact TwoPInv.two (p := p)
      have ht := hval _ (stabilizer_affine_translation p M K w hM i₀ hi₀ hl hs')
      have hc1 := dvd_val_mul M hqM (residue M (p * 2 ^ m)) _ ht
      have hc2 := dvd_val_mul M hqM (residue M p) _ hc1
      apply mod_of_dvd_sub M hqM
      have e : residue M p * (residue M (p * 2 ^ m) * (μ + unitInv M (residue M p)
          - unitInv M (residue M p) * (2 * residue M (2 ^ i₀)) * μ - lam * unitInv M (residue M p)))
          = residue M (p * 2 ^ m + 2 * 2 ^ i₀) - residue M (p + 2 * 2 ^ i) :=
        hB_id M p m i i₀ u (unitInv M (residue M p)) hu hv
      rw [← e]; exact hc2
    apply Gen.period_general p K q i₀ T Base.odd hq1 hq hT0
    · exact_mod_cast Gen.cong_of_mod hT
    · intro m hm
      have hm' : 2 ^ m % p ^ (K + 1) = 1 % p ^ (K + 1) := Gen.mod_of_cong (by exact_mod_cast hm)
      exact_mod_cast Gen.cong_of_mod (hA m hm')
    · exact_mod_cast Gen.cong_of_mod hi₀
    · intro m
      obtain ⟨i, hi⟩ := undo_class p K (2 ^ m)
      exact ⟨i, by exact_mod_cast Gen.cong_of_mod hi⟩
    · intro i m him
      have h3 : (2 * 2 ^ i) % p ^ (K + 1) = (p * 2 ^ m + 1) % p ^ (K + 1) :=
        Gen.mod_of_cong (by exact_mod_cast him)
      exact_mod_cast Gen.cong_of_mod (hB i m h3.symm)
  · have : q = 1 := by omega
    subst this
    exact translationPeriod_mul p M K w hqP 1 |> fun h => by simpa using h

theorem fibre_one_full [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) (t : Fin M) : Fibre p M K w 1 t := by
  obtain ⟨iw, hiw⟩ := hw
  have hw0 : Fibre p M K w w (residue M w) :=
    ⟨w, Closure.base 0 w (by unfold SameMod; rw [Nat.pow_zero, Nat.one_mul]), rfl, rfl⟩
  have hc : 1 ≤ cardinality (Fibre p M K w 1) :=
    Nat.le_trans (cardinality_pos hw0)
      (fibre_cardinality_le_live p M K w (w_inG p hiw K) ⟨0, by rw [Nat.pow_zero]⟩)
  obtain ⟨t0, ht0⟩ := exists_of_cardinality_pos M hc
  have hp : IsTranslationPeriod p M K w (t - t0).val := by
    have := translationPeriod_mul p M K w (translationPeriod_one p M K w hM) (t - t0).val; rwa [Nat.one_mul] at this
  have := (hp t0).1 ht0
  change Fibre p M K w 1 (t0 + residue M (t - t0).val) at this
  rw [residue_val_self] at this
  have e : t0 + (t - t0) = t := by grind
  rw [e] at this; exact this

theorem fibre_full_live [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) {a : Nat} (ha : InG p K a)
    (t : Fin M) : Fibre p M K w a t := by
  obtain ⟨m, hm⟩ := ha
  have hu := mul_unitInv M (twoPow_invertible p M hM m)
  exact (fibre_live p M K w (m := m) hm t).2
    ⟨unitInv M (residue M (2 ^ m)) * t, fibre_one_full p M K w hM hw _, by grind⟩

theorem fibre_full [TwoPInv p M] (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) (a : Nat) (t : Fin M) :
    Fibre p M K w a t := by
  obtain ⟨i, hi⟩ := undo_class p K a
  have h2i := two_mul_unitInv M (p := p)
  obtain ⟨y, hy, hyg, hyt⟩ := fibre_full_live p M K w hM hw (inG_pow p K i) (unitInv M 2 * (residue M p * t + 1))
  have hcop : Nat.Coprime M (p ^ (K + 1)) := Nat.Coprime.pow_right _ (cop_M_p hM)
  obtain ⟨x, hx3, hxM⟩ := crt_exists hcop a t.val
  have hxt : residue M x = t := by rw [← residue_self_val t, residue_eq_iff]; exact hxM
  refine ⟨x, Closure.undo hy ?_, hx3, hxt⟩
  unfold SameMod
  apply mod_combine (Nat.Coprime.symm hcop)
  · rw [Nat.add_mod, Nat.mul_mod, hx3, ← Nat.mul_mod, ← Nat.add_mod, ← hi,
      Nat.mul_mod, ← hyg, ← Nat.mul_mod]
  · rw [← residue_eq_iff, residue_add, residue_mul, residue_mul, residue_one, residue_two, hxt, hyt]; grind

theorem closure_all (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p) (x : Nat) : Closure p (p ^ (K + 1) * M) w x := by
  haveI : TwoPInv p M := twoPInv_of_coprime hM
  obtain ⟨x', hx', h1, h2⟩ := fibre_full p M K w hM hw x (residue M x)
  apply Closure.cong hx'
  unfold SameMod
  have hcop : Nat.Coprime (p ^ (K + 1)) M := Nat.Coprime.symm (Nat.Coprime.pow_right _ (cop_M_p hM))
  exact mod_combine hcop h1.symm ((residue_eq_iff M x x').1 h2.symm)

end Fibres

end PX

namespace PX

def PrimeLike (p : Nat) : Prop := ∀ N, N % p ≠ 0 → Nat.Coprime p N

section Words
variable (p : Nat)

def oneCount : List Nat → Nat
  | [] => 0
  | e :: u => oneCount u + e

def offset : List Nat → Nat
  | [] => 0
  | e :: u => p ^ oneCount u * e + 2 * offset u

theorem collatz_odd [Base p] (y : Nat) :
    collatz p (2 * y + 1) = 2 * (p * y + (p + 1) / 2) := by
  have := Base.odd (p := p)
  unfold collatz
  rw [ite_eq_right (by omega)]
  have h : p + 1 = 2 * ((p + 1) / 2) := by omega
  generalize (p + 1) / 2 = c at h ⊢
  grind

theorem integrality [Base p] : ∀ (u : List Nat), (∀ e ∈ u, e ≤ 1) → ∀ x : Nat,
    2 ^ u.length ∣ p ^ oneCount u * x + offset p u →
    ∃ k, iter (collatz p) k x = (p ^ oneCount u * x + offset p u) / 2 ^ u.length
  | [], _, x, _ => ⟨0, by simp [oneCount, offset, iter]⟩
  | e :: u, hu, x, h => by
    have he : e = 0 ∨ e = 1 := by have := hu e (by simp); omega
    have hu' : ∀ d ∈ u, d ≤ 1 := fun d hd => hu d (by simp [hd])
    have hp : p ^ oneCount u % 2 = 1 := powp_odd p _
    have hc : p + 1 = 2 * ((p + 1) / 2) := by have := Base.odd (p := p); omega
    have h2 : 2 ∣ 2 ^ (u.length + 1) := ⟨2 ^ u.length, by grind⟩
    have hpow : 2 ^ (u.length + 1) = 2 * 2 ^ u.length := by grind
    simp only [List.length_cons, oneCount, offset] at h ⊢
    rcases he with rfl | rfl
    · have h0 := Nat.dvd_trans h2 h
      obtain ⟨y, hy | hy⟩ : ∃ y, x = 2 * y ∨ x = 2 * y + 1 := ⟨x / 2, by omega⟩
      · subst hy
        have hn : p ^ (oneCount u + 0) * (2 * y) + (p ^ oneCount u * 0 + 2 * offset p u)
            = 2 * (p ^ oneCount u * y + offset p u) := by grind
        rw [hn, hpow] at h
        have h' := (Nat.mul_dvd_mul_iff_left (by omega : 0 < 2)).1 h
        obtain ⟨k, hk⟩ := integrality u hu' y h'
        refine ⟨k + 1, ?_⟩
        show iter (collatz p) k (collatz p (2 * y)) = _
        rw [collatz_double, hk, hn, hpow, Nat.mul_div_mul_left _ _ (by omega : 0 < 2)]
      · subst hy
        exfalso
        have hn : p ^ (oneCount u + 0) * (2 * y + 1) + (p ^ oneCount u * 0 + 2 * offset p u)
            = 2 * (p ^ oneCount u * y + offset p u) + p ^ oneCount u := by grind
        rw [hn] at h0
        generalize p ^ oneCount u * y + offset p u = P at h0
        omega
    · have h0 := Nat.dvd_trans h2 h
      obtain ⟨y, hy | hy⟩ : ∃ y, x = 2 * y ∨ x = 2 * y + 1 := ⟨x / 2, by omega⟩
      · subst hy
        exfalso
        have hn : p ^ (oneCount u + 1) * (2 * y) + (p ^ oneCount u * 1 + 2 * offset p u)
            = 2 * (p ^ oneCount u * (p * y) + offset p u) + p ^ oneCount u := by grind
        rw [hn] at h0
        generalize p ^ oneCount u * (p * y) + offset p u = P at h0
        omega
      · subst hy
        have hn : p ^ (oneCount u + 1) * (2 * y + 1) + (p ^ oneCount u * 1 + 2 * offset p u)
            = 2 * (p ^ oneCount u * (p * y + (p + 1) / 2) + offset p u) := by
          rw [Nat.pow_succ]
          generalize (p + 1) / 2 = c at hc ⊢
          grind
        rw [hn, hpow] at h
        have h' := (Nat.mul_dvd_mul_iff_left (by omega : 0 < 2)).1 h
        obtain ⟨k, hk⟩ := integrality u hu' (p * y + (p + 1) / 2) h'
        refine ⟨k + 2, ?_⟩
        show iter (collatz p) k (collatz p (collatz p (2 * y + 1))) = _
        rw [collatz_odd, collatz_double, hk, hn, hpow, Nat.mul_div_mul_left _ _ (by omega : 0 < 2)]

theorem integrality_reaches [Base p] (u : List Nat) (hu : ∀ e ∈ u, e ≤ 1) (x : Nat)
    (h : 2 ^ u.length ∣ p ^ oneCount u * x + offset p u) :
    Reaches p ((p ^ oneCount u * x + offset p u) / 2 ^ u.length) x := integrality p u hu x h

theorem oneCount_le : ∀ u : List Nat, (∀ e ∈ u, e ≤ 1) → oneCount u ≤ u.length
  | [], _ => by simp [oneCount]
  | e :: u, hu => by
    have h1 := oneCount_le u (fun d hd => hu d (by simp [hd]))
    have h2 := hu e (by simp)
    simp only [oneCount, List.length_cons]; omega

theorem offset_le [Base p] : ∀ u : List Nat, (∀ e ∈ u, e ≤ 1) → offset p u ≤ (2 * p) ^ u.length
  | [], _ => by simp [offset]
  | e :: u, hu => by
    have hu' : ∀ d ∈ u, d ≤ 1 := fun d hd => hu d (by simp [hd])
    have ih := offset_le u hu'
    have hj := oneCount_le u hu'
    have h3 : p ^ oneCount u ≤ p ^ u.length :=
      Nat.pow_le_pow_right (by have := Base.three_le (p := p); omega) hj
    have h36 : p ^ u.length ≤ (2 * p) ^ u.length := Nat.pow_le_pow_left (by omega) _
    have he := hu e (by simp)
    have h6 : (2 * p) ^ (u.length + 1) = (2 * p) ^ u.length * (2 * p) := Nat.pow_succ ..
    have h8 := Nat.mul_le_mul_left ((2 * p) ^ u.length)
      (show 3 ≤ 2 * p by have := Base.three_le (p := p); omega)
    have h7 : p ^ oneCount u * e ≤ p ^ oneCount u := by
      rcases (by omega : e = 0 ∨ e = 1) with rfl | rfl <;> simp
    simp only [offset, List.length_cons]
    rw [h6]
    omega

theorem parity_word [Base p] : ∀ (a r : Nat), ∃ q : List Nat, q.length = a ∧ (∀ e ∈ q, e ≤ 1) ∧
    2 ^ a ∣ p ^ oneCount q * r + offset p q
  | 0, r => ⟨[], rfl, by simp, by simp [oneCount, offset]⟩
  | a + 1, r => by
    obtain ⟨y, hy | hy⟩ : ∃ y, r = 2 * y ∨ r = 2 * y + 1 := ⟨r / 2, by omega⟩
    · obtain ⟨q, hl, hq, hd⟩ := parity_word a y
      refine ⟨0 :: q, by simp [hl], ?_, ?_⟩
      · intro e he
        rcases List.mem_cons.1 he with rfl | he
        · omega
        · exact hq e he
      · have h2 := Nat.mul_dvd_mul_left 2 hd
        rw [hy]
        have e1 : p ^ oneCount (0 :: q) * (2 * y) + offset p (0 :: q) = 2 * (p ^ oneCount q * y + offset p q) := by
          simp only [oneCount, offset, Nat.add_zero, Nat.mul_zero]; grind
        rw [e1, show 2 ^ (a + 1) = 2 * 2 ^ a by rw [Nat.pow_succ]; grind]
        exact h2
    · have hc : p + 1 = 2 * ((p + 1) / 2) := by have := Base.odd (p := p); omega
      obtain ⟨q, hl, hq, hd⟩ := parity_word a (p * y + (p + 1) / 2)
      refine ⟨1 :: q, by simp [hl], ?_, ?_⟩
      · intro e he
        rcases List.mem_cons.1 he with rfl | he
        · omega
        · exact hq e he
      · have h2 := Nat.mul_dvd_mul_left 2 hd
        rw [hy]
        have e1 : p ^ oneCount (1 :: q) * (2 * y + 1) + offset p (1 :: q)
            = 2 * (p ^ oneCount q * (p * y + (p + 1) / 2) + offset p q) := by
          simp only [oneCount, offset]
          rw [Nat.pow_succ]
          generalize (p + 1) / 2 = c at hc ⊢
          grind
        rw [e1, show 2 ^ (a + 1) = 2 * 2 ^ a by rw [Nat.pow_succ]; grind]
        exact h2

theorem reaches_pow2 [Base p] (w : Nat) : ∀ n, Reaches p w (2 ^ n * w)
  | 0 => ⟨0, by simp [iter]⟩
  | n + 1 => by
    obtain ⟨k, hk⟩ := reaches_pow2 w n
    refine ⟨k + 1, ?_⟩
    rw [iter_add]
    show iter (collatz p) k (collatz p (2 ^ (n + 1) * w)) = w
    rw [show 2 ^ (n + 1) * w = 2 * (2 ^ n * w) by rw [Nat.pow_succ]; grind, collatz_double]; exact hk

end Words

theorem mod_lin {Q a b : Nat} (c d : Nat) (h : a % Q = b % Q) : (c * a + d) % Q = (c * b + d) % Q := by
  rw [Nat.add_mod, Nat.mul_mod, h, ← Nat.mul_mod, ← Nat.add_mod]

theorem closure_word (p Q w : Nat) {x : Nat} (h : Closure p Q w x) :
    ∃ (u : List Nat) (k : Nat), (∀ e ∈ u, e ≤ 1) ∧
      (p ^ oneCount u * x + offset p u) % Q = (2 ^ (u.length + k) * w) % Q := by
  induction h with
  | base k x hx => exact ⟨[], k, by simp, by unfold SameMod at hx; simpa [oneCount, offset] using hx⟩
  | @dbl z hz ih =>
    obtain ⟨u, k, hu, h⟩ := ih
    refine ⟨0 :: u, k, ?_, ?_⟩
    · intro e he
      rcases List.mem_cons.1 he with rfl | he
      · omega
      · exact hu e he
    · have hh := mod_lin 2 0 h
      have e1 : p ^ oneCount (0 :: u) * (2 * z) + offset p (0 :: u) = 2 * (p ^ oneCount u * z + offset p u) + 0 := by
        simp only [oneCount, offset, Nat.add_zero, Nat.mul_zero]; grind
      have e2 : 2 ^ ((0 :: u).length + k) * w = 2 * (2 ^ (u.length + k) * w) + 0 := by
        rw [List.length_cons, show u.length + 1 + k = (u.length + k) + 1 by omega, Nat.pow_succ]; grind
      rw [e1, e2]; exact hh
  | @undo z x hz hx ih =>
    obtain ⟨u, k, hu, h⟩ := ih
    refine ⟨1 :: u, k, ?_, ?_⟩
    · intro e he
      rcases List.mem_cons.1 he with rfl | he
      · omega
      · exact hu e he
    · have hh := mod_lin 2 0 h
      have hx' := mod_lin (p ^ oneCount u) (2 * offset p u) (show (p * x + 1) % Q = (2 * z) % Q from hx)
      have e1 : p ^ oneCount (1 :: u) * x + offset p (1 :: u) = p ^ oneCount u * (p * x + 1) + 2 * offset p u := by
        simp only [oneCount, offset]; grind
      have e3 : p ^ oneCount u * (2 * z) + 2 * offset p u = 2 * (p ^ oneCount u * z + offset p u) + 0 := by grind
      have e2 : 2 ^ ((1 :: u).length + k) * w = 2 * (2 ^ (u.length + k) * w) + 0 := by
        rw [List.length_cons, show u.length + 1 + k = (u.length + k) + 1 by omega, Nat.pow_succ]; grind
      rw [e1, e2]
      exact hx'.trans (by rw [e3]; exact hh)
  | @cong z x hz hx ih =>
    obtain ⟨u, k, hu, h⟩ := ih
    exact ⟨u, k, hu, (mod_lin (p ^ oneCount u) (offset p u) (show x % Q = z % Q from hx)).trans h⟩

section Short
variable (p Q w : Nat)

def HasWord (n x : Nat) : Prop :=
  ∃ (u : List Nat) (k : Nat), (∀ e ∈ u, e ≤ 1) ∧ u.length ≤ n ∧
    (p ^ oneCount u * x + offset p u) % Q = (2 ^ (u.length + k) * w) % Q

theorem hasWord_mono {n x : Nat} (h : HasWord p Q w n x) : HasWord p Q w (n + 1) x := by
  obtain ⟨u, k, hu, hl, he⟩ := h
  exact ⟨u, k, hu, by omega, he⟩

theorem hasWord_le {a b x : Nat} (h : a ≤ b) (hx : HasWord p Q w a x) : HasWord p Q w b x := by
  obtain ⟨d, rfl⟩ : ∃ d, b = a + d := ⟨b - a, by omega⟩
  induction d with
  | zero => exact hx
  | succ d ih => exact hasWord_mono p Q w (ih (by omega))

theorem hasWord_mod {n x : Nat} : HasWord p Q w n x ↔ HasWord p Q w n (x % Q) := by
  constructor
  · rintro ⟨u, k, hu, hl, he⟩
    exact ⟨u, k, hu, hl, (mod_lin (p ^ oneCount u) (offset p u) (Nat.mod_mod x Q)).trans he⟩
  · rintro ⟨u, k, hu, hl, he⟩
    exact ⟨u, k, hu, hl, (mod_lin (p ^ oneCount u) (offset p u) (Nat.mod_mod x Q).symm).trans he⟩

theorem hasWord_base {x k : Nat} (h : x % Q = (2 ^ k * w) % Q) : HasWord p Q w 0 x :=
  ⟨[], k, by simp, by simp, by simpa [oneCount, offset] using h⟩

theorem hasWord_step {n x y ε : Nat} (hε : ε ≤ 1) (hy : HasWord p Q w n y)
    (h : (2 * y) % Q = (p ^ ε * x + ε) % Q) : HasWord p Q w (n + 1) x := by
  obtain ⟨u, k, hu, hl, he⟩ := hy
  refine ⟨ε :: u, k, ?_, by simp; omega, ?_⟩
  · intro e he'
    rcases List.mem_cons.1 he' with rfl | he'
    · exact hε
    · exact hu e he'
  · have hx' := mod_lin (p ^ oneCount u) (2 * offset p u) (show (p ^ ε * x + ε) % Q = (2 * y) % Q from h.symm)
    have hh := mod_lin 2 0 he
    have e1 : p ^ oneCount (ε :: u) * x + offset p (ε :: u) = p ^ oneCount u * (p ^ ε * x + ε) + 2 * offset p u := by
      simp only [oneCount, offset, Nat.pow_add]; grind
    have e3 : p ^ oneCount u * (2 * y) + 2 * offset p u = 2 * (p ^ oneCount u * y + offset p u) + 0 := by grind
    have e2 : 2 ^ ((ε :: u).length + k) * w = 2 * (2 ^ (u.length + k) * w) + 0 := by
      rw [List.length_cons, show u.length + 1 + k = (u.length + k) + 1 by omega, Nat.pow_succ]; grind
    rw [e1, e2]
    exact hx'.trans (by rw [e3]; exact hh)

theorem hasWord_inv (hQ2 : Q % 2 = 1) {n x : Nat} (h : HasWord p Q w (n + 1) x) :
    HasWord p Q w 0 x ∨ ∃ ε, ε ≤ 1 ∧ ∃ y, HasWord p Q w n y ∧ (2 * y) % Q = (p ^ ε * x + ε) % Q := by
  have hcop : Nat.Coprime Q 2 := by
    unfold Nat.Coprime; rw [Nat.gcd_comm, Nat.gcd_rec, hQ2]; simp
  obtain ⟨u, k, hu, hl, he⟩ := h
  cases u with
  | nil => left; exact hasWord_base p Q w (k := k) (by simpa [oneCount, offset] using he)
  | cons ε u' =>
    right
    refine ⟨ε, hu ε (by simp), ((Q + 1) / 2) * (p ^ ε * x + ε), ?_, ?_⟩
    · have h2y : (2 * (((Q + 1) / 2) * (p ^ ε * x + ε))) % Q = (p ^ ε * x + ε) % Q := by
        have : 2 * (((Q + 1) / 2) * (p ^ ε * x + ε)) = (p ^ ε * x + ε) + Q * (p ^ ε * x + ε) := by
          have h2 : 2 * ((Q + 1) / 2) = Q + 1 := by omega
          rw [← Nat.mul_assoc, h2]; grind
        rw [this, Nat.add_mul_mod_self_left]
      refine ⟨u', k, fun e he' => hu e (by simp [he']), by simp at hl; omega, ?_⟩
      have e1 : p ^ oneCount (ε :: u') * x + offset p (ε :: u') = p ^ oneCount u' * (p ^ ε * x + ε) + 2 * offset p u' := by
        simp only [oneCount, offset, Nat.pow_add]; grind
      have e2 : 2 ^ ((ε :: u').length + k) * w = 2 * (2 ^ (u'.length + k) * w) := by
        rw [List.length_cons, show u'.length + 1 + k = (u'.length + k) + 1 by omega, Nat.pow_succ]; grind
      rw [e1, e2] at he
      have hz := mod_lin (p ^ oneCount u') (2 * offset p u')
        (show (p ^ ε * x + ε) % Q = (2 * (((Q + 1) / 2) * (p ^ ε * x + ε))) % Q from h2y.symm)
      have hA : ((p ^ oneCount u' * (((Q + 1) / 2) * (p ^ ε * x + ε)) + offset p u') * 2) % Q
          = ((2 ^ (u'.length + k) * w) * 2) % Q := by
        have e3 : (p ^ oneCount u' * (((Q + 1) / 2) * (p ^ ε * x + ε)) + offset p u') * 2
            = p ^ oneCount u' * (2 * (((Q + 1) / 2) * (p ^ ε * x + ε))) + 2 * offset p u' := by grind
        have e4 : (2 ^ (u'.length + k) * w) * 2 = 2 * (2 ^ (u'.length + k) * w) := by grind
        rw [e3, e4]; exact hz.symm.trans he
      exact mod_cancel_mul_right hcop hA
    · have h2 : 2 * (((Q + 1) / 2) * (p ^ ε * x + ε)) = (p ^ ε * x + ε) + Q * (p ^ ε * x + ε) := by
        have h2' : 2 * ((Q + 1) / 2) = Q + 1 := by omega
        rw [← Nat.mul_assoc, h2']; grind
      rw [h2, Nat.add_mul_mod_self_left]

theorem cardinality_le_modulus {Q : Nat} (S : Fin Q → Prop) : cardinality S ≤ Q := by
  classical
  unfold cardinality
  calc ((List.finRange Q).filter (fun t => decide (S t))).length ≤ (List.finRange Q).length :=
        List.length_filter_le _ _
    _ = Q := List.length_finRange

theorem hasWord_stable [NeZero Q] :
    ∃ n, n ≤ Q ∧ ∀ t : Fin Q, HasWord p Q w (n + 1) t.val → HasWord p Q w n t.val := by
  apply Classical.byContradiction
  intro hno
  have hno' : ∀ n, n ≤ Q → ∃ t : Fin Q, HasWord p Q w (n + 1) t.val ∧ ¬ HasWord p Q w n t.val := by
    intro n hn
    apply Classical.byContradiction
    intro hc
    exact hno ⟨n, hn, fun t ht => Classical.byContradiction fun h => hc ⟨t, ht, h⟩⟩
  have hc : ∀ n, n ≤ Q + 1 → n + 1 ≤ cardinality (fun t : Fin Q => HasWord p Q w n t.val) := by
    intro n
    induction n with
    | zero =>
      intro _
      exact cardinality_pos (t0 := ⟨w % Q, Nat.mod_lt _ (Nat.pos_of_ne_zero (NeZero.ne Q))⟩)
        (hasWord_base p Q w (k := 0) (by simp))
    | succ n ih =>
      intro hn
      obtain ⟨t, h1, h2⟩ := hno' n (by omega)
      have hlt : cardinality (fun t : Fin Q => HasWord p Q w n t.val) < cardinality (fun t : Fin Q => HasWord p Q w (n + 1) t.val) := by
        apply Classical.byContradiction
        intro hge
        exact h2 (cardinality_eq_of_sub (S := fun t : Fin Q => HasWord p Q w n t.val)
          (T := fun t : Fin Q => HasWord p Q w (n + 1) t.val) (fun t h => hasWord_mono p Q w h)
          (Nat.le_of_not_lt hge) t h1)
      have := ih (by omega)
      omega
  have h1 := hc (Q + 1) (Nat.le_refl _)
  have h2 := cardinality_le_modulus (Q := Q) (fun t : Fin Q => HasWord p Q w (Q + 1) t.val)
  omega

theorem hasWord_all_short [NeZero Q] (hQ2 : Q % 2 = 1) (hall : ∀ x, ∃ n, HasWord p Q w n x) :
    ∀ x, HasWord p Q w Q x := by
  obtain ⟨n, hnQ, hst⟩ := hasWord_stable p Q w
  have hQpos : 0 < Q := Nat.pos_of_ne_zero (NeZero.ne Q)
  have hst' : ∀ x, HasWord p Q w (n + 1) x → HasWord p Q w n x := by
    intro x hx
    have := hst ⟨x % Q, Nat.mod_lt _ hQpos⟩ ((hasWord_mod p Q w).1 hx)
    exact (hasWord_mod p Q w).2 this
  have hstab : ∀ d x, HasWord p Q w (n + d) x → HasWord p Q w n x := by
    intro d
    induction d with
    | zero => exact fun x h => h
    | succ d ih =>
      intro x hx
      rcases hasWord_inv p Q w hQ2 (show HasWord p Q w (n + d + 1) x from hx) with h0 | ⟨ε, hε, y, hy, h⟩
      · exact hasWord_le p Q w (Nat.zero_le n) h0
      · exact hst' x (hasWord_step p Q w hε (ih y hy) h)
  intro x
  obtain ⟨m, hm⟩ := hall x
  by_cases hnm : n ≤ m
  · obtain ⟨d, rfl⟩ : ∃ d, m = n + d := ⟨m - n, by omega⟩
    exact hasWord_le p Q w hnQ (hstab d x hm)
  · exact hasWord_le p Q w (by omega) hm

end Short

theorem closure_word_short (p : Nat) [Base p] (M K w : Nat) [NeZero M] (hM : Nat.Coprime M (2 * p))
    (hw : ∃ i, w % p = 2 ^ i % p) (x : Nat) :
    ∃ (u : List Nat) (k : Nat), (∀ e ∈ u, e ≤ 1) ∧ u.length ≤ p ^ (K + 1) * M ∧
      (p ^ oneCount u * x + offset p u) % (p ^ (K + 1) * M) = (2 ^ (u.length + k) * w) % (p ^ (K + 1) * M) := by
  haveI : NeZero (p ^ (K + 1) * M) :=
    ⟨Nat.ne_of_gt (Nat.mul_pos (powp_pos p _) (Nat.pos_of_ne_zero (NeZero.ne M)))⟩
  have hM2 : M % 2 = 1 := by
    apply Classical.byContradiction
    intro h
    have h2 : 2 ∣ M := Nat.dvd_of_mod_eq_zero (by omega)
    have := Nat.Coprime.eq_one_of_dvd (Nat.Coprime.symm (cop_M_two hM)) h2
    omega
  have hQ2 : (p ^ (K + 1) * M) % 2 = 1 := by
    rw [Nat.mul_mod, powp_odd p, hM2]
  have hall : ∀ x, ∃ n, HasWord p (p ^ (K + 1) * M) w n x := by
    intro x
    obtain ⟨u, k, hu, h⟩ := closure_word p _ w (closure_all p M K w hM hw x)
    exact ⟨u.length, u, k, hu, Nat.le_refl _, h⟩
  exact hasWord_all_short p _ w hQ2 hall x

theorem exists_pow2_period (M : Nat) (hM : 0 < M) (hc : Nat.Coprime M 2) :
    ∃ D, 0 < D ∧ D ≤ M ∧ 2 ^ D % M = 1 % M := by
  apply Classical.byContradiction
  intro hno
  have hinj : ∀ a b, a < b → b ≤ M → 2 ^ a % M ≠ 2 ^ b % M := by
    intro a b hab hb heq
    apply hno
    refine ⟨b - a, by omega, by omega, ?_⟩
    have hcop : Nat.Coprime M (2 ^ a) := Nat.Coprime.pow_right _ hc
    exact mod_cancel_mul_right (x := 2 ^ (b - a)) (y := 1) hcop
      (by rw [← Nat.pow_add, Nat.sub_add_cancel (by omega), Nat.one_mul]; exact heq.symm)
  have hnd : ((List.range (M + 1)).map (fun i => 2 ^ i % M)).Nodup := by
    apply List.pairwise_map.2
    apply List.Pairwise.imp_of_mem _ List.nodup_range
    intro a b ha hb hab
    rw [List.mem_range] at ha hb
    rcases Nat.lt_or_gt_of_ne hab with h | h
    · exact hinj a b h (by omega)
    · exact fun h' => hinj b a h (by omega) h'.symm
  have hsub : ((List.range (M + 1)).map (fun i => 2 ^ i % M)) ⊆ List.range M := by
    intro v hv
    rw [List.mem_map] at hv
    obtain ⟨i, _, rfl⟩ := hv
    rw [List.mem_range]; exact Nat.mod_lt _ hM
  have := hnd.length_le_of_subset hsub
  simp at this
  omega

theorem split_p (p : Nat) [Base p] (D : Nat) (hD : 0 < D) : ∃ ν d, D = p ^ ν * d ∧ d % p ≠ 0 := by
  have hp3 := Base.three_le (p := p)
  induction D using Nat.strongRecOn with
  | _ D ih =>
    by_cases h : D % p = 0
    · have hDp : p * (D / p) = D := Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero h)
      have hpos : 0 < D / p := Nat.pos_of_ne_zero fun h0 => by rw [h0] at hDp; omega
      obtain ⟨ν, d, hd, h3⟩ := ih (D / p) (Nat.div_lt_self hD (by omega)) hpos
      refine ⟨ν + 1, d, ?_, h3⟩
      rw [← hDp, hd, Nat.pow_succ]; grind
    · exact ⟨0, D, by simp, h⟩

theorem coprime2p_of_not_dvd (p : Nat) [Base p] (hpr : PrimeLike p) (N : Nat)
    (h2 : N % 2 ≠ 0) (hp : N % p ≠ 0) : Nat.Coprime N (2 * p) := by
  apply Nat.Coprime.mul_right _ (hpr N hp).symm
  unfold Nat.Coprime; rw [Nat.gcd_comm, Nat.gcd_rec, show N % 2 = 1 by omega]; rfl

theorem split_two_p (p : Nat) [Base p] (hpr : PrimeLike p) (N : Nat) (hN : 1 ≤ N) :
    ∃ a b M, N = 2 ^ a * p ^ b * M ∧ Nat.Coprime M (2 * p) := by
  have hp3 := Base.three_le (p := p)
  induction N using Nat.strongRecOn with
  | _ N ih =>
    by_cases h2 : N % 2 = 0
    · obtain ⟨a, b, M, hM, hc⟩ := ih (N / 2) (by omega) (by omega)
      refine ⟨a + 1, b, M, ?_, hc⟩
      have : N = 2 * (N / 2) := by omega
      rw [this, hM, Nat.pow_succ]; grind
    · by_cases h5 : N % p = 0
      · have hNp : p * (N / p) = N := Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero h5)
        have hpos : 1 ≤ N / p := Nat.pos_of_ne_zero fun h0 => by rw [h0] at hNp; omega
        obtain ⟨a, b, M, hM, hc⟩ := ih (N / p) (Nat.div_lt_self (by omega) (by omega)) hpos
        refine ⟨a, b + 1, M, ?_, hc⟩
        rw [← hNp, hM, Nat.pow_succ p b]; grind
      · exact ⟨0, 0, N, by simp, coprime2p_of_not_dvd p hpr N h2 h5⟩

section Lift
variable (p : Nat) [Base p]

theorem mod_mul_right_cong {Q a b : Nat} (c : Nat) (h : a % Q = b % Q) :
    (a * c) % Q = (b * c) % Q := by
  rw [Nat.mul_mod, h, ← Nat.mul_mod]

end Lift

theorem cop_w (p : Nat) [Base p] {w : Nat} (hw : ∃ i, w % p = 2 ^ i % p) : Nat.Coprime p w := by
  obtain ⟨i, hi⟩ := hw
  have h : Nat.Coprime p (2 ^ i) := Nat.Coprime.pow_right i (coprime_p_two p)
  unfold Nat.Coprime at h ⊢
  rw [Nat.gcd_rec, hi, ← Nat.gcd_rec]; exact h

theorem exp_lift_cong (p : Nat) [Base p] (K j w Z κ : Nat) (hw : ∃ i, w % p = 2 ^ i % p)
    (hZ : Z % p ^ (K + 1) = (2 ^ κ * w) % p ^ (K + 1)) :
    ∃ x, x % p ^ (K + 1) = 1 % p ^ (K + 1) ∧ (2 ^ κ * w * x) % p ^ (K + j + 1) = Z % p ^ (K + j + 1) := by
  haveI : NeZero (p ^ (K + j + 1)) := ⟨Nat.pos_iff_ne_zero.1 (powp_pos p _)⟩
  have hcp : Nat.Coprime p (2 ^ κ * w) :=
    Nat.Coprime.mul_right (Nat.Coprime.pow_right κ (coprime_p_two p)) (cop_w p hw)
  obtain ⟨b, hb⟩ := exists_inv_residue (M := p ^ (K + j + 1)) (2 ^ κ * w) (Nat.Coprime.pow_left _ hcp)
  have hb' : (2 ^ κ * w * b.val) % p ^ (K + j + 1) = 1 % p ^ (K + j + 1) := by
    rw [← residue_eq_iff, residue_mul, residue_self_val, hb]; rfl
  have hZb : ∀ Q, Q ∣ p ^ (K + j + 1) → (Z * (2 ^ κ * w * b.val)) % Q = Z % Q := by
    intro Q hQ
    rw [Nat.mul_mod, mod_of_dvd_mod hQ hb', ← Nat.mul_mod, Nat.mul_one]
  refine ⟨Z * b.val, ?_, ?_⟩
  · have hd : p ^ (K + 1) ∣ p ^ (K + j + 1) := Nat.pow_dvd_pow p (by omega)
    apply mod_cancel_mul_right (Nat.Coprime.pow_left (K + 1) hcp)
    rw [Nat.one_mul, ← hZ, ← hZb _ hd]; congr 1; grind
  · rw [← hZb _ (Nat.dvd_refl _)]; congr 1; grind

theorem exp_lift_t (p : Nat) [Base p] {u : Nat} (hu : Nat.Coprime p u) (K j x : Nat)
    (hx : x % p ^ (K + 1) = 1 % p ^ (K + 1)) :
    ∃ t', t' < p ^ j ∧ (1 + p * u) ^ (p ^ K * t') % p ^ (K + j + 1) = x % p ^ (K + j + 1) := by
  have hxp : x % p = 1 := by
    have := mod_of_dvd_mod (p_dvd_pow p K) hx
    rw [this]
    exact Nat.mod_eq_of_lt (by have := Base.three_le (p := p); omega)
  obtain ⟨t, ht, hte⟩ := Gen.gen_unit Base.odd Base.three_le hu (K + j) x hxp
  have hdvd : p ^ (K + 1) ∣ p ^ (K + j + 1) := Nat.pow_dvd_pow p (by omega)
  have h1 : (1 + p * u) ^ t % p ^ (K + 1) = 1 := by
    have := mod_of_dvd_mod hdvd hte
    rw [this, hx, one_mod_P p K]
  obtain ⟨t', rfl⟩ := (Gen.order_iff Base.odd Base.three_le hu K t).1 h1
  refine ⟨t', ?_, hte⟩
  rw [Nat.pow_add] at ht
  exact Nat.lt_of_mul_lt_mul_left ht

theorem exp_lift_s (p : Nat) [Base p] (hpr : PrimeLike p) (j t' D' B : Nat) (hD0 : 0 < D') (hD3 : D' % p ≠ 0) :
    ∃ s, B ≤ s ∧ s < D' + D' * B ∧ D' ∣ t' + p ^ j * s := by
  haveI : NeZero D' := ⟨by omega⟩
  have hc : Nat.Coprime D' (p ^ j) := Nat.Coprime.pow_right j (Nat.Coprime.symm (hpr D' hD3))
  obtain ⟨b, hb⟩ := exists_inv_residue (p ^ j) hc
  have hb' : (p ^ j * b.val) % D' = 1 % D' := by
    rw [← residue_eq_iff, residue_mul, residue_self_val, hb]; rfl
  have hdvd : ∀ y, y % D' = (y * (p ^ j * b.val)) % D' := by
    intro y; rw [Nat.mul_mod y, hb', ← Nat.mul_mod, Nat.mul_one]
  refine ⟨(D' - t' % D') * b.val % D' + D' * B, by
    have := Nat.le_mul_of_pos_left B hD0; omega, by
    have := Nat.mod_lt ((D' - t' % D') * b.val) hD0; omega, ?_⟩
  apply Nat.dvd_of_mod_eq_zero
  have ht : t' % D' < D' := Nat.mod_lt _ hD0
  have key : (p ^ j * ((D' - t' % D') * b.val % D')) % D' = (D' - t' % D') % D' := by
    rw [Nat.mul_mod, Nat.mod_mod, ← Nat.mul_mod, hdvd (D' - t' % D')]
    congr 1; grind
  rw [Nat.mul_add, ← Nat.add_assoc, Nat.mul_left_comm, Nat.add_mul_mod_self_left,
    Nat.add_mod, key, Nat.add_mod_mod, Nat.mod_add_mod,
    show t' + (D' - t' % D') = D' * (t' / D' + 1) by have := Nat.div_add_mod t' D'; grind,
    Nat.mul_mod_right]

theorem exp_lift (p : Nat) [Base p] (hpr : PrimeLike p) {d u : Nat} (hd0 : 0 < d) (hd : 2 ^ d = 1 + p * u)
    (hu : Nat.Coprime p u)
    (M K j w Z κ D' B : Nat) (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p)
    (hD0 : 0 < D') (hD3 : D' % p ≠ 0) (hD : 2 ^ (p ^ K * D') % M = 1 % M)
    (hZ : Z % (p ^ (K + 1) * M) = (2 ^ κ * w) % (p ^ (K + 1) * M)) :
    ∃ k, B ≤ k ∧
      k ≤ d * p ^ (K + j) * (κ + 1) + d * p ^ (K + j) * (D' * D' * (d * p ^ (K + j) * (κ + 1))
        + p ^ K * D' * B) ∧
      Z % (p ^ (K + j + 1) * M) = (2 ^ k * w) % (p ^ (K + j + 1) * M) := by
  obtain ⟨x, hx1, hxZ⟩ := exp_lift_cong p K j w Z κ hw (mod_of_dvd_mod (Nat.dvd_mul_right _ _) hZ)
  obtain ⟨t', ht', hte⟩ := exp_lift_t p hu K j x hx1
  obtain ⟨s, hBs, hsl, ⟨c, hc⟩⟩ := exp_lift_s p hpr j t' D' B hD0 hD3
  have hpK := powp_pos p K
  have hpj := powp_pos p j
  have hpow : p ^ (K + j) = p ^ K * p ^ j := Nat.pow_add p K j
  refine ⟨κ + d * p ^ K * (t' + p ^ j * s), ?_, ?_, ?_⟩
  ·
    have : s ≤ d * p ^ K * (t' + p ^ j * s) := by
      have h1 : s ≤ p ^ j * s := Nat.le_mul_of_pos_left s hpj
      have h2 : 1 ≤ d * p ^ K := Nat.mul_pos hd0 hpK
      calc s ≤ t' + p ^ j * s := by omega
        _ ≤ d * p ^ K * (t' + p ^ j * s) := Nat.le_mul_of_pos_left _ h2
    omega
  ·
    have hA : 1 ≤ d * p ^ (K + j) := Nat.mul_pos hd0 (powp_pos p _)
    have e1 : d * p ^ K * (t' + p ^ j * s) = d * p ^ K * t' + d * p ^ (K + j) * s := by
      rw [hpow, Nat.mul_add]; grind
    have e2 : d * p ^ K * t' ≤ d * p ^ (K + j) := by
      rw [hpow, ← Nat.mul_assoc]; exact Nat.mul_le_mul_left _ (Nat.le_of_lt ht')
    have e3 : s ≤ D' + D' * B := Nat.le_of_lt hsl
    have e4 : D' ≤ D' * D' * (d * p ^ (K + j) * (κ + 1)) := by
      have h := Nat.mul_pos hD0 (Nat.mul_pos hA (Nat.succ_pos κ))
      have := Nat.le_mul_of_pos_right D' h
      rw [Nat.mul_assoc D' D']; exact this
    have e5 : D' * B ≤ p ^ K * D' * B := by
      rw [Nat.mul_assoc]; exact Nat.le_mul_of_pos_left _ hpK
    have e6 : d * p ^ (K + j) * s ≤ d * p ^ (K + j) * (D' * D' * (d * p ^ (K + j) * (κ + 1)) + p ^ K * D' * B) :=
      Nat.mul_le_mul_left _ (by omega)
    have e7 : κ + d * p ^ (K + j) ≤ d * p ^ (K + j) * (κ + 1) := by
      rw [Nat.mul_add, Nat.mul_one]; have := Nat.le_mul_of_pos_left κ hA; omega
    omega
  ·
    have hPM : Nat.Coprime (p ^ (K + j + 1)) M :=
      Nat.Coprime.pow_left _ (Nat.Coprime.symm (cop_M_p hM))
    symm
    apply mod_combine hPM
    · have hord : (1 + p * u) ^ (p ^ (K + j) * s) % p ^ (K + j + 1) = 1 :=
        (Gen.order_iff Base.odd Base.three_le hu (K + j) _).2 (Nat.dvd_mul_right _ _)
      have hk : 2 ^ (κ + d * p ^ K * (t' + p ^ j * s)) * w
          = 2 ^ κ * w * (1 + p * u) ^ (p ^ K * t') * (1 + p * u) ^ (p ^ (K + j) * s) := by
        have hex : κ + d * p ^ K * (t' + p ^ j * s) = κ + d * (p ^ K * t') + d * (p ^ (K + j) * s) := by
          rw [hpow]; grind
        rw [hex, Nat.pow_add, Nat.pow_add, Nat.pow_mul 2 d (p ^ K * t'), Nat.pow_mul 2 d (p ^ (K + j) * s), hd]
        ac_rfl
      rw [hk, Nat.mul_mod, hord, Nat.mul_one, Nat.mod_mod, Nat.mul_mod, hte, ← Nat.mul_mod, hxZ]
    · have hk : κ + d * p ^ K * (t' + p ^ j * s) = κ + p ^ K * D' * (d * c) := by
        rw [hc]; grind
      rw [hk, Nat.mul_mod, pow_mod_period hD κ, ← Nat.mul_mod]
      exact (mod_of_dvd_mod (Nat.dvd_mul_left _ _) hZ).symm

theorem pow2bound_mul {x y a b : Nat} (hx : x ≤ 2 ^ a) (hy : y ≤ 2 ^ b) : x * y ≤ 2 ^ (a + b) := by
  rw [Nat.pow_add]; exact Nat.mul_le_mul hx hy
theorem pow2bound_le {x a a' : Nat} (hx : x ≤ 2 ^ a) (h : a ≤ a') : x ≤ 2 ^ a' :=
  Nat.le_trans hx (Nat.pow_le_pow_right (by omega) h)
theorem pow2bound_add {x y a : Nat} (hx : x ≤ 2 ^ a) (hy : y ≤ 2 ^ a) : x + y ≤ 2 ^ (a + 1) := by
  rw [Nat.pow_succ]; omega
theorem pow_le_of_le (p L n : Nat) (hpL : p ≤ 2 ^ L) : p ^ n ≤ 2 ^ (L * n) := by
  rw [Nat.pow_mul]; exact Nat.pow_le_pow_left hpL n
theorem two_p_pow_le (p L n : Nat) (hpL : p ≤ 2 ^ L) : (2 * p) ^ n ≤ 2 ^ ((L + 1) * n) := by
  rw [Nat.pow_mul, Nat.pow_succ, Nat.mul_comm (2 ^ L)]
  exact Nat.pow_le_pow_left (Nat.mul_le_mul_left 2 hpL) n
theorem bound_arith (p L X K jv len d d' κ C B : Nat) (hL : 2 ≤ L) (hpL : p ≤ 2 ^ L) (hX3 : 3 ≤ X)
    (hd : d ≤ p) (hpX : p ≤ X) (hK : p ^ K ≤ X) (hjv : jv ≤ X)
    (hlen : len ≤ X) (hd' : d' ≤ X) (hκ : κ ≤ 2 * X) (hC : C ≤ (2 * p) ^ X) (hB : B ≤ X) :
    d * p ^ (K + jv) * (κ + 1) + d * p ^ (K + jv) * (d' * d' * (d * p ^ (K + jv) * (κ + 1))
      + p ^ K * d' * (C + len + p ^ jv * (B + 1))) ≤ 2 ^ ((3 * L + 7) * X) := by
  have hXp : X < 2 ^ X := Nat.lt_two_pow_self
  have eq1 : (L + 1) * X = L * X + X := by rw [Nat.add_mul, Nat.one_mul]
  have eqT : (3 * L + 7) * X = 3 * (L * X) + 7 * X := by rw [Nat.add_mul, Nat.mul_assoc]
  have hq : 2 * X ≤ L * X := Nat.mul_le_mul_right X hL
  have hpj : p ^ jv ≤ 2 ^ (L * X) :=
    pow2bound_le (pow_le_of_le p L jv hpL) (Nat.mul_le_mul_left L hjv)
  have hCq : C ≤ 2 ^ (L * X + X) := by rw [← eq1]; exact Nat.le_trans hC (two_p_pow_le p L X hpL)
  rw [eqT]
  generalize L * X = q at hpj hCq hq
  have hdX : d ≤ 2 ^ X := by omega
  have hKX : p ^ K ≤ 2 ^ X := by omega
  have hd'X : d' ≤ 2 ^ X := by omega
  have hlX : len ≤ 2 ^ X := by omega
  have hBX : B + 1 ≤ 2 ^ X := by omega
  have hκX : κ + 1 ≤ 2 ^ (2 * X) := by
    have : 2 * X < 2 ^ (2 * X) := Nat.lt_two_pow_self; omega
  have hA : d * p ^ (K + jv) ≤ 2 ^ (X + (X + q)) := by
    rw [Nat.pow_add]; exact pow2bound_mul hdX (pow2bound_mul hKX hpj)
  have h1 : d * p ^ (K + jv) * (κ + 1) ≤ 2 ^ (X + (X + q) + 2 * X) := pow2bound_mul hA hκX
  have h2 : d' * d' * (d * p ^ (K + jv) * (κ + 1)) ≤ 2 ^ (X + X + (X + (X + q) + 2 * X)) :=
    pow2bound_mul (pow2bound_mul hd'X hd'X) h1
  have h3 : p ^ jv * (B + 1) ≤ 2 ^ (q + X) := pow2bound_mul hpj hBX
  have h4 : C + len + p ^ jv * (B + 1) ≤ 2 ^ (q + X + 2) := by
    have a : C + len ≤ 2 ^ (q + X + 1) := pow2bound_add hCq (pow2bound_le hlX (by omega))
    have b : p ^ jv * (B + 1) ≤ 2 ^ (q + X + 1) := pow2bound_le h3 (by omega)
    exact pow2bound_add a b
  have h5 : p ^ K * d' * (C + len + p ^ jv * (B + 1)) ≤ 2 ^ (X + X + (q + X + 2)) :=
    pow2bound_mul (pow2bound_mul hKX hd'X) h4
  have h6 : d' * d' * (d * p ^ (K + jv) * (κ + 1)) + p ^ K * d' * (C + len + p ^ jv * (B + 1))
      ≤ 2 ^ (q + 6 * X + 1) := pow2bound_add (pow2bound_le h2 (by omega)) (pow2bound_le h5 (by omega))
  have h7 := pow2bound_mul hA h6
  exact pow2bound_le (pow2bound_add (pow2bound_le h1 (by omega : _ ≤ X + (X + q) + (q + 6 * X + 1))) h7) (by omega)

theorem pow2_period_lift (p : Nat) [Base p] {d u : Nat} (hd : 2 ^ d = 1 + p * u) (hu : Nat.Coprime p u)
    (M K D' : Nat) (hM : Nat.Coprime M (2 * p)) (hD : 2 ^ (p ^ K * D') % M = 1 % M) :
    2 ^ (d * p ^ K * D') % (p ^ (K + 1) * M) = 1 % (p ^ (K + 1) * M) := by
  apply mod_combine (Nat.Coprime.pow_left _ (Nat.Coprime.symm (cop_M_p hM)))
  · rw [Nat.mul_assoc, Nat.pow_mul, hd, one_mod_P p K]
    exact (Gen.order_iff Base.odd Base.three_le hu K _).2 (Nat.dvd_mul_right _ _)
  · rw [Nat.mul_assoc, Nat.mul_comm d, Nat.pow_mul, Nat.pow_mod, hD, ← Nat.pow_mod, Nat.one_pow]

theorem hit_residue (p : Nat) [Base p] (hpr : PrimeLike p) (L : Nat) (hpL : p ≤ 2 ^ L)
    (M b' e B w X : Nat) (hM : Nat.Coprime M (2 * p)) (hw : ∃ i, w % p = 2 ^ i % p)
    (hX : p * (p ^ b' * M * M) ≤ X) (hBX : B ≤ X) :
    ∃ m, B < m ∧ m % (p ^ b' * M) = e % (p ^ b' * M) ∧ Reaches p w m ∧
      m ≤ w * 2 ^ (2 ^ ((3 * L + 7) * X)) := by
  have hp3 := Base.three_le (p := p)
  have hL : 2 ≤ L := Classical.byContradiction fun h => by
    have h2 : 2 ^ L ≤ 2 ^ 1 := Nat.pow_le_pow_right (by omega) (by omega)
    rw [Nat.pow_one] at h2; omega
  have hM0 : 0 < M := by
    rcases Nat.eq_zero_or_pos M with h | h
    · subst h; unfold Nat.Coprime at hM; rw [Nat.gcd_zero_left] at hM; omega
    · exact h
  haveI : NeZero M := ⟨by omega⟩
  obtain ⟨dg, ug, hdg0, hdgp, hdg, hug⟩ := Base.gen (p := p)
  obtain ⟨D, hD0, hDM, hD⟩ := exists_pow2_period M hM0 (cop_M_two hM)
  obtain ⟨ν, d', hDd, hd3⟩ := split_p p D hD0
  obtain ⟨K, hKd⟩ : ∃ K, K = ν + b' := ⟨_, rfl⟩
  have hKν : ν ≤ K := by omega
  have hKb : b' ≤ K + 1 := by omega
  have hd'pos : 1 ≤ d' := by
    rcases Nat.eq_zero_or_pos d' with h | h
    · subst h; omega
    · exact h
  have h3ν : 0 < p ^ ν := powp_pos p ν
  have hper : 2 ^ (p ^ K * d') % M = 1 % M := by
    have e1 : p ^ K = p ^ ν * p ^ (K - ν) := by rw [← Nat.pow_add, Nat.add_sub_cancel' hKν]
    have e2 : p ^ K * d' = D * p ^ (K - ν) := by rw [hDd, e1]; grind
    rw [e2, Nat.pow_mul, Nat.pow_mod, hD, ← Nat.pow_mod, Nat.one_pow]
  have hν3 : p ^ ν ≤ M := by
    have := Nat.le_mul_of_pos_right (p ^ ν) hd'pos
    rw [← hDd] at this; omega
  have hd'M : d' ≤ M := by
    have := Nat.le_mul_of_pos_left d' h3ν
    rw [← hDd] at this; omega
  have hK3 : p ^ K ≤ p ^ b' * M := by
    rw [hKd, Nat.pow_add]
    calc p ^ ν * p ^ b' ≤ M * p ^ b' := Nat.mul_le_mul_right _ hν3
      _ = p ^ b' * M := Nat.mul_comm _ _
  have hS : 0 < p ^ b' * M := Nat.mul_pos (powp_pos p _) hM0
  rw [← Nat.mul_assoc] at hX
  have hSX : p ^ b' * M ≤ X := by
    have h1 := Nat.le_mul_of_pos_right (p * (p ^ b' * M)) hM0
    have h2 := Nat.le_mul_of_pos_left (p ^ b' * M) (show 0 < p by omega)
    omega
  have hMX : M ≤ X := by
    have := Nat.le_mul_of_pos_left M (show 0 < p * (p ^ b' * M) by exact Nat.mul_pos (by omega) hS)
    omega
  have hpX : p ≤ X := by
    have h1 := Nat.le_mul_of_pos_right p hS
    have h2 := Nat.le_mul_of_pos_right (p * (p ^ b' * M)) hM0
    omega
  have hX3 : 3 ≤ X := by omega
  have hQ : p ^ (K + 1) * M = p * p ^ K * M := by rw [Nat.pow_succ]; grind
  have hQX : p ^ (K + 1) * M ≤ X := by
    rw [hQ]
    exact Nat.le_trans (Nat.mul_le_mul_right M (Nat.mul_le_mul_left p hK3)) hX
  have hK3X : p ^ K ≤ X := Nat.le_trans hK3 hSX
  have hd'X : d' ≤ X := Nat.le_trans hd'M hMX
  have hπX : dg * p ^ K * d' ≤ X := by
    have h1 := Nat.mul_le_mul (Nat.mul_le_mul hdgp hK3) hd'M
    exact Nat.le_trans h1 hX
  have hπpos : 0 < dg * p ^ K * d' := Nat.mul_pos (Nat.mul_pos hdg0 (powp_pos p _)) hd'pos
  obtain ⟨u, kk, hu, hlen, hk'⟩ := closure_word_short p M K w hM hw e
  have hlenX : u.length ≤ X := Nat.le_trans hlen hQX
  have hπ := pow2_period_lift p hdg hug M K d' hM hper
  have hkr : (p ^ oneCount u * e + offset p u) % (p ^ (K + 1) * M)
      = (2 ^ (u.length + kk % (dg * p ^ K * d')) * w) % (p ^ (K + 1) * M) := by
    have h1 : 2 ^ (u.length + kk) % (p ^ (K + 1) * M)
        = 2 ^ (u.length + kk % (dg * p ^ K * d')) % (p ^ (K + 1) * M) := by
      have e' : u.length + kk = (u.length + kk % (dg * p ^ K * d')) + (dg * p ^ K * d') * (kk / (dg * p ^ K * d')) := by
        have := Nat.mod_add_div kk (dg * p ^ K * d'); omega
      rw [e']; exact pow_mod_period hπ _ _
    exact hk'.trans (mod_mul_right_cong w h1)
  have hκ : u.length + kk % (dg * p ^ K * d') ≤ 2 * X := by
    have := Nat.mod_lt kk hπpos; omega
  have hw1 : 1 ≤ w := by
    rcases Nat.eq_zero_or_pos w with h | h
    · subst h; have := cop_w p hw; unfold Nat.Coprime at this; rw [Nat.gcd_zero_right] at this; omega
    · exact h
  obtain ⟨k, hk, hkU, hkZ⟩ := exp_lift p hpr hdg0 hdg hug M K (oneCount u) w (p ^ oneCount u * e + offset p u)
    (u.length + kk % (dg * p ^ K * d')) d' (offset p u + u.length + p ^ oneCount u * (B + 1)) hM hw hd'pos hd3 hper hkr
  have hU := bound_arith p L X K (oneCount u) u.length dg d' (u.length + kk % (dg * p ^ K * d')) (offset p u) B
    hL hpL hX3 hdgp hpX hK3X (Nat.le_trans (oneCount_le u hu) hlenX) hlenX hd'X hκ
    (Nat.le_trans (offset_le p u hu) (Nat.pow_le_pow_right (by omega) hlenX)) hBX
  have hkX : k ≤ 2 ^ ((3 * L + 7) * X) := Nat.le_trans hkU hU
  have hbig : offset p u + u.length + p ^ oneCount u * (B + 1) < 2 ^ k * w :=
    Nat.lt_of_le_of_lt hk (Nat.lt_of_lt_of_le Nat.lt_two_pow_self (Nat.le_mul_of_pos_right _ hw1))
  have hj0 : 0 < p ^ oneCount u := powp_pos p _
  have hdv : p ^ oneCount u ∣ p ^ (K + oneCount u + 1) * M :=
    Nat.dvd_trans (Nat.pow_dvd_pow p (by omega)) (Nat.dvd_mul_right _ _)
  have hd : (2 ^ k * w - offset p u) % p ^ oneCount u = 0 := by
    apply Nat.sub_mod_eq_zero_of_mod_eq
    rw [mod_of_dvd_mod hdv hkZ.symm, Nat.add_mod, Nat.mul_mod_right, Nat.zero_add, Nat.mod_mod]
  have hm3 := Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero hd)
  obtain ⟨m, hm⟩ : ∃ m, m = (2 ^ k * w - offset p u) / p ^ oneCount u := ⟨_, rfl⟩
  rw [← hm] at hm3
  rw [Nat.mul_add, Nat.mul_one] at hbig
  have heq : p ^ oneCount u * m + offset p u = 2 ^ k * w := by omega
  have hmB : B < m := by
    apply Classical.byContradiction
    intro hc
    have := Nat.mul_le_mul_left (p ^ oneCount u) (Nat.le_of_not_lt hc)
    omega
  refine ⟨m, hmB, ?_, ?_, ?_⟩
  · have h1 : (offset p u + p ^ oneCount u * m) % (p ^ (K + oneCount u + 1) * M) = (offset p u + p ^ oneCount u * e) % (p ^ (K + oneCount u + 1) * M) := by
      rw [Nat.add_comm (offset p u) (p ^ oneCount u * m), Nat.add_comm (offset p u) (p ^ oneCount u * e), heq]
      exact hkZ.symm
    have h2 := mod_add_left_cancel h1
    have hBig : p ^ (K + oneCount u + 1) * M = p ^ oneCount u * (p ^ (K + 1) * M) := by
      rw [show K + oneCount u + 1 = oneCount u + (K + 1) by omega, Nat.pow_add, Nat.mul_assoc]
    rw [hBig, Nat.mul_mod_mul_left, Nat.mul_mod_mul_left] at h2
    have h3 := Nat.eq_of_mul_eq_mul_left hj0 h2
    exact mod_of_dvd_mod (Nat.mul_dvd_mul_right (Nat.pow_dvd_pow p hKb) M) h3
  · have hak : u.length ≤ k := by omega
    have hdiv : 2 ^ u.length ∣ p ^ oneCount u * m + offset p u :=
      ⟨2 ^ (k - u.length) * w, by rw [heq, ← Nat.mul_assoc, ← Nat.pow_add, Nat.add_sub_cancel' hak]⟩
    have hq : (p ^ oneCount u * m + offset p u) / 2 ^ u.length = 2 ^ (k - u.length) * w := by
      rw [heq, show 2 ^ k * w = 2 ^ u.length * (2 ^ (k - u.length) * w) by
        rw [← Nat.mul_assoc, ← Nat.pow_add, Nat.add_sub_cancel' hak]]
      exact Nat.mul_div_cancel_left _ (Nat.pow_pos (by omega))
    have hr := integrality_reaches p u hu m hdiv
    rw [hq] at hr
    exact reaches_trans p hr (reaches_pow2 p w _)
  · have h1 : m ≤ p ^ oneCount u * m := Nat.le_mul_of_pos_left m hj0
    have h2 : m ≤ 2 ^ k * w := by omega
    have h3 : 2 ^ k ≤ 2 ^ (2 ^ ((3 * L + 7) * X)) := Nat.pow_le_pow_right (by omega) hkX
    calc m ≤ 2 ^ k * w := h2
      _ ≤ 2 ^ (2 ^ ((3 * L + 7) * X)) * w := Nat.mul_le_mul_right w h3
      _ = w * 2 ^ (2 ^ ((3 * L + 7) * X)) := Nat.mul_comm _ _

theorem remainder_bounded (p : Nat) [Base p] (hpr : PrimeLike p) (L : Nat) (hpL : p ≤ 2 ^ L)
    (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : ∃ i, w % p = 2 ^ i % p) (r B : Nat) :
    ∃ n : Nat, B < n ∧ Reaches p w n ∧ n % N = r % N ∧
      n ≤ w * 2 ^ (2 ^ ((3 * L + 8) * (p * N ^ (L + 2) * (B + 1)))) := by
  have hp3 := Base.three_le (p := p)
  obtain ⟨α, b, M, hNd, h6⟩ := split_two_p p hpr N hN
  have hM0 : 0 < M := by
    rcases Nat.eq_zero_or_pos M with h | h
    · subst h; unfold Nat.Coprime at h6; rw [Nat.gcd_zero_left] at h6; omega
    · exact h
  obtain ⟨q, hql, hqe, e, he0⟩ := parity_word p α (r % N)
  have hr0 : r % N < N := Nat.mod_lt _ (by omega)
  have h2pos : 0 < 2 ^ α := Nat.pow_pos (by omega)
  have h3bM : 0 < p ^ b * M := Nat.mul_pos (powp_pos p _) hM0
  have hNe : N = 2 ^ α * (p ^ b * M) := by rw [hNd]; grind
  have h2aN : 2 ^ α ≤ N := by
    rw [hNe]; exact Nat.le_mul_of_pos_right _ h3bM
  have h3bMN : p ^ b * M ≤ N := by
    rw [hNe]; exact Nat.le_mul_of_pos_left _ h2pos
  have hMN : M ≤ N := Nat.le_trans (Nat.le_mul_of_pos_left M (powp_pos p _)) h3bMN
  have h3αN : p ^ α ≤ N ^ L := by
    have h1 := pow_le_of_le p L α hpL
    have h2 : 2 ^ (L * α) = (2 ^ α) ^ L := by rw [Nat.mul_comm, Nat.pow_mul]
    exact Nat.le_trans h1 (by rw [h2]; exact Nat.pow_le_pow_left h2aN L)
  have hjp : oneCount q ≤ α := by have := oneCount_le q hqe; rw [hql] at this; exact this
  have h3jp : p ^ oneCount q ≤ N ^ L :=
    Nat.le_trans (Nat.pow_le_pow_right (by omega) hjp) h3αN
  have hN4 : N ^ (L + 1) = N ^ L * N := Nat.pow_succ N L
  have hN5 : N ^ (L + 2) = N ^ (L + 1) * N := Nat.pow_succ N (L + 1)
  have h13 : N ^ L ≤ N ^ (L + 1) := Nat.pow_le_pow_right (by omega) (by omega)
  have h14 : N ^ (L + 1) ≤ N ^ (L + 2) := Nat.pow_le_pow_right (by omega) (by omega)
  have hS3 : p ^ (oneCount q + b) * M ≤ N ^ (L + 1) := by
    rw [Nat.pow_add, Nat.mul_assoc, hN4]; exact Nat.mul_le_mul h3jp h3bMN
  have hSM : p ^ (oneCount q + b) * M * M ≤ N ^ (L + 2) := by
    rw [hN5]; exact Nat.mul_le_mul hS3 hMN
  have hXe : p * N ^ (L + 2) * (B + 1) = p * (N ^ (L + 2) * B) + p * N ^ (L + 2) := by grind
  have hX : p * (p ^ (oneCount q + b) * M * M) ≤ p * N ^ (L + 2) * (B + 1) := by
    have := Nat.mul_le_mul_left p hSM
    have h2 := Nat.le_mul_of_pos_left (N ^ (L + 2) * B) (show 0 < p by omega)
    omega
  have hcc : offset p q ≤ 2 ^ α * N ^ L := by
    have h1 := offset_le p q hqe
    rw [hql, Nat.mul_pow] at h1
    exact Nat.le_trans h1 (Nat.mul_le_mul (Nat.le_refl _) h3αN)
  have h3r : p ^ oneCount q * (r % N) ≤ N ^ (L + 1) := by
    rw [hN4]; exact Nat.mul_le_mul h3jp (Nat.le_of_lt hr0)
  have h2N3 : 2 ^ α * N ^ L ≤ N ^ (L + 1) := by
    calc 2 ^ α * N ^ L ≤ N * N ^ L := Nat.mul_le_mul_right _ h2aN
      _ = N ^ (L + 1) := by rw [hN4]; grind
  have he1 : e ≤ 2 * N ^ (L + 1) := by
    have h1 : e ≤ 2 ^ α * e := Nat.le_mul_of_pos_left e h2pos
    omega
  have hBX : e + p ^ oneCount q * B ≤ p * N ^ (L + 2) * (B + 1) := by
    have h2 : p ^ oneCount q * B ≤ N ^ (L + 2) * B :=
      Nat.mul_le_mul_right B (Nat.le_trans h3jp (Nat.le_trans h13 h14))
    have h3 := Nat.le_mul_of_pos_left (N ^ (L + 2) * B) (show 0 < p by omega)
    have h4 := Nat.mul_le_mul_right (N ^ (L + 2)) hp3
    omega
  obtain ⟨m, hmB, hmc, hmw, hmbd⟩ :=
    hit_residue p hpr L hpL M (oneCount q + b) e (e + p ^ oneCount q * B) w (p * N ^ (L + 2) * (B + 1)) h6 hw hX hBX
  have hj0 : 0 < p ^ oneCount q := powp_pos p _
  have h0 := Nat.sub_mod_eq_zero_of_mod_eq hmc
  obtain ⟨s, hs⟩ := Nat.dvd_of_mod_eq_zero h0
  have hm' : m = e + p ^ oneCount q * (p ^ b * M * s) := by
    have : m - e = p ^ oneCount q * (p ^ b * M * s) := by rw [hs, Nat.pow_add]; grind
    omega
  have htB : B < p ^ b * M * s := by
    apply Classical.byContradiction
    intro hc
    have := Nat.mul_le_mul_left (p ^ oneCount q) (Nat.le_of_not_lt hc)
    omega
  have htm : p ^ b * M * s ≤ m := by
    have := Nat.le_mul_of_pos_left (p ^ b * M * s) hj0
    omega
  have hn : p ^ oneCount q * (r % N + 2 ^ α * (p ^ b * M * s)) + offset p q
      = 2 ^ α * (e + p ^ oneCount q * (p ^ b * M * s)) := by
    have : p ^ oneCount q * (r % N + 2 ^ α * (p ^ b * M * s)) + offset p q
        = (p ^ oneCount q * (r % N) + offset p q) + 2 ^ α * (p ^ oneCount q * (p ^ b * M * s)) := by grind
    rw [this, he0]; grind
  have hm1 : 1 ≤ m := by omega
  generalize hXdef : p * N ^ (L + 2) * (B + 1) = X at hmbd hXe
  refine ⟨r % N + 2 ^ α * (p ^ b * M * s), ?_, ?_, ?_, ?_⟩
  · have := Nat.le_mul_of_pos_left (p ^ b * M * s) h2pos
    omega
  · have hdiv : 2 ^ q.length ∣ p ^ oneCount q * (r % N + 2 ^ α * (p ^ b * M * s)) + offset p q := by
      rw [hql, hn]; exact Nat.dvd_mul_right _ _
    have hr := integrality_reaches p q hqe _ hdiv
    rw [hql, hn, Nat.mul_div_cancel_left _ h2pos, ← hm'] at hr
    exact reaches_trans p hr hmw
  · rw [show 2 ^ α * (p ^ b * M * s) = N * s by rw [hNe]; grind, Nat.add_mul_mod_self_left, Nat.mod_mod]
  · have hn1 : r % N + 2 ^ α * (p ^ b * M * s) ≤ 2 * (N * m) := by
      have h1 : 2 ^ α * (p ^ b * M * s) ≤ N * m := Nat.mul_le_mul h2aN htm
      have h2 : N ≤ N * m := Nat.le_mul_of_pos_right N hm1
      omega
    have hX1 : N ≤ X := by
      have := Nat.le_self_pow (show L + 2 ≠ 0 by omega) N
      have := Nat.le_mul_of_pos_left (N ^ (L + 2) * B) (show 0 < p by omega)
      have := Nat.mul_le_mul_right (N ^ (L + 2)) hp3
      omega
    have hE8 : (3 * L + 8) * X = (3 * L + 7) * X + X := by rw [Nat.add_mul (3 * L + 7) 1, Nat.one_mul]
    have hE7 : X ≤ (3 * L + 7) * X := Nat.le_mul_of_pos_left X (by omega)
    rw [hE8]
    generalize (3 * L + 7) * X = E at hmbd hE7
    have hN2 : 2 * N ≤ 2 ^ (N + 1) := by
      have := Nat.lt_two_pow_self (n := N)
      rw [Nat.pow_succ]; omega
    have hN1 : N + 1 ≤ 2 ^ E :=
      Nat.le_trans Nat.lt_two_pow_self (Nat.pow_le_pow_right (by omega) (by omega))
    have hexp : N + 1 + 2 ^ E ≤ 2 ^ (E + X) := by
      have h1 : 2 ^ (E + 1) ≤ 2 ^ (E + X) := Nat.pow_le_pow_right (by omega) (by omega)
      have h2 : 2 ^ (E + 1) = 2 ^ E * 2 := Nat.pow_succ 2 _
      omega
    calc r % N + 2 ^ α * (p ^ b * M * s) ≤ 2 * (N * m) := hn1
      _ ≤ 2 * (N * (w * 2 ^ (2 ^ E))) := Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left N hmbd)
      _ = (2 * N) * w * 2 ^ (2 ^ E) := by grind
      _ ≤ 2 ^ (N + 1) * w * 2 ^ (2 ^ E) := Nat.mul_le_mul_right _ (Nat.mul_le_mul_right w hN2)
      _ = w * 2 ^ (N + 1 + 2 ^ E) := by rw [Nat.pow_add]; grind
      _ ≤ w * 2 ^ (2 ^ (E + X)) := Nat.mul_le_mul_left w (Nat.pow_le_pow_right (by omega) hexp)

theorem effective_remainder_everywhere (p : Nat) [Base p] (hpr : PrimeLike p) (L : Nat)
    (hpL : p ≤ 2 ^ L) (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : ∃ i, w % p = 2 ^ i % p) (r : Nat) :
    ∃ n : Nat, Reaches p w n ∧ n % N = r % N ∧
      n ≤ w * 2 ^ (2 ^ ((3 * L + 8) * (p * N ^ (L + 2)))) := by
  obtain ⟨n, _, h1, h2, h3⟩ := remainder_bounded p hpr L hpL N hN w hw r 0
  exact ⟨n, h1, h2, by rw [Nat.zero_add, Nat.mul_one] at h3; exact h3⟩

instance base3 : Base 3 := ⟨by decide, by decide, ⟨2, 1, by decide, by decide, by decide, by decide⟩⟩
instance base5 : Base 5 := ⟨by decide, by decide, ⟨4, 3, by decide, by decide, by decide, by decide⟩⟩

theorem primeLike3 : PrimeLike 3 := by
  intro N hN; unfold Nat.Coprime; rw [Nat.gcd_rec]
  rcases (by omega : N % 3 = 1 ∨ N % 3 = 2) with h | h <;> rw [h] <;> rfl

theorem primeLike5 : PrimeLike 5 := by
  intro N hN; unfold Nat.Coprime; rw [Nat.gcd_rec]
  rcases (by omega : N % 5 = 1 ∨ N % 5 = 2 ∨ N % 5 = 3 ∨ N % 5 = 4) with h | h | h | h <;> rw [h] <;> rfl

theorem bound_mono (w E E' n : Nat) (h : n ≤ w * 2 ^ (2 ^ E)) (hE : E ≤ E') : n ≤ w * 2 ^ (2 ^ E') :=
  Nat.le_trans h (Nat.mul_le_mul_left w (Nat.pow_le_pow_right (by omega) (Nat.pow_le_pow_right (by omega) hE)))

theorem cor_p3 (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : w % 3 ≠ 0) (r : Nat) :
    ∃ n : Nat, Reaches 3 w n ∧ n % N = r % N ∧ n ≤ w * 2 ^ (2 ^ (48 * N ^ 4)) := by
  have hw' : ∃ i, w % 3 = 2 ^ i % 3 := by
    rcases (by omega : w % 3 = 1 ∨ w % 3 = 2) with h | h
    · exact ⟨0, by rw [h]⟩
    · exact ⟨1, by rw [h]⟩
  obtain ⟨n, h1, h2, h3⟩ := effective_remainder_everywhere 3 primeLike3 2 (by decide) N hN w hw' r
  exact ⟨n, h1, h2, bound_mono w _ _ n h3 (by rw [show (2 + 2 : Nat) = 4 from rfl]; omega)⟩

theorem cor_p5 (N : Nat) (hN : 1 ≤ N) (w : Nat) (hw : w % 5 ≠ 0) (r : Nat) :
    ∃ n : Nat, Reaches 5 w n ∧ n % N = r % N ∧ n ≤ w * 2 ^ (2 ^ (105 * N ^ 5)) := by
  have hw' : ∃ i, w % 5 = 2 ^ i % 5 := by
    rcases (by omega : w % 5 = 1 ∨ w % 5 = 2 ∨ w % 5 = 3 ∨ w % 5 = 4) with h | h | h | h
    · exact ⟨0, by rw [h]⟩
    · exact ⟨1, by rw [h]⟩
    · exact ⟨3, by rw [h]⟩
    · exact ⟨2, by rw [h]⟩
  obtain ⟨n, h1, h2, h3⟩ := effective_remainder_everywhere 5 primeLike5 3 (by decide) N hN w hw' r
  exact ⟨n, h1, h2, bound_mono w _ _ n h3 (by rw [show (3 + 2 : Nat) = 5 from rfl]; omega)⟩

end PX
