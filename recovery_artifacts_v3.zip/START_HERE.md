# START HERE (recovery_artifacts_v3, 2026-11-04)
px+1 map coverage project. One zip, everything needed to continue.

## Precedence (newest wins on conflict)
1. PLAN_V3.md: the current plan, vision, working rules, open questions.
2. PROOF_SKETCH.md + INSIGHTS_SESSION2.md: the new paper proof and session-2 insights (their next-step lists are merged into PLAN_V3).
3. UNDERSTANDING_NOTES.md, CHECKPOINT.md, PLAN.md: session-1 notes; historical where they conflict (§3 "replacement not found" and §8(iii) N^(L+2) guess are superseded).
4. README.md: still the authority on the Lean files and how to build them (its future-work item 4 is resolved).

## Contents
- EREp.lean (canonical), split/ (same 173 decls), reference/ERE5.lean, Period.lean, verification.log: the certified Lean proof.
- Handoff_Universal_Coverage_for_px_1.md: original handoff (Thm 1 generation, Thm 2 necessity).
- scripts/: numerical checks from session 2 (do not rerun; results in PROOF_SKETCH.md).
- mathlib_probe/: crawl script + notes on why a Mathlib subset is not viable.

## Single next step
PLAN_V3 roadmap stage 1: write PROOF_SKETCH Steps 3 and 4 in full, then get them checked.
