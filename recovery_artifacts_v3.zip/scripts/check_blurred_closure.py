from math import gcd
def reach_all(p,K,M,w):
    Q=p**(K+1)*M
    inv2=pow(2,-1,Q)
    # backward closure from w: x in X if h(x)=x/2 in X  (x=2*y) or u(x)=(p x+1)/2 in X
    # forward maps h,u on Z/Q; compute set of x that reach w: BFS on reverse edges
    pre={}
    for x in range(Q):
        for y in ((x*inv2)%Q, ((p*x+1)*inv2)%Q):
            pre.setdefault(y,[]).append(x)
    seen={w%Q}; st=[w%Q]
    while st:
        y=st.pop()
        for x in pre.get(y,[]):
            if x not in seen: seen.add(x); st.append(x)
    return len(seen)==Q, len(seen), Q
def ordgroup(p):
    s={1};x=2%p
    while x not in s: s.add(x);x=x*2%p
    return s
bad=0;tot=0
for p in (3,5,7,11,13):
    assert pow(2,p-1,p*p)!=1
    G=ordgroup(p)
    for K in (0,1,2):
        for M in [m for m in range(1,40) if gcd(m,2*p)==1]:
            if p**(K+1)*M>6000: continue
            for w in (1,2,3,4,5,6,7,8,9,10,11,12,13,100,101):
                if w%p not in G: continue
                ok,_,_=reach_all(p,K,M,w); tot+=1
                if not ok: bad+=1; print("FAIL",p,K,M,w)
print("tested",tot,"failures",bad)
# sanity: dead-end class should fail
print("p=7,w=3,K=0,M=1:",reach_all(7,0,1,3))
print("p=7,w=3,K=1,M=5:",reach_all(7,1,5,3))
# contraction check: u^{K+1} const on Z/p^{K+1}
for p in (3,5,7):
    for K in (0,1,2,3):
        P=p**(K+1); i2=pow(2,-1,P)
        vals=set()
        for a in range(P):
            x=a
            for _ in range(K+1): x=(p*x+1)*i2%P
            vals.add(x)
        xs=pow(2-p,-1,P)%P
        assert vals=={xs},(p,K,vals,xs)
print("contraction ok")
