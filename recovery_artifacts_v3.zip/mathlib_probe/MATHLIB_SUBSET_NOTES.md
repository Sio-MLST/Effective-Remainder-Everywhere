# Mathlib subset probe (2026-11-04, session 3). No Lean built, nothing installed.

## What was tested
- Single files download fine from raw.githubusercontent.com (master branch).
- api.github.com directory listings: rate-limited (403) without a token.
- No Mathlib files were kept: they were only counted. Re-download on demand.

## Transitive import closure (master, 2026-11-04), via mathlib_import_crawl.py
| Root | Files | Lines |
|---|---|---|
| Mathlib.Data.Nat.Prime.Basic | 1,359 | 408,808 |
| Mathlib.Data.ZMod.Basic | 1,402 | 427,097 |
| Mathlib.FieldTheory.Finite.Basic (Fermat) | 1,952 | 611,820 |
Conclusion: copying a file subset is not viable (closure ~1/3 of Mathlib; also Mathlib master
needs its own Lean toolchain, likely not 4.35 — unchecked). Use Mathlib only as a reference.

## Hand-written mini-library the new proof needs (core Lean, written fresh)
1. Fermat base 2: ord_p(2) | p-1. (Only genuinely new number theory.)
2. Standard Prime definition + bridge to PrimeLike.
3. Modular inverses mod Q (gcd/Bezout): 1/2, 1/4, 1/(2-p).
4. CRT existence for coprime moduli + lcm facts (choosing E, Step 3).
5. Finite reachability: bijections on a finite set reach any reachable target in < |set| steps.
6. Terras parity bookkeeping: already in EREp.lean (parity_word, integrality).
Already available: lifting-the-exponent for 2^d = 1+pu (Gen.order_iff, Gen.gen_unit).
Estimated size: a few hundred lines. Next step: write exact statements as a spec before coding.

## Re-run the probe
python3 mathlib_import_crawl.py Mathlib.Data.ZMod.Basic   # plain Python 3, ~1 min
