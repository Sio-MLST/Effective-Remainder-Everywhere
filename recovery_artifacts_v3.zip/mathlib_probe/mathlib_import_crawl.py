import re,sys,urllib.request,concurrent.futures as cf
B="https://raw.githubusercontent.com/leanprover-community/mathlib4/master/"
def get(m):
    try: return urllib.request.urlopen(B+m.replace('.','/')+'.lean',timeout=20).read().decode()
    except Exception as e: return ""
def imps(t): return [x for x in re.findall(r'^\s*(?:public\s+|meta\s+)*import\s+(\S+)',t,re.M) if x.startswith('Mathlib')]
for root in sys.argv[1:]:
    seen={root};front=[root];lines=0
    with cf.ThreadPoolExecutor(32) as ex:
        while front and len(seen)<3000:
            res=list(ex.map(get,front));nf=[]
            for t in res:
                lines+=t.count('\n')
                for i in imps(t):
                    if i not in seen: seen.add(i);nf.append(i)
            front=nf
    print(root,len(seen),"files",lines,"lines", "(capped)" if front else "")
