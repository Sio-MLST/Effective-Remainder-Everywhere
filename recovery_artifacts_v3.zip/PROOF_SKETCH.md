# Weak theorem for px+1: a short proof sketch (UNVERIFIED in Lean; checked numerically, see end)
Written 2026-11-04. Status tags: [borrowed] standard theorem cited, [argued] argued here, [tested] checked by script, [gap] not fully written.

## Theorem
p odd prime, 2^(p-1) ≢ 1 (mod p²), w ≥ 1 with (w mod p) ∈ ⟨2⟩. Then for all N ≥ 1, r, B there is n > B with n ≡ r (mod N) and n ⇝ w.
Shortcut map T(n)= n/2 (even), (pn+1)/2 (odd). An odd T-step is two C_p-steps, so T-orbits lie inside C_p-orbits; work with T.
Write h(x)=x/2, u(x)=(px+1)/2 (affine maps of Z/Q for odd Q).

## Borrowed
(F1) [borrowed] (Z/p^m)^× is cyclic (p odd); if 2^d = 1+pa, p∤a, then 2^d has order p^(m-1) mod p^m (lifting the exponent).
(F2) [borrowed, Terras] the first ℓ parities of n under T depend only on n mod 2^ℓ, one class per pattern ω; T^ℓ(n)=(p^o n + c_ω)/2^ℓ, o = number of odd steps, c_ω ∈ Z depends only on ω.
(F3) Fermat's little theorem; CRT.

## Lemma 0 (the only place non-Wieferich is used) [argued, from F1,F3]
For every m: ⟨2⟩ mod p^m = {x : x mod p ∈ ⟨2⟩ mod p}; in particular ⟨2⟩ ⊇ U={x≡1 mod p}.
Proof: d=ord_p(2) divides p-1 (Fermat). If p² | 2^d−1 then p² | 2^(p−1)−1, excluded. So 2^d=1+pa, p∤a; by F1 it generates U (order p^(m−1)).

## Step 1: remove the 2-part (Terras) [argued]
N = 2^α p^b M, gcd(M,2p)=1. r₀ = r mod 2^α, o₂ = odd steps of r₀ in α steps, z₀ = T^α(r₀). For n = r₀+2^α m: T^α(n) = z₀ + p^(o₂) m.
n ≡ r (mod N) iff m lies in one class mod p^b M, so z = T^α(n) ranges over a full class z₁ mod p^c M, c = o₂+b, all large values included.
So it suffices to prove: **Proposition.** For any c, any M coprime to 2p, any z₁, B: some z > B, z ≡ z₁ (mod p^c M), z ⇝ w.

## Step 2: blurred reachability (the heart) [argued, tested]
K ≥ c (enlarged in Step 3), P=p^(K+1), Q=PM, Z/Q = Z/P × Z/M. x "reaches w" if some word in h,u sends x to w. Claim: every x reaches w.
(a) Contraction. x* = 1/(2−p) ∈ Z/P. u(x)−x* = (p/2)(x−x*), so u^(K+1) ≡ x* (constant) on Z/P. (p=3: x* = −1.) x* ≡ 1/2 (mod p).
(b) Free translation. On Z/M, h,u are bijections. hu(t)=(pt+1)/4, uh(t)=(pt+2)/4, so uh = (t ↦ t+1/4)∘hu. Hence Γ=⟨h,u⟩ ≤ Sym(Z/M) contains t ↦ t+1/4; 1/4 is a unit, so Γ ⊇ all translations, Γ is transitive. A finite semigroup of bijections is a group (inverses are positive powers), so the semigroup orbit equals the Γ-orbit: any target is reachable by a word of length ≤ M−1.
(c) Explicit word. Given x=(a,t): Lemma 0 gives m ≥ 0 with 2^(−m)x* = w_P (both lie in ⟨2⟩-coset: w∈⟨2⟩, x*≡1/2).
    By (b) pick a word ω, |ω| ≤ M−1, with ω_M(t) = u_M^{−(K+1)}(2^m w_M). Then the word ω, then u^(K+1), then h^m sends x to w:
    after ω then u^(K+1): P-part = x* by (a) (whatever ω did to it), M-part = 2^m w_M; then h^m gives (2^(−m)x*, w_M) = w.
    Number of u-steps o ≤ (M−1)+(K+1) = M+K.   [no loop group, stabiliser or period descent needed]

## Step 3: lift to an actual integer [argued, tested end to end; CRT bookkeeping is a sketch]
Take K ≥ max(c, ν), p^ν ‖ D := ord_M(2). Apply Step 2 to x = z₁ mod Q: a word ω (length ℓ, o odd steps) with
 (†) p^o z₁ + c_ω ≡ 2^ℓ w (mod Q).
Want E ≥ 0 with (‡) 2^(ℓ+E) w ≡ Y := c_ω + p^o z₁ (mod p^(o+c) M). Then z := (2^(ℓ+E) w − c_ω)/p^o is an integer ≡ z₁ (mod p^c M).
Parities: p^o r_ω + c_ω ≡ 0 (mod 2^ℓ) and p^o z ≡ −c_ω (mod 2^ℓ) give z ≡ r_ω (mod 2^ℓ); so by F2, T^ℓ(z)=2^E w, and E more halvings reach w.
Solving (‡): mod M need D | E (use † mod M). Mod p^(o+c): by † Y/(2^ℓ w) ≡ 1 (mod p^(K+1)); by Lemma 0 it equals 2^(ds), and p^K | s (order of 2^d mod p^(K+1) is p^K), so E ≡ ds (mod d p^(o+c−1)).
Compatible since p^K | s and K ≥ ν (and gcd of the d-parts divides d·s). CRT gives E; adding the lcm makes it as large as wanted, so z > B.

## Step 4: bound [argued, tested only as the u-count claim; differs from the Lean file's bound]
ℓ ≤ (M−1)+(K+1)+m with m < ord_P(2) ≤ d p^K. o ≤ M+K. E < lcm(D, d p^(o+c−1)) ≤ M p p^(M+K+c).
With p ≤ 2^L: p^K ≤ max(M, p^c) (as p^ν ≤ D ≤ M), p^c ≤ p^(α+b) ≤ N^(L+1). So log₂E ≤ L·M + O(L log N).
Result (sketch): n ≤ w · 2^(2^(L·N + O(L log N))).
The Lean file proves n ≤ w·2^(2^((3L+8)·p·N^(L+2)·(B+1))). Origin of the p·N^(L+2): it bounds Q = p^(K+1)M ≤ p N^(L+2), because the Lean word-length bound is ℓ ≤ Q (shortest path in a graph on Z/Q).
The new construction never searches in Z/Q: it uses the product structure (contraction + transitivity of Γ), giving o ≤ M+K instead of o ≤ Q.
Special case M = 1 (N = 2^α p^b): Γ trivial, o = K+1, E = p^O(c): singly exponential, consistent with the one-odd-step witness argument in UNDERSTANDING_NOTES §8.

## Where hypotheses enter
- non-Wieferich: Lemma 0 only (Step 2(c) via w_P, x*∈⟨2⟩-coset; Step 3 via 2^d generating U).
- w mod p ∈ ⟨2⟩: Step 2(c) only. Necessity: if w mod p ∉ ⟨2⟩ the tree of w is {2^k w} (UNDERSTANDING_NOTES §2).
- p prime: Fermat (d | p−1) and gcd(M,2p)=1 structure.

## Verification status (honest)
[tested] scripts/check_blurred_closure.py: 2,335 cases, p∈{3,5,7,11,13}, K≤2, M<40: every x reaches w; fails for p=7,w=3 (dead end) as predicted; u^(K+1) constant = x* verified.
[tested] scripts/check_odd_step_bound.py: 1,817 cases: min number of u-steps to reach w is ≤ M+K (tight when M=1).
[tested] scripts/pipeline_test.py: 836 cases (p∈{3,5,7}, N up to 81, various w, r): Steps 1–3 build an explicit n with n ≡ r (mod N) whose T-orbit reaches w (word found by BFS, E found by search).
[gap] F2 (Terras) cited not proved; CRT compatibility in Step 3 sketched; the bound claim in Step 4 not re-derived rigorously; nothing formalised in Lean.
