import sys
def ancestors(p,w,bound):
    seen={w}; st=[w]
    while st:
        z=st.pop()
        c=[2*z]
        if z%2==0 and (z-1)%p==0 and ((z-1)//p)%2==1 and z>1: c.append((z-1)//p)
        for n in c:
            if 0<n<=bound and n not in seen: seen.add(n); st.append(n)
    return seen
for p,w in ((3,1),(5,1),(7,1),(7,2)):
    A=sorted(ancestors(p,w,3*10**6))
    res=[]
    for N in (2,3,4,5,6,8,9,10,12,15,16,20,25,27,30):
        m={}
        for n in A:
            r=n%N
            if r not in m: m[r]=n
            if len(m)==N: break
        res.append((N,len(m)==N,max(m.values()) if len(m)==N else None))
    print("p",p,"w",w,"size",len(A)); print(res)
