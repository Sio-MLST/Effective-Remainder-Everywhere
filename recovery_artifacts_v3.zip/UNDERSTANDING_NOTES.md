> **Superseded in part (2026-11-04, session 3):** see START_HERE.md for precedence. Status lines and next steps here are historical; PLAN_V3.md is the current plan.

# Understanding notes (paper-level, no builds). Tags: [read] seen in file, [paper] argued here, [unchecked] plausible only.

## 1. Statement (audited against EREp.lean) [read]
collatz p n = n/2 if even else p*n+1; Reaches p v n := ∃k, iter (collatz p) k n = v  (n reaches v) -- matches the informal map.
Weak thm: Base p, PrimeLike p, p ≤ 2^L, w%p ∈ ⟨2⟩ ⇒ ∀N≥1,r ∃n: n⇝w, n≡r (N), n ≤ w·2^(2^((3L+8)pN^(L+2))).
- w%p∈⟨2⟩ forces p∤w, so w≥1. Base p: some d≤p, 2^d=1+pu, p∤u. For prime p: Base ⇔ non-Wieferich
  (d must be a multiple of ord_p 2; v_p(2^{m·ord}-1)=v_p(2^ord-1)+v_p(m), so d=ord works iff non-Wieferich).
- Statement matches informal; no discrepancy found.

## 2. The dichotomy [paper]
Non-Wieferich ⇒ ⟨2⟩ mod p^{K+1} ⊇ U_1={x≡1 mod p}. So "live" classes mod p^{K+1} are exactly those whose class mod p is in ⟨2⟩ (Lean: two_gen). One picture: a coset w⟨2⟩ either contains 1 or not.
Necessity (Thm 2), short enough to formalise: if 2^k·w ≢ 1 (mod p) ∀k, then iter collatz j n = w ⇒ n = 2^k·w.
 Induction on j: f n = 2^k w; n even ⇒ n=2^{k+1}w; n odd ⇒ p n+1 = 2^k w ≡1, contradiction.
 And "∃k, 2^k w≡1" ⇔ w∈⟨2⟩ using 2^{kd}≡1 (w ≡ 2^{k(d-1)}); no primality needed.
 Hence sharp: for non-Wieferich p, [full coverage of w] ⇔ w mod p ∈ ⟨2⟩. (p∤w alone is FALSE: p=7,w=3; N=p,r=0 is missed. If p|w, tree⊂0 mod p, class 1 missed.)
 => README future-work item 4 is resolved; the "strong theorem" must keep w∈⟨2⟩.

## 3. Part A, as it is in the file [read] and a reframing
Fibre of target class a: F_a ⊂ Z/M. F_1 ≠ ∅; Stab = affine bijections of Z/M preserving F_1.
Lean: least translation period q (translationPeriod_one) ; q>1 refuted by Gen.period_general with hA,hB.
fibre_full (classes outside ⟨2⟩): ONE undo step from a live class (pa+1∈U_1⊆G), so dead-end classes are free.
Reframing [paper]: derived subgroup of Aff(Z/M) is translations, so any commutator of Stab lies in Stab∩translations = qZ/M.
 Hence Stab mod q is abelian (in the proof only the special loop ℓ is used, i.e. ℓ is central mod q).
 The final contradiction still needs (A) ord_q 2 | ord_P 2 and (B) the numerics; no pure-group one-liner found. Tag: clean replacement NOT found.
Observation [unchecked relevance]: the undo/shortcut map T(x)=(px+1)/2 is p-adically contracting with fixed point 1/(2-p)
 (p=3: -1; p=5: -1/3; checked by hand). The level-by-level descent in Lemma 9 looks like this contraction. Not proved to be the same thing.

## 4. Part B mechanism [read]
hit_residue order of choices: M coprime to 2p; D=ord of 2 mod M (D≤M), D=p^ν·d'; set K=ν+b' (so p^K·d' kills 2 mod M; p^K ≤ p^{b'}M).
 closure_word_short: at precision Q=p^{K+1}M find parity word u, |u|≤Q, with p^{ones}x+offset ≡ 2^{|u|+κ}w (mod Q).
 Circularity is broken by ORDER: word found first at fixed K; only afterwards raise p-adic precision to K+j with j=ones(u) ≤ Q
 (exp_lift: re-solve 2^k w ≡ Z mod p^{K+j+1}M by discrete log in U_1 via gen_unit/order_iff, k = κ + d p^K(t'+p^j s)).
 Final n = (2^{|u|+k}w − offset)/p^{ones}, integral because precision ≥ ones.
Double exponential [read+paper]: k ≈ p^{K+ones} ≈ 2^{L·Q}, n ≈ 2^k w. Two causes: (i) word length ≤ Q is a pigeonhole (BFS depth in Z/Q);
 (ii) lifting an exponent mod p^{ones} costs size p^{ones}. Single exponential would need words with ones ≈ log Q (the open "sums of ⟨2⟩" problem).
Unresolved: where exactly N^{L+2} arises (hit_residue needs X ≥ p·p^{b'}·M·M; remainder_bounded/2-part not read). Not traced.

## 5. Strong theorem: what is actually missing [paper]
Math: nothing for sufficiency. Logistics, in order of effort:
 (a) Fermat base 2 ⇒ ord d | p-1 ⇒ Base from 2^{p-1}≢1 mod p². d≤p-1 alone is pigeonhole (no Fermat), but d|p-1 needs Fermat/Lagrange:
     2^{p-1}=(1+pu)^e ≡ 1+e p u (p²), so p|u ⇒ 2^{p-1}≡1 (p²). Route options: self-made Pascal/binomial (a+1)^p≡a^p+1 (~60-100 lines),
     or orbit counting. Cheapest honest alternative: state strong thm with Base as hypothesis and prove Fermat link as separate lemma.
 (b) Prime bridge: with a self-defined Prime p := 2≤p ∧ ∀m, m∣p→m=1∨m=p, PrimeLike is ~5 lines (gcd | p). Whether core has Nat.Prime: UNVERIFIED (not installed).
 (c) Necessity lemma of §2 (~25 lines), makes hypotheses provably sharp.
 (d) Optional: tighten cor constants.

## 6. Exposition skeleton [paper]
1 Statement + sharp dichotomy (Thm 1 generation, Thm 2 necessity). 2 Residue closure: fibres, rigidity-by-counting, stabiliser, commutator/period, q=1.
3 Lift: word first, precision second. 4 Bound: honest remark on double exponential. 5 Lean as certificate (173 decls, standard axioms).

## 7. Mazur paper (read in context; PDF text has lost superscripts, so I read for structure, not constants) [read]
Different theorem: positive density of n<X with τ(n) ≤ 10.46 log n (3x+1 only), via Z/3^q random-walk mixing (Tao-style), one fixed seed M with S(M)=1.
Useful pieces: Lemma 4.1 R_j=(4^j−1)/3 permutes residues mod 3^q (via v_3(4^j−1)=1+v_3(j)) = our gen_unit/order_iff for p=3, d=2.
Lemma 2.1 (F_w : Z/3^t → Z/3^{t+d} injective) = p-adic side is an injective expanding tree; M-side (our Part A) is a permutation. CRT splits them.
Mixing (2.3) needs modulus 3^q (2 is a primitive root there); says nothing about Z/M, gcd(M,6)=1. Confirms handoff.

## 8. New derivation [paper, not formalised]: N = 2^α p^b has a SINGLY exponential witness
(i) α=0, N=p^b. Take n=(2^k w−1)/p with 2^k w≡1 (p), k≥1. Then n is odd, C(n)=2^k w, so n⇝w. k=k0+dj: 2^d generates U_1 mod p^{b+1}
    (order p^b by order_iff), so n mod p^b takes every value as j<p^b. Hence n ≤ w·2^{d p^b+d} ≤ w·2^{pN+p}. (p=3,w=1: Mazur's R_j.)
(ii) general α: fix n0<2^α with prescribed class; its parity word (ones≤α) gives Z0=(p^{ones}n0+offset)/2^α, and n=n0+2^α t gives Z=Z0+p^{ones}t.
    Impose Z=(2^k w−1)/p; solving mod p^{b+ones} for k needs only that 1+pZ∈U_1⊆G, k ≤ d p^{b+ones}. Then t integral, n≡r mod 2^α p^b.
    n ≤ w·2^{O(d p^{b+α})}, and p^α ≤ (2^α)^L ⇒ exponent O(N^{L+1}). Singly exponential, no pigeonhole.
    The Lean file's M=1 bound is still doubly exponential (it uses closure_word_short length ≤ p^{K+1}).
(iii) Hypothesis [unchecked]: the N^{L+2} in the Lean bound = N^L (from p^α) · N^2 (M and p parts).
(iv) Consequence: the double exponential is caused ONLY by the M-part (coprime to 2p). One end-step 2^k w only reaches the coset w⟨2⟩ mod M,
    so M needs t odd steps with Σ p^{t-i}2^{e_i} covering Z/M. Pigeonhole gives t≤M; the real question is whether t=O(log M) suffices
    (plausible: M=2^s−1 needs t≈s≈log2 M). If yes, whole theorem becomes singly exponential.
## Best next step (decision)
Study t(M) := least number of odd steps (as sums Σ p^{t-i}2^{e_i}, mod M) that cover Z/M: tiny hand/py check for p=3, small M, then try to prove t=O(log M) at least for M=2^s−1.

## 9. Takeaway on Mazur (agreed with user)
His linchpin = mixing; ours = coverage. Overlap is the t(M) question (how few odd steps cover Z/M). If we contact him: ask only that, framed as a question.
Our coverage thm is a necessary-side fact (no algebraic obstruction mod M, any non-Wieferich p). Unchecked: whether coverage mod N for 3x+1 is already in the literature.
## 10. Plan status: see PLAN.md (full plan, status, revised order).
