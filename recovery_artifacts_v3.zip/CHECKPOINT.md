> **Superseded in part (2026-11-04, session 3):** see START_HERE.md for precedence. Status lines and next steps here are historical; PLAN_V3.md is the current plan.

# Checkpoint — 2026-11-04 (recovery session, no builds run)

## Evidence on disk
- ERE_recovery_artifacts.zip: README.md + verification.log (12:07), EREp.lean (1932 lines), split/PX{Gen,1,2}.lean, reference/ERE5.lean.
- verification.log: monolith and split chain both rc=0 (~16 s); axioms for effective_remainder_everywhere, cor_p3, cor_p5 = propext, Classical.choice, Quot.sound.
- grep this session: 0 `sorry` in EREp.lean. Not re-compiled (status taken from log).
- Previous run finished its deliverables before the interruption; no partial/broken outputs found.

## Statement as formalised (read from EREp.lean:1891)
Base p ∧ PrimeLike p ∧ p ≤ 2^L ∧ N ≥ 1 ∧ w%p ∈ ⟨2⟩ ⇒ ∀ r ∃ n, Reaches p w n ∧ n ≡ r (N) ∧ n ≤ w·2^(2^((3L+8)·p·N^(L+2))).

## Findings from reading (new this session)
1. README future-work item 4 ("w ∉ ⟨2⟩ not investigated") is stale: Handoff Theorem 2 proves on paper that w ∈ ⟨2⟩ is necessary (p=7, w=3: predecessors are only 3·2^k). So the strong theorem "p ∤ w alone" is FALSE; the correct strong form keeps w ∈ ⟨2⟩. Formalising Thm 2 = short induction (gap, not formalised).
2. Handoff open question "does Part B need primitivity of 2?" is answered by the formalisation: no.
3. Exponent F_p = (3L+8)·p·N^(L+2)·(B+1), L ≈ log2 p: N^4 (p=3) vs N^5 (p=5) is exactly the L-dependence.
4. Weak → strong gap is logistical, not mathematical:
   - Existence of d ≤ p−1 with p | 2^d−1: pigeonhole + cancel 2 (no Fermat needed).
   - Translating "2^(p−1) ≢ 1 mod p²" into Base needs d | p−1 (Fermat/Lagrange) — the only real lemma left.
   - PrimeLike ↔ prime: core Lean has no Nat.Prime (Mathlib def) — unverified; if so, bridge is to a self-defined Prime.
## Remaining (none started)
Fermat base 2 + d|p−1; Prime bridge; formalise Thm 2 (necessity); tighten cor constants (42N^4, 85N^5); optional Base instances p=7,11,13.
