from math import gcd
from collections import deque
def ordu(p,M):
    if M==1: return 1
    inv2=pow(2,-1,M)
    f=lambda t:((p*t+1)*inv2)%M
    # order of permutation f on Z/M
    seen=[False]*M; from math import lcm; r=1
    for s in range(M):
        if not seen[s]:
            L=0;x=s
            while not seen[x]: seen[x]=True;x=f(x);L+=1
            r=lcm(r,L)
    return r
def min_u(p,K,M,w):
    Q=p**(K+1)*M; i2=pow(2,-1,Q)
    # reverse 0-1 BFS: dist[x]=min #u to reach w
    pre0={};pre1={}
    for x in range(Q):
        pre0.setdefault((x*i2)%Q,[]).append(x)
        pre1.setdefault(((p*x+1)*i2)%Q,[]).append(x)
    INF=10**9; dist=[INF]*Q; dist[w%Q]=0; dq=deque([w%Q])
    while dq:
        y=dq.popleft()
        for x in pre0.get(y,[]):
            if dist[x]>dist[y]: dist[x]=dist[y]; dq.appendleft(x)
        for x in pre1.get(y,[]):
            if dist[x]>dist[y]+1: dist[x]=dist[y]+1; dq.append(x)
    return max(dist)

worst=0;cnt=0
for p in (3,5,7,11,13):
    G={pow(2,i,p) for i in range(p)}
    for K in (0,1,2,3):
        for M in [m for m in range(1,60) if gcd(m,2*p)==1]:
            if p**(K+1)*M>8000: continue
            for w in (1,2,3,4,5,6,7):
                if w%p not in G: continue
                m=min_u(p,K,M,w); b=M+K; cnt+=1
                assert m<=b,(p,K,M,w,m,b); worst=max(worst,m/b)
print("cases",cnt,"claim: min #u-steps to reach w from any x in Z/(p^(K+1) M) is <= M+K; holds; worst ratio",round(worst,3))
