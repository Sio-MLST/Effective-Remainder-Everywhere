# End-to-end test of PROOF_SKETCH steps 1-3: builds an explicit n and checks n ≡ r (mod N) and that the T-orbit of n reaches w.
import random, sys
from math import gcd
from collections import deque
def T(p,n): return n//2 if n%2==0 else (p*n+1)//2
def mord(M):
    if M==1: return 1
    o=1;x=2%M
    while x!=1: x=x*2%M;o+=1
    return o
def vp(n,p):
    k=0
    while n%p==0: n//=p;k+=1
    return k
def build(p,w,N,r,B=0,Elimit=4_000_000):
    a=vp(N,2); b=vp(N//2**a,p); M=N//(2**a*p**b); assert gcd(M,2*p)==1
    r0=r%2**a; x=r0; o2=0
    for _ in range(a):
        if x%2: o2+=1
        x=T(p,x)
    z0=x; m0=(r//2**a)%(p**b*M); z1=z0+p**o2*m0; c=o2+b
    D=mord(M); nu=vp(D,p); K=max(c,nu); Q=p**(K+1)*M
    i2=pow(2,-1,Q); start=z1%Q; goal=w%Q
    prev={start:None}; dq=deque([start])
    while dq and goal not in prev:
        s=dq.popleft()
        for mv,t in (('h',(s*i2)%Q),('u',((p*s+1)*i2)%Q)):
            if t not in prev: prev[t]=(s,mv); dq.append(t)
    if goal not in prev: return None
    word=[];s=goal
    while prev[s] is not None: s,mv=prev[s]; word.append(mv)
    word.reverse(); l=len(word); o=word.count('u')
    cw=0;j=0
    for mv in word:
        if mv=='u': cw=p*cw+2**j
        j+=1
    Y=cw+p**o*z1; mod=p**(o+c)*M
    cur=pow(2,l,mod)*w%mod; E=None
    for e in range(Elimit):
        if cur==Y%mod: E=e;break
        cur=cur*2%mod
    if E is None: return ('noE',o,c)
    z=(2**(l+E)*w-cw)//p**o
    assert (2**(l+E)*w-cw)%p**o==0 and (z-z1)%(p**c*M)==0
    m=(z-z0)//p**o2; assert (z-z0)%p**o2==0 and m>=0
    n=r0+2**a*m
    assert n%N==r%N
    y=n
    for _ in range(a+l+E+5):
        if y==w: break
        y=T(p,y)
    return (y==w, l, o, E, n.bit_length())
random.seed(1)
tot=ok=skip=0
for p in (3,5,7):
    G={pow(2,i,p) for i in range(p)}
    for N in list(range(1,40))+[48,54,60,75,81]:
        for w in (1,2,3,4,5,6,7,9,11):
            if w%p not in G: continue
            r=random.randrange(10*N)
            res=build(p,w,N,r)
            tot+=1
            if res is None or res[0] is False or res[0]=='noE': skip+=1; 
            else: ok+=1
            if res and res[0] is False: print("FAIL",p,w,N,r,res)
print("tested",tot,"orbit-verified",ok,"skipped(no E within limit or BFS)",skip)
